package com.example.focuslock.lock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import com.example.focuslock.R
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.tasks.TaskRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LockForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "focus_lock"
        private const val NOTIFICATION_ID = 9001
        private const val WATCHDOG_INTERVAL_MS = 2_000L
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var stepServiceRequested = false

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        TaskRegistry.initialize(applicationContext)
        TaskRegistry.resetAll()

        serviceScope.launch {
            val dataStore = AppDataStore(applicationContext)
            dataStore.setLockActive(true)
            dataStore.setEmergencyUntil(0L)
        }

        startWatchdog()
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        tryStartLockActivity()
        return START_NOT_STICKY
    }

    private fun startWatchdog() {
        serviceScope.launch {
            val dataStore = AppDataStore(applicationContext)

            while (isActive) {
                val settings = dataStore.readSettings()
                val now = System.currentTimeMillis()

                if (settings.lockActive && !TaskRegistry.allCompleted()) {
                    syncWalkingService(dataStore)
                } else if (stepServiceRequested) {
                    stepServiceRequested = false
                    stopService(Intent(this@LockForegroundService, StepTrackingService::class.java))
                }

                if (
                    settings.lockActive &&
                    now >= settings.emergencyUntil &&
                    !TaskRegistry.allCompleted() &&
                    Settings.canDrawOverlays(this@LockForegroundService)
                ) {
                    startLockActivity()
                }

                delay(WATCHDOG_INTERVAL_MS)
            }
        }
    }

    private suspend fun syncWalkingService(dataStore: AppDataStore) {
        val walkingSettings = dataStore.readWalkingSettings()
        val walkingProgress = dataStore.readWalkingProgress()
        val permissionGranted = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q ||
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED
        val goalMet = walkingProgress.steps >= walkingSettings.requiredSteps

        if (walkingSettings.enabled && permissionGranted && !goalMet) {
            // Start once; the service restarts itself (START_STICKY) if the system kills it.
            if (stepServiceRequested) return
            stepServiceRequested = true
            runCatching {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    startForegroundService(Intent(this@LockForegroundService, StepTrackingService::class.java))
                } else {
                    startService(Intent(this@LockForegroundService, StepTrackingService::class.java))
                }
            }
        } else if (stepServiceRequested) {
            stepServiceRequested = false
            stopService(Intent(this@LockForegroundService, StepTrackingService::class.java))
        }
    }

    private fun tryStartLockActivity() {
        if (!Settings.canDrawOverlays(this)) {
            return
        }

        val lockIntent = Intent(this, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        runCatching { startActivity(lockIntent) }
    }

    private fun startLockActivity() {
        val lockIntent = Intent(this, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        runCatching { startActivity(lockIntent) }
    }

    private fun buildNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Focus lock is active. Complete the tasks to unlock.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(lockPendingIntent())
            .setFullScreenIntent(lockPendingIntent(), true)
            .build()

    private fun lockPendingIntent(): PendingIntent {
        return PendingIntent.getActivity(
            this,
            9002,
            Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Focus lock",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows when the focus lock is active."
            }

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopService(Intent(this, StepTrackingService::class.java))
        serviceScope.cancel()
        super.onDestroy()
    }
}
