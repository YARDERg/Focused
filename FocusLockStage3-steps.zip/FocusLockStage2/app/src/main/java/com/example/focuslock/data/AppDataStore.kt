package com.example.focuslock.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private val Context.focusLockDataStore by preferencesDataStore(name = "focus_lock")

class AppDataStore(private val context: Context) {
    private object Keys {
        val scheduleEnabled = booleanPreferencesKey("schedule_enabled")
        val startMinutes = intPreferencesKey("start_minutes")
        val lockActive = booleanPreferencesKey("lock_active")
        val emergencyUntil = longPreferencesKey("emergency_until")
        val learningStartUrl = stringPreferencesKey("learning_start_url")
        val learningRequiredMinutes = intPreferencesKey("learning_required_minutes")
        val learningRequiredLectures = intPreferencesKey("learning_required_lectures")
        val learningDebugEnabled = booleanPreferencesKey("learning_debug_enabled")
        val learningMinimumWatchedShare = intPreferencesKey("learning_minimum_watched_share")
        val learningEnabled = booleanPreferencesKey("learning_enabled")
        val walkingEnabled = booleanPreferencesKey("walking_enabled")
        val walkingRequiredSteps = intPreferencesKey("walking_required_steps")
        val walkingCadenceThreshold = intPreferencesKey("walking_cadence_threshold")
        val walkingDebugEnabled = booleanPreferencesKey("walking_debug_enabled")
        val walkingProgressDate = stringPreferencesKey("walking_progress_date")
        val walkingCreditedSeconds = longPreferencesKey("walking_credited_seconds")
        val walkingSteps = longPreferencesKey("walking_steps")
        val walkingHistory = stringPreferencesKey("walking_history")
        val learningProgressDate = stringPreferencesKey("learning_progress_date")
        val learningLectureCredits = stringSetPreferencesKey("learning_lecture_credits_ms")
        val learningLectureMaxPositions = stringSetPreferencesKey("learning_lecture_max_positions_ms")
        val learningLectureDurations = stringSetPreferencesKey("learning_lecture_durations_ms")
        val learningWatchedLectures = stringSetPreferencesKey("learning_watched_lectures")
        val legacyLearningLectureCredits = stringSetPreferencesKey("learning_lecture_credits")
    }

    val scheduleEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.scheduleEnabled] ?: false
    }

    val startMinutes: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.startMinutes] ?: (9 * 60)
    }

    val lockActive: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.lockActive] ?: false
    }

    val learningStartUrl: Flow<String> = context.focusLockDataStore.data.map {
        it[Keys.learningStartUrl] ?: DEFAULT_LEARNING_START_URL
    }

    val learningRequiredMinutes: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.learningRequiredMinutes] ?: DEFAULT_LEARNING_REQUIRED_MINUTES
    }

    val learningRequiredLectures: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.learningRequiredLectures] ?: DEFAULT_LEARNING_REQUIRED_LECTURES
    }

    val learningDebugEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.learningDebugEnabled] ?: false
    }

    val learningMinimumWatchedShare: Flow<Int> = context.focusLockDataStore.data.map {
        (it[Keys.learningMinimumWatchedShare] ?: DEFAULT_LEARNING_MINIMUM_WATCHED_SHARE).coerceIn(50, 100)
    }

    val learningEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.learningEnabled] ?: DEFAULT_TASK_ENABLED
    }

    val walkingEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.walkingEnabled] ?: DEFAULT_TASK_ENABLED
    }

    val walkingRequiredSteps: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.walkingRequiredSteps] ?: DEFAULT_WALKING_REQUIRED_STEPS
    }

    val walkingCadenceThreshold: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.walkingCadenceThreshold] ?: DEFAULT_WALKING_CADENCE_THRESHOLD
    }

    val walkingDebugEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.walkingDebugEnabled] ?: false
    }

    suspend fun setScheduleEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.scheduleEnabled] = enabled }
    }

    suspend fun setStartMinutes(minutes: Int) {
        require(minutes in 0..1439)
        context.focusLockDataStore.edit { it[Keys.startMinutes] = minutes }
    }

    suspend fun setLockActive(active: Boolean) {
        context.focusLockDataStore.edit { it[Keys.lockActive] = active }
    }

    suspend fun setEmergencyUntil(timestampMillis: Long) {
        context.focusLockDataStore.edit { it[Keys.emergencyUntil] = timestampMillis }
    }

    suspend fun setLearningStartUrl(url: String) {
        context.focusLockDataStore.edit { it[Keys.learningStartUrl] = url }
    }

    suspend fun setLearningRequiredMinutes(minutes: Int) {
        require(minutes >= 0)
        context.focusLockDataStore.edit { it[Keys.learningRequiredMinutes] = minutes }
    }

    suspend fun setLearningRequiredLectures(count: Int) {
        require(count >= 0)
        context.focusLockDataStore.edit { it[Keys.learningRequiredLectures] = count }
    }

    suspend fun setLearningDebugEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.learningDebugEnabled] = enabled }
    }

    suspend fun setLearningMinimumWatchedShare(percent: Int) {
        require(percent in 50..100)
        context.focusLockDataStore.edit { it[Keys.learningMinimumWatchedShare] = percent }
    }

    suspend fun setLearningEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.learningEnabled] = enabled }
    }

    suspend fun setWalkingEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.walkingEnabled] = enabled }
    }

    suspend fun setWalkingRequiredSteps(steps: Int) {
        require(steps >= MIN_WALKING_REQUIRED_STEPS)
        context.focusLockDataStore.edit { it[Keys.walkingRequiredSteps] = steps }
    }

    suspend fun setWalkingRequiredStepsDebug(steps: Int) {
        require(steps >= DEBUG_MIN_WALKING_REQUIRED_STEPS)
        context.focusLockDataStore.edit { it[Keys.walkingRequiredSteps] = steps }
    }

    suspend fun setWalkingCadenceThreshold(threshold: Int) {
        require(threshold >= 1)
        context.focusLockDataStore.edit { it[Keys.walkingCadenceThreshold] = threshold }
    }

    suspend fun setWalkingDebugEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.walkingDebugEnabled] = enabled }
    }

    suspend fun readWalkingSettings(): WalkingSettings {
        val preferences = context.focusLockDataStore.data.first()
        val debug = preferences[Keys.walkingDebugEnabled] ?: false
        val storedSteps = preferences[Keys.walkingRequiredSteps] ?: DEFAULT_WALKING_REQUIRED_STEPS
        return WalkingSettings(
            enabled = preferences[Keys.walkingEnabled] ?: DEFAULT_TASK_ENABLED,
            requiredSteps = if (debug) {
                storedSteps.coerceAtLeast(DEBUG_MIN_WALKING_REQUIRED_STEPS)
            } else {
                storedSteps.coerceAtLeast(MIN_WALKING_REQUIRED_STEPS)
            },
            cadenceThreshold = (preferences[Keys.walkingCadenceThreshold] ?: DEFAULT_WALKING_CADENCE_THRESHOLD).coerceAtLeast(1),
            debugEnabled = debug
        )
    }

    suspend fun readWalkingProgress(): WalkingProgress {
        val today = LocalDate.now()
        var progress = WalkingProgress(today.toString(), 0L, 0L)
        context.focusLockDataStore.edit { preferences ->
            rollWalkingDay(preferences, today)
            progress = WalkingProgress(
                date = today.toString(),
                steps = preferences[Keys.walkingSteps] ?: 0L,
                creditedSeconds = preferences[Keys.walkingCreditedSeconds] ?: 0L
            )
        }
        return progress
    }

    /** Adds counted steps and/or walking seconds to today's totals and updates the per-day history. */
    suspend fun creditWalking(steps: Long, seconds: Long): WalkingProgress {
        val today = LocalDate.now()
        var progress = WalkingProgress(today.toString(), 0L, 0L)
        context.focusLockDataStore.edit { preferences ->
            rollWalkingDay(preferences, today)
            val newSteps = (preferences[Keys.walkingSteps] ?: 0L) + steps.coerceAtLeast(0L)
            val newSeconds = (preferences[Keys.walkingCreditedSeconds] ?: 0L) + seconds.coerceAtLeast(0L)
            preferences[Keys.walkingSteps] = newSteps
            preferences[Keys.walkingCreditedSeconds] = newSeconds
            upsertWalkingHistory(preferences, today.toString(), newSteps, newSeconds, today)
            progress = WalkingProgress(today.toString(), newSteps, newSeconds)
        }
        return progress
    }

    /** Per-day walking history for the last [WALKING_HISTORY_DAYS] days, oldest first. */
    suspend fun readWalkingHistory(): List<WalkingDayRecord> {
        val preferences = context.focusLockDataStore.data.first()
        return pruneWalkingHistory(
            parseWalkingHistory(preferences[Keys.walkingHistory]).values,
            LocalDate.now()
        )
    }

    // Starts a fresh day: archives the previous day's totals into history, then zeroes today's counters.
    private fun rollWalkingDay(preferences: MutablePreferences, today: LocalDate) {
        val todayText = today.toString()
        val storedDate = preferences[Keys.walkingProgressDate]
        if (storedDate == todayText) return
        if (storedDate != null) {
            upsertWalkingHistory(
                preferences,
                storedDate,
                preferences[Keys.walkingSteps] ?: 0L,
                preferences[Keys.walkingCreditedSeconds] ?: 0L,
                today
            )
        }
        preferences[Keys.walkingProgressDate] = todayText
        preferences[Keys.walkingSteps] = 0L
        preferences[Keys.walkingCreditedSeconds] = 0L
    }

    private fun upsertWalkingHistory(
        preferences: MutablePreferences,
        date: String,
        steps: Long,
        seconds: Long,
        today: LocalDate
    ) {
        val records = parseWalkingHistory(preferences[Keys.walkingHistory])
        records[date] = WalkingDayRecord(date, steps, seconds)
        preferences[Keys.walkingHistory] = serializeWalkingHistory(pruneWalkingHistory(records.values, today))
    }

    suspend fun readSettings(): StoredSettings {
        val preferences = context.focusLockDataStore.data.first()
        return StoredSettings(
            scheduleEnabled = preferences[Keys.scheduleEnabled] ?: false,
            startMinutes = preferences[Keys.startMinutes] ?: (9 * 60),
            lockActive = preferences[Keys.lockActive] ?: false,
            emergencyUntil = preferences[Keys.emergencyUntil] ?: 0L
        )
    }

    suspend fun readLearningSettings(): LearningSettings {
        val preferences = context.focusLockDataStore.data.first()
        return LearningSettings(
            startUrl = preferences[Keys.learningStartUrl] ?: DEFAULT_LEARNING_START_URL,
            requiredMinutes = preferences[Keys.learningRequiredMinutes] ?: DEFAULT_LEARNING_REQUIRED_MINUTES,
            requiredLectures = preferences[Keys.learningRequiredLectures] ?: DEFAULT_LEARNING_REQUIRED_LECTURES,
            debugEnabled = preferences[Keys.learningDebugEnabled] ?: false,
            minimumWatchedShare = (preferences[Keys.learningMinimumWatchedShare] ?: DEFAULT_LEARNING_MINIMUM_WATCHED_SHARE).coerceIn(50, 100),
            enabled = preferences[Keys.learningEnabled] ?: DEFAULT_TASK_ENABLED
        )
    }

    suspend fun readLearningProgress(): LearningProgress {
        val today = LocalDate.now().toString()
        var progress = LearningProgress.empty(today)

        context.focusLockDataStore.edit { preferences ->
            val storedDate = preferences[Keys.learningProgressDate]
            if (storedDate != today) {
                preferences[Keys.learningProgressDate] = today
                preferences[Keys.learningLectureCredits] = emptySet()
                preferences[Keys.learningLectureMaxPositions] = emptySet()
                preferences[Keys.learningLectureDurations] = emptySet()
                preferences[Keys.learningWatchedLectures] = emptySet()
            } else if (preferences[Keys.learningLectureCredits] == null) {
                // Migrate the reviewed build's daily credits, which were stored as whole seconds.
                val legacy = parseLectureCredits(preferences[Keys.legacyLearningLectureCredits] ?: emptySet())
                if (legacy.isNotEmpty()) {
                    preferences[Keys.learningLectureCredits] = legacy.map { (key, seconds) ->
                        "$key=${seconds * 1000L}"
                    }.toSet()
                    preferences[Keys.legacyLearningLectureCredits] = emptySet()
                }
            }

            val credits = parseLectureValues(preferences[Keys.learningLectureCredits] ?: emptySet())
            val maxPositions = parseLectureValues(preferences[Keys.learningLectureMaxPositions] ?: emptySet())
            val durations = parseLectureValues(preferences[Keys.learningLectureDurations] ?: emptySet())
            val minimumShare = (preferences[Keys.learningMinimumWatchedShare] ?: DEFAULT_LEARNING_MINIMUM_WATCHED_SHARE).coerceIn(50, 100)
            val watched = recomputeWatchedLectures(credits, maxPositions, durations, minimumShare)
            preferences[Keys.learningWatchedLectures] = watched

            progress = LearningProgress(
                date = today,
                creditsByLectureMs = credits,
                maxPositionByLectureMs = maxPositions,
                watchedLectureIds = watched
            )
        }

        return progress
    }

    suspend fun creditLearningLecture(
        lectureId: String,
        creditedMillis: Long,
        maxPositionMillis: Long,
        durationMillis: Long,
        minimumWatchedSharePercent: Int
    ): LearningProgress {
        require(lectureId.isNotBlank())
        require(creditedMillis >= 0)
        require(maxPositionMillis >= 0)
        require(durationMillis > 0)
        require(minimumWatchedSharePercent in 50..100)

        val today = LocalDate.now().toString()
        var result = LearningProgress.empty(today)

        context.focusLockDataStore.edit { preferences ->
            val storedDate = preferences[Keys.learningProgressDate]
            val credits = if (storedDate == today) {
                parseLectureValues(preferences[Keys.learningLectureCredits] ?: emptySet()).toMutableMap()
            } else mutableMapOf()
            val maxPositions = if (storedDate == today) {
                parseLectureValues(preferences[Keys.learningLectureMaxPositions] ?: emptySet()).toMutableMap()
            } else mutableMapOf()
            val durations = if (storedDate == today) {
                parseLectureValues(preferences[Keys.learningLectureDurations] ?: emptySet()).toMutableMap()
            } else mutableMapOf()

            val cappedCredit = minOf(creditedMillis, durationMillis)
            val cappedMaxPosition = minOf(maxPositionMillis, durationMillis)
            credits[lectureId] = cappedCredit
            maxPositions[lectureId] = maxOf(maxPositions[lectureId] ?: 0L, cappedMaxPosition)
            durations[lectureId] = durationMillis

            val watched = recomputeWatchedLectures(credits, maxPositions, durations, minimumWatchedSharePercent)

            preferences[Keys.learningProgressDate] = today
            preferences[Keys.learningLectureCredits] = credits.entries
                .filter { it.value > 0 }
                .map { "${it.key}=${it.value}" }
                .toSet()
            preferences[Keys.learningLectureMaxPositions] = maxPositions.entries
                .filter { it.value > 0 }
                .map { "${it.key}=${it.value}" }
                .toSet()
            preferences[Keys.learningLectureDurations] = durations.entries
                .filter { it.value > 0 }
                .map { "${it.key}=${it.value}" }
                .toSet()
            preferences[Keys.learningWatchedLectures] = watched

            result = LearningProgress(today, credits, maxPositions, watched)
        }

        return result
    }

    companion object {
        const val DEFAULT_LEARNING_START_URL = "https://www.udemy.com"
        const val DEFAULT_LEARNING_REQUIRED_MINUTES = 30
        const val DEFAULT_LEARNING_REQUIRED_LECTURES = 0
        const val DEFAULT_LEARNING_MINIMUM_WATCHED_SHARE = 70
        const val DEFAULT_TASK_ENABLED = true
        const val DEFAULT_WALKING_REQUIRED_STEPS = 3000
        const val MIN_WALKING_REQUIRED_STEPS = 1000
        const val DEBUG_MIN_WALKING_REQUIRED_STEPS = 20
        const val WALKING_HISTORY_DAYS = 90
        const val DEFAULT_WALKING_CADENCE_THRESHOLD = 60

        private fun recomputeWatchedLectures(
            credits: Map<String, Long>,
            maxPositions: Map<String, Long>,
            durations: Map<String, Long>,
            minimumSharePercent: Int
        ): Set<String> {
            return durations.keys.filter { key ->
                val duration = durations[key] ?: 0L
                duration > 0L &&
                    (maxPositions[key] ?: 0L) * 100L >= duration * 90L &&
                    (credits[key] ?: 0L) * 100L >= duration * minimumSharePercent
            }.toSet()
        }

        private fun parseLectureValues(values: Set<String>): Map<String, Long> =
            values.mapNotNull { value ->
                val parts = value.split('=', limit = 2)
                if (parts.size != 2 || parts[0].isBlank()) return@mapNotNull null
                val seconds = parts[1].toLongOrNull() ?: return@mapNotNull null
                parts[0] to seconds
            }.toMap()

        private fun parseLectureCredits(values: Set<String>): Map<String, Long> =
            parseLectureValues(values)

        // History is stored as "date,steps,seconds" entries separated by ';'.
        private fun parseWalkingHistory(raw: String?): MutableMap<String, WalkingDayRecord> {
            val records = linkedMapOf<String, WalkingDayRecord>()
            if (raw.isNullOrBlank()) return records
            raw.split(';').forEach { entry ->
                val parts = entry.split(',')
                if (parts.size != 3) return@forEach
                val date = parts[0]
                val steps = parts[1].toLongOrNull() ?: return@forEach
                val seconds = parts[2].toLongOrNull() ?: return@forEach
                if (runCatching { LocalDate.parse(date) }.isFailure) return@forEach
                records[date] = WalkingDayRecord(date, steps, seconds)
            }
            return records
        }

        private fun serializeWalkingHistory(records: Collection<WalkingDayRecord>): String =
            records.joinToString(";") { "${it.date},${it.steps},${it.walkingSeconds}" }

        private fun pruneWalkingHistory(
            records: Collection<WalkingDayRecord>,
            today: LocalDate
        ): List<WalkingDayRecord> {
            val cutoff = today.minusDays(WALKING_HISTORY_DAYS - 1L).toString() // ISO dates sort as text
            return records.filter { it.date >= cutoff }.sortedBy { it.date }
        }
    }
}

data class StoredSettings(
    val scheduleEnabled: Boolean,
    val startMinutes: Int,
    val lockActive: Boolean,
    val emergencyUntil: Long
)

data class LearningSettings(
    val startUrl: String,
    val requiredMinutes: Int,
    val requiredLectures: Int,
    val debugEnabled: Boolean,
    val minimumWatchedShare: Int,
    val enabled: Boolean = true
)

data class WalkingSettings(
    val enabled: Boolean,
    val requiredSteps: Int,
    val cadenceThreshold: Int,
    val debugEnabled: Boolean
)

data class WalkingProgress(
    val date: String,
    val steps: Long,
    val creditedSeconds: Long
)

data class WalkingDayRecord(
    val date: String,
    val steps: Long,
    val walkingSeconds: Long
)

data class LearningProgress(
    val date: String,
    val creditsByLectureMs: Map<String, Long>,
    val maxPositionByLectureMs: Map<String, Long>,
    val watchedLectureIds: Set<String>
) {
    val creditedMillis: Long get() = creditsByLectureMs.values.sum()

    companion object {
        fun empty(date: String) = LearningProgress(date, emptyMap(), emptyMap(), emptySet())
    }
}
