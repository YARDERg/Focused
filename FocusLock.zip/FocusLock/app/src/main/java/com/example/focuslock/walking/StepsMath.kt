package com.example.focuslock.walking

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.max

data class DaySegment(val date: String, val startMs: Long, val endMs: Long)

object DayMath {
    fun dayStart(date: LocalDate, zone: ZoneId): Long = date.atStartOfDay(zone).toInstant().toEpochMilli()

    /** Start of the next local day (the exclusive end of [date]). */
    fun dayEnd(date: LocalDate, zone: ZoneId): Long = dayStart(date.plusDays(1), zone)

    fun dateOf(epochMs: Long, zone: ZoneId): LocalDate = Instant.ofEpochMilli(epochMs).atZone(zone).toLocalDate()

    /** Splits [startMs, endMs) at local midnights. Empty when the range is empty. */
    fun segments(startMs: Long, endMs: Long, zone: ZoneId): List<DaySegment> {
        if (endMs <= startMs) return emptyList()
        val out = ArrayList<DaySegment>()
        var cursor = startMs
        var date = dateOf(startMs, zone)
        while (cursor < endMs) {
            val dayEnd = dayEnd(date, zone)
            val segEnd = if (dayEnd < endMs) dayEnd else endMs
            out.add(DaySegment(date.toString(), cursor, segEnd))
            cursor = segEnd
            date = date.plusDays(1)
        }
        return out
    }
}

object HourMath {
    /** Start (epoch ms) of the local wall-clock hour containing [epochMs]; also right for zones with :30 offsets. */
    fun hourStart(epochMs: Long, zone: ZoneId): Long {
        val offsetMs = zone.rules.getOffset(Instant.ofEpochMilli(epochMs)).totalSeconds * 1000L
        return epochMs - Math.floorMod(epochMs + offsetMs, 3_600_000L)
    }
}

/** "2026-10-02:300,2026-10-03:200": the raw steps of one session split by local date. */
object RawByDay {
    fun encode(map: Map<String, Int>): String = map.entries.joinToString(",") { "${it.key}:${it.value}" }

    fun decode(raw: String): Map<String, Int> {
        val out = LinkedHashMap<String, Int>()
        for (part in raw.split(",")) {
            val i = part.lastIndexOf(':')
            if (i <= 0) continue
            val n = part.substring(i + 1).toIntOrNull() ?: continue
            out[part.substring(0, i)] = n
        }
        return out
    }
}

object DailyMath {
    /** Steps outside the session: whole-day raw minus the session raw steps of that day (never negative). */
    fun daily(dayRaw: Int, sessionRawOnDay: Int): Int = max(0, dayRaw - sessionRawOnDay)

    fun sessionRawOnDate(sessions: List<SessionRow>, date: String): Int =
        sessions.sumOf { RawByDay.decode(it.rawByDay)[date] ?: 0 }

    /** Re-read of the same data never lowers a value that was already stored (a failed or empty read keeps it). */
    fun mergeRaw(stored: Int, read: Int): Int = if (read <= 0 && stored > 0) stored else read
}

/** Hourly buckets are ONLY for charts and history; Daily never comes from them. */
object HourlyRollup {
    fun stepsByDate(hours: List<HourRow>, zone: ZoneId): Map<String, Int> {
        val out = LinkedHashMap<String, Int>()
        for (h in hours.sortedBy { it.hourStartEpoch }) {
            val d = DayMath.dateOf(h.hourStartEpoch, zone).toString()
            out[d] = (out[d] ?: 0) + h.rawSteps
        }
        return out
    }

    /** 24 values (local hour 0..23) for one date; hours without data are 0. */
    fun chartForDate(hours: List<HourRow>, date: String, zone: ZoneId): List<Int> {
        val out = IntArray(24)
        for (h in hours) {
            val t = Instant.ofEpochMilli(h.hourStartEpoch).atZone(zone)
            if (t.toLocalDate().toString() == date) out[t.hour] += h.rawSteps
        }
        return out.toList()
    }
}
