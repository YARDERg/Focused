package com.example.focuslock.data

import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class ScheduleRepository(private val dao: ScheduleOverrideDao) {

    suspend fun getOverride(moduleId: String, date: LocalDate): Int? =
        dao.get(moduleId, date.toString())?.minutes

    fun observeOverrides(moduleId: String): Flow<List<ScheduleOverrideEntity>> =
        dao.observeForModule(moduleId)

    suspend fun setOverride(moduleId: String, date: LocalDate, minutes: Int) =
        dao.upsert(ScheduleOverrideEntity(moduleId, date.toString(), minutes))

    suspend fun clearOverride(moduleId: String, date: LocalDate) =
        dao.deleteFor(moduleId, date.toString())

    suspend fun deleteOlderThan(date: LocalDate) = dao.deleteOlderThan(date.toString())
}
