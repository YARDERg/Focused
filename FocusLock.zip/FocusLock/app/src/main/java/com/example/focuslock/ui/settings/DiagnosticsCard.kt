package com.example.focuslock.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.focuslock.diag.Diagnostics
import com.example.focuslock.diag.DiagnosticsReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val PREVIEW_LINES = 14

/** Debug-only: last 5 crash traces, last 10 process exits and a "Copy all" button. */
@Composable
fun DiagnosticsCard() {
    val context = LocalContext.current
    var report by remember { mutableStateOf<DiagnosticsReport?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var copied by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    LaunchedEffect(tick) {
        report = withContext(Dispatchers.IO) { Diagnostics.collect(context.applicationContext) }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Crash diagnostics", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val text = report?.asText().orEmpty()
                        copied = copyToClipboard(context, text)
                    },
                    enabled = report != null,
                ) { Text("Copy all") }
                TextButton(onClick = { copied = false; tick++ }) { Text("Refresh") }
            }
            if (copied) Text("Copied to clipboard.", style = MaterialTheme.typography.bodySmall)

            val r = report
            if (r == null) {
                Text("Loading...", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("Last crashes (up to 5)", style = MaterialTheme.typography.titleSmall)
                if (r.crashes.isEmpty()) Text("None recorded.", style = MaterialTheme.typography.bodySmall)
                r.crashes.forEach { crash ->
                    HorizontalDivider()
                    val lines = crash.lines()
                    Text(
                        text = lines.take(PREVIEW_LINES).joinToString("\n") +
                            if (lines.size > PREVIEW_LINES) "\n... (full text in Copy all)" else "",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                    )
                }
                HorizontalDivider()
                Text("Last process exits (up to 10)", style = MaterialTheme.typography.titleSmall)
                r.exits.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String): Boolean = try {
    val cm = context.getSystemService(ClipboardManager::class.java)
    cm.setPrimaryClip(ClipData.newPlainText("Focus Lock diagnostics", text))
    true
} catch (_: Exception) {
    false
}
