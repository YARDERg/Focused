package com.example.focuslock.learning

import com.example.focuslock.data.ActivityLogEntity
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.LearningDao
import com.example.focuslock.data.LearningDayEntity
import com.example.focuslock.data.LearningLectureEntity
import com.example.focuslock.domain.LogSource
import com.example.focuslock.modules.ModuleIds

class RoomStudyStore(private val dao: LearningDao) : StudyStore {

    override suspend fun loadDay(date: String): DayRecord? =
        dao.getDay(date)?.let { DayRecord(it.creditedMs, it.requirementNotified) }

    override suspend fun loadLectures(date: String): List<LectureState> =
        dao.getLectures(date).map {
            LectureState(it.lectureKey, it.creditedMs, it.maxPositionSec, it.durationSec, it.watched)
        }

    override suspend fun saveDay(date: String, record: DayRecord) {
        dao.upsertDay(LearningDayEntity(date, record.creditedMs, record.requirementNotified))
    }

    override suspend fun saveLectures(date: String, lectures: List<LectureState>) {
        if (lectures.isEmpty()) return
        dao.upsertLectures(
            lectures.map {
                LearningLectureEntity(date, it.key, it.creditedMs, it.maxPositionSec, it.durationSec, it.watched)
            }
        )
    }
}

/** One ActivityLog row per study episode: source "study", durationSeconds = credited delta, items = newly watched lectures. */
class ActivityLogStudySink(private val logs: ActivityLogRepository) : StudyLogSink {
    override suspend fun writeStudyRow(date: String, startedAt: Long, endedAt: Long, durationSeconds: Long, newlyWatched: Int) {
        logs.insertAll(
            listOf(
                ActivityLogEntity(
                    moduleId = ModuleIds.LEARNING,
                    date = date,
                    startedAt = startedAt,
                    endedAt = endedAt,
                    durationSeconds = durationSeconds,
                    steps = null,
                    items = newlyWatched,
                    source = LogSource.STUDY,
                )
            )
        )
    }
}
