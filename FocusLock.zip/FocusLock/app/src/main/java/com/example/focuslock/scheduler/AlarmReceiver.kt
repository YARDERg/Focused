package com.example.focuslock.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.focuslock.FocusLockApp
import com.example.focuslock.lock.LockForegroundService
import com.example.focuslock.lock.LockLauncher
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_FIRE) return
        val moduleId = intent.getStringExtra(AlarmScheduler.EXTRA_MODULE_ID) ?: return
        val triggerAt = intent.getLongExtra(AlarmScheduler.EXTRA_TRIGGER_AT, System.currentTimeMillis())
        val app = context.applicationContext as FocusLockApp
        val pending = goAsync()
        app.container.scope.launch {
            try {
                handleFire(app, moduleId, triggerAt)
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun handleFire(app: FocusLockApp, moduleId: String, triggerAt: Long) {
        val c = app.container
        // The trigger's own date (not "now"), so a late delivery after midnight cannot swallow tomorrow.
        val date = Instant.ofEpochMilli(triggerAt).atZone(ZoneId.systemDefault()).toLocalDate()
        c.settings.setLastFired(moduleId, date.toString())
        c.schedules.clearOverride(moduleId, date)       // override is one-day: gone once the session fired
        if (c.settings.isModuleEnabled(moduleId) && c.sessions.startSession(moduleId)) {
            LockForegroundService.start(app)
            LockLauncher.launch(app)
        }
        c.scheduler.schedule(moduleId)                  // next occurrence
    }
}
