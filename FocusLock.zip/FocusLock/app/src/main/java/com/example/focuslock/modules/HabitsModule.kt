package com.example.focuslock.modules

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.focuslock.domain.FeatureModule
import com.example.focuslock.domain.SessionKind
import com.example.focuslock.domain.Task
import com.example.focuslock.scheduler.ScheduleDefaults

/** Empty-state placeholder. It never locks and has no schedule; user-defined habits arrive later. */
class HabitsModule : FeatureModule {
    override val id: String = ModuleIds.HABITS
    override val title: String = "Habits"
    override val defaultScheduleMinutes: Int = ScheduleDefaults.LEARNING_MINUTES
    override val locksPhoneOnSchedule: Boolean = false
    override val iconEmoji: String = "✅"

    override fun createTasks(kind: SessionKind): List<Task> = emptyList()

    @Composable
    override fun Screen() {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("No habits yet", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Your own AI-verified habits will live here in a later stage.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
            )
        }
    }
}
