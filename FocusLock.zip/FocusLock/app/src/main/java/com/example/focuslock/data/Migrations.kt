package com.example.focuslock.data

import androidx.room3.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL

/**
 * 1 -> 2: adds the Learning tables. Existing tables (activity_log, schedule_override) are untouched, so all
 * older data is kept. The DDL must match the entities exactly (Room validates the schema when opening).
 */
val MIGRATION_1_2: Migration = object : Migration(1, 2) {
    override suspend fun migrate(connection: SQLiteConnection) {
        connection.execSQL(
            "CREATE TABLE IF NOT EXISTS `learning_day` (" +
                "`date` TEXT NOT NULL, " +
                "`creditedMs` INTEGER NOT NULL, " +
                "`requirementNotified` INTEGER NOT NULL, " +
                "PRIMARY KEY(`date`))"
        )
        connection.execSQL(
            "CREATE TABLE IF NOT EXISTS `learning_lecture` (" +
                "`date` TEXT NOT NULL, " +
                "`lectureKey` TEXT NOT NULL, " +
                "`creditedMs` INTEGER NOT NULL, " +
                "`maxPositionSec` REAL NOT NULL, " +
                "`durationSec` REAL NOT NULL, " +
                "`watched` INTEGER NOT NULL, " +
                "PRIMARY KEY(`date`, `lectureKey`))"
        )
    }
}

/**
 * 2 -> 3: adds the Walking tables. activity_log, schedule_override and the Learning tables are untouched, so all older
 * data is kept. The DDL must match the entities exactly (Room validates the schema when opening).
 */
val MIGRATION_2_3: Migration = object : Migration(2, 3) {
    override suspend fun migrate(connection: SQLiteConnection) {
        connection.execSQL(
            "CREATE TABLE IF NOT EXISTS `steps_hour` (" +
                "`hourStartEpoch` INTEGER NOT NULL, " +
                "`rawSteps` INTEGER NOT NULL, " +
                "PRIMARY KEY(`hourStartEpoch`))"
        )
        connection.execSQL(
            "CREATE TABLE IF NOT EXISTS `walk_session` (" +
                "`startEpochMs` INTEGER NOT NULL, " +
                "`endEpochMs` INTEGER NOT NULL, " +
                "`sessionSteps` INTEGER NOT NULL, " +
                "`sessionWalkingMs` INTEGER NOT NULL, " +
                "`sessionRawSteps` INTEGER NOT NULL, " +
                "`rawByDay` TEXT NOT NULL, " +
                "`ignoredSteps` INTEGER NOT NULL, " +
                "`rawRefreshedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`startEpochMs`))"
        )
        connection.execSQL(
            "CREATE TABLE IF NOT EXISTS `steps_day` (" +
                "`date` TEXT NOT NULL, " +
                "`requirementNotified` INTEGER NOT NULL, " +
                "`dayRawSteps` INTEGER NOT NULL, " +
                "`dailySteps` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`date`))"
        )
    }
}
