package com.example.focuslock.learning

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToLong

/** Everything the debug panel shows. */
data class StudyDebug(
    val url: String? = null,
    val lectureId: String? = null,
    val lectureSource: String = "-",
    val videoFound: Boolean = false,
    val currentSec: Double = 0.0,
    val durationSec: Double = 0.0,
    val lectureCreditedMs: Long = 0L,
    val lectureCreditedPercent: Int = 0,
    val maxPositionSec: Double = 0.0,
    val countsAsWatched: Boolean = false,
    val watchedReason: String = "-",
    val totalCreditedTodayMs: Long = 0L,
    val playbackRate: Double = 1.0,
    val lastMediaDeltaMs: Long = 0L,
    val lastWallDeltaMs: Long = 0L,
    val lastSkipReason: String = "-",
)

/**
 * Turns video samples into ledger credit. Pure Kotlin (time and screen state are passed in), so the whole
 * sampling rule is covered by JVM tests.
 */
class StudyTracker(
    private val ledger: StudyLedger,
    private val minSharePercent: () -> Int,
) {
    private data class Prev(val currentSec: Double, val atMs: Long, val key: String)

    private var prev: Prev? = null
    private var lastSkip: String = "-"

    private val _debug = MutableStateFlow(StudyDebug())
    val debug: StateFlow<StudyDebug> = _debug.asStateFlow()

    /** Forget the previous sample (study view paused, page changed, JavaScript failed). */
    fun reset() {
        prev = null
    }

    suspend fun onSample(
        sample: VideoSample?,
        url: String?,
        title: String?,
        wallNowMs: Long,
        interactive: Boolean,
        resumed: Boolean,
    ) {
        if (sample == null) {
            prev = null
            lastSkip = "javascript sample failed"
            _debug.value = _debug.value.copy(url = url, lastSkipReason = lastSkip)
            return
        }
        if (!sample.found) {
            prev = null
            lastSkip = "no video on the page"
            _debug.value = _debug.value.copy(
                url = url,
                lectureId = LectureId.fromUrl(url),
                videoFound = false,
                lastSkipReason = lastSkip,
                totalCreditedTodayMs = ledger.snapshot.value.creditedMs,
            )
            return
        }

        val lecture = LectureKeys.resolve(url, sample.durationSec, title)
        val p = prev
        val sameLecture = p != null && p.key == lecture.key
        var mediaDeltaMs = 0L
        var wallDeltaMs = 0L
        if (p != null && sameLecture) {
            mediaDeltaMs = ((sample.currentSec - p.currentSec) * 1000.0).roundToLong()
            wallDeltaMs = wallNowMs - p.atMs
        }
        prev = Prev(sample.currentSec, wallNowMs, lecture.key)

        val decision = if (sameLecture) {
            CreditCalculator.credit(
                mediaDeltaMs = mediaDeltaMs,
                wallDeltaMs = wallDeltaMs,
                playbackRate = sample.playbackRate,
                interactive = interactive,
                resumed = resumed,
                playing = sample.playing,
            )
        } else {
            CreditDecision(0L, "first sample of this lecture")
        }
        if (decision.skipReason != null) lastSkip = decision.skipReason

        val state = ledger.record(lecture.key, decision.creditedMs, sample.currentSec, sample.durationSec)
        val verdict = WatchedRule.evaluate(state.maxPositionSec, state.durationSec, state.creditedMs, minSharePercent())
        val pct = if (state.durationSec > 0.0) (state.creditedMs / (state.durationSec * 1000.0) * 100.0).toInt() else 0
        _debug.value = StudyDebug(
            url = url,
            lectureId = lecture.lectureId,
            lectureSource = lecture.source,
            videoFound = true,
            currentSec = sample.currentSec,
            durationSec = sample.durationSec,
            lectureCreditedMs = state.creditedMs,
            lectureCreditedPercent = pct,
            maxPositionSec = state.maxPositionSec,
            countsAsWatched = state.watched,
            watchedReason = if (state.watched && !verdict.watched) "watched earlier today" else verdict.reason,
            totalCreditedTodayMs = ledger.snapshot.value.creditedMs,
            playbackRate = sample.playbackRate,
            lastMediaDeltaMs = mediaDeltaMs,
            lastWallDeltaMs = wallDeltaMs,
            lastSkipReason = lastSkip,
        )
    }
}
