package com.example.focuslock.domain.session

data class PersistedTask(val moduleId: String, val taskId: String)

data class PersistedSession(
    val moduleStarts: Map<String, Long>,
    val tasks: List<PersistedTask>,
    val completed: Set<String>,
)

/** Plain-string encoding for the DataStore session keys. Ids must not contain , | @ */
object SessionCodec {

    fun encodeModules(starts: Map<String, Long>): String =
        starts.entries.joinToString(",") { "${it.key}@${it.value}" }

    fun encodeTasks(tasks: List<PersistedTask>): String =
        tasks.joinToString(",") { "${it.moduleId}|${it.taskId}" }

    fun encodeCompleted(completed: Set<String>): String = completed.joinToString(",")

    fun decode(modules: String?, tasks: String?, completed: String?): PersistedSession? {
        if (modules.isNullOrBlank()) return null
        val starts = LinkedHashMap<String, Long>()
        for (part in modules.split(",")) {
            val i = part.lastIndexOf('@')
            if (i <= 0) continue
            val millis = part.substring(i + 1).toLongOrNull() ?: continue
            starts[part.substring(0, i)] = millis
        }
        if (starts.isEmpty()) return null
        val taskList = tasks.orEmpty().split(",").mapNotNull { part ->
            val i = part.indexOf('|')
            if (i > 0 && i < part.length - 1) PersistedTask(part.substring(0, i), part.substring(i + 1)) else null
        }
        val done = completed.orEmpty().split(",").filter { it.isNotBlank() }.toSet()
        return PersistedSession(starts, taskList, done)
    }
}
