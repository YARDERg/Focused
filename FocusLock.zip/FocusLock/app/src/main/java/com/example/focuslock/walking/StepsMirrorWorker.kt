package com.example.focuslock.walking

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.focuslock.FocusLockApp
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

/** Periodic (every 3 h) mirror of the Recording API data into Room. Subscribes first (a no-op when already subscribed). */
class StepsMirrorWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val hub = (applicationContext as FocusLockApp).container.walking
            hub.onAppEvent()
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            Result.success()        // never retry-storm; the next period tries again
        }
    }

    companion object {
        private const val UNIQUE_NAME = "steps_mirror"

        fun schedule(context: Context) {
            try {
                val request = PeriodicWorkRequestBuilder<StepsMirrorWorker>(WalkingDefaults.MIRROR_PERIOD_HOURS, TimeUnit.HOURS).build()
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
            } catch (_: Throwable) {
                // WorkManager not available: app-open and session mirrors still run.
            }
        }
    }
}
