package com.example.focuslock.domain

import java.time.ZonedDateTime

/** 12-hour AM/PM formatting that does not depend on the device locale. */
object TimeFormat {
    fun format12h(minutesOfDay: Int): String {
        val m = ((minutesOfDay % 1440) + 1440) % 1440
        val h24 = m / 60
        val minute = m % 60
        val suffix = if (h24 < 12) "AM" else "PM"
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        return "$h12:${minute.toString().padStart(2, '0')} $suffix"
    }

    fun format12h(time: ZonedDateTime): String = format12h(time.hour * 60 + time.minute)
}
