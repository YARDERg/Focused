package com.example.focuslock.learning

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.SessionKind
import com.example.focuslock.lock.LockForegroundService
import com.example.focuslock.lock.LockLauncher
import com.example.focuslock.modules.ModuleIds
import kotlinx.coroutines.launch

/** Extra card of the Learning page: today's study progress and the optional-session button. */
@Composable
fun LearningPageCard(container: AppContainer) {
    val hub = container.learning
    val appContext = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val day by hub.ledger.snapshot.collectAsState()
    val session by container.sessions.session.collectAsState()
    var error by remember { mutableStateOf<String?>(null) }
    RefreshDayEffect(hub)

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Study", style = MaterialTheme.typography.labelLarge)
            Text(
                "Today: ${day.creditedMinutes} min studied, lectures ${day.lecturesWatched}",
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                "An optional session has no time target: it just records the time you spend watching lectures.",
                style = MaterialTheme.typography.bodySmall,
            )
            Button(
                onClick = {
                    error = null
                    scope.launch {
                        if (container.sessions.session.value != null) return@launch
                        val started = container.sessions.startSession(ModuleIds.LEARNING, SessionKind.OPTIONAL)
                        if (started) {
                            hub.requestOpenStudy()
                            LockForegroundService.start(appContext)
                            LockLauncher.launch(appContext)
                        } else {
                            error = "Could not start a learning session."
                        }
                    }
                },
                enabled = session == null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Start learning session") }
            if (session != null) {
                Text(
                    "A lock session is already active. Finish it (Unlock) before starting an optional learning session.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}
