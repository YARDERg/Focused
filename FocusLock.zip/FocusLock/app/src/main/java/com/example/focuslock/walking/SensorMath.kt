package com.example.focuslock.walking

import kotlin.math.min

/**
 * Turns TYPE_STEP_COUNTER readings (steps since boot) into step deltas. The first reading sets the baseline (so
 * steps taken before the session never count). A value lower than the previous one means the counter restarted
 * (reboot): the baseline is rebased and the new value counts as steps since the restart.
 */
class SensorBaseline {
    private var last: Float = Float.NaN

    var rebases: Int = 0
        private set

    val lastRaw: Float get() = last

    fun reset() {
        last = Float.NaN
    }

    /** Steps since the previous reading (0 for the very first reading). */
    fun delta(raw: Float): Int {
        if (raw.isNaN()) return 0
        if (last.isNaN()) {
            last = raw
            return 0
        }
        val d = if (raw < last) {
            rebases++
            raw.toInt().coerceAtLeast(0)
        } else {
            (raw - last).toInt()
        }
        last = raw
        return d
    }
}

object StepSpreader {
    /**
     * The sensor may report several steps in one event. The cadence rule needs timestamps, so n steps are spread
     * evenly over the (capped) time since the previous event; the last one is at [curMs].
     */
    fun spread(prevMs: Long, curMs: Long, n: Int, capMs: Long = WalkingDefaults.SPREAD_CAP_MS): List<Long> {
        if (n <= 0) return emptyList()
        if (n == 1) return listOf(curMs)
        val span = if (prevMs < 0L) 0L else min((curMs - prevMs).coerceAtLeast(0L), capMs)
        val start = curMs - span
        return (1..n).map { k -> start + span * k / n }
    }
}
