package com.example.focuslock.walking

import kotlin.math.max
import kotlin.math.min

enum class CadenceStatus { WALKING, NOT_WALKING, TOO_FAST }

data class CadenceState(
    val countedSteps: Int,
    val ignoredSteps: Int,
    val walkingMs: Long,
    /** Trailing cadence in steps per minute (steps that are not flagged as ignored, over the trailing window). */
    val cadencePerMin: Int,
    val status: CadenceStatus,
    /** Steps inside the window that are neither counted nor ignored yet (they may be credited retroactively). */
    val pendingSteps: Int,
    val lastSkipReason: String,
)

/**
 * The anti-shake rule, pure and clock-free (every call passes the time).
 *
 *  - A trailing window ([windowMs], 30 s) of step timestamps is kept. cadence = non-ignored steps in the window x 60000 / windowMs.
 *  - WALKING when thresholdPerMin <= cadence <= maxPerMin: steps are credited. The moment the cadence FIRST qualifies,
 *    the buffered (pending) window steps are credited once; afterwards each step is credited when it arrives.
 *  - Steps that arrive while the cadence is below the threshold stay pending; when they leave the window uncredited
 *    they become IGNORED. Above the maximum (in the window, or in the short window) steps are IGNORED at once.
 *  - Walking time: every evaluation credits the elapsed time (capped at [gapCapMs]) when the previous evaluation was WALKING.
 */
class CadenceCounter(
    private val thresholdPerMin: Int,
    private val maxPerMin: Int = WalkingDefaults.MAX_CADENCE,
    private val windowMs: Long = WalkingDefaults.WINDOW_MS,
    private val shortWindowMs: Long = WalkingDefaults.SHORT_WINDOW_MS,
    private val gapCapMs: Long = WalkingDefaults.GAP_CAP_MS,
) {
    private enum class S { PENDING, COUNTED, IGNORED }
    private class Entry(val t: Long, var s: S)

    private val window = ArrayDeque<Entry>()
    private var counted = 0
    private var ignored = 0
    private var walkingMs = 0L
    private var lastAt = -1L
    private var status = CadenceStatus.NOT_WALKING
    private var skip = ""

    /** Starts from saved totals (the window itself is not persisted: it refills in a few seconds). */
    fun restore(countedSteps: Int, ignoredSteps: Int, walkingMs: Long) {
        counted = countedSteps.coerceAtLeast(0)
        ignored = ignoredSteps.coerceAtLeast(0)
        this.walkingMs = walkingMs.coerceAtLeast(0L)
        window.clear()
        lastAt = -1L
        status = CadenceStatus.NOT_WALKING
    }

    /** One step at [nowMs]. Returns how many steps this call credited (0, 1, or the whole buffered window). */
    fun onStep(nowMs: Long): Int {
        val t = max(nowMs, lastAt)
        advanceInternal(t)
        window.addLast(Entry(t, S.PENDING))
        evaluate(t)
        var credited = 0
        when (status) {
            CadenceStatus.TOO_FAST -> {
                var n = 0
                for (e in window) if (e.s == S.PENDING) { e.s = S.IGNORED; n++ }
                if (n > 0) {
                    ignored += n
                    skip = "cadence above $maxPerMin/min: $n step(s) ignored"
                }
            }
            CadenceStatus.WALKING -> {
                for (e in window) if (e.s == S.PENDING) { e.s = S.COUNTED; credited++ }
                counted += credited
            }
            CadenceStatus.NOT_WALKING -> Unit      // stays pending; may be credited retroactively or expire
        }
        return credited
    }

    /** Time passes without a step (call about once per second). */
    fun advance(nowMs: Long) {
        advanceInternal(max(nowMs, lastAt))
    }

    fun state(): CadenceState {
        val valid = window.count { it.s != S.IGNORED }
        return CadenceState(
            countedSteps = counted,
            ignoredSteps = ignored,
            walkingMs = walkingMs,
            cadencePerMin = (valid * 60_000.0 / windowMs).toInt(),
            status = status,
            pendingSteps = window.count { it.s == S.PENDING },
            lastSkipReason = skip,
        )
    }

    private fun advanceInternal(now: Long) {
        if (lastAt < 0L) {
            lastAt = now
            return
        }
        val dt = (now - lastAt).coerceAtLeast(0L)
        if (dt > gapCapMs) skip = "gap of $dt ms: walking time capped at $gapCapMs ms"
        if (status == CadenceStatus.WALKING) walkingMs += min(dt, gapCapMs)
        lastAt = now
        expire(now)
        evaluate(now)
    }

    private fun expire(now: Long) {
        var expiredPending = 0
        while (window.isNotEmpty() && window.first().t <= now - windowMs) {
            val e = window.removeFirst()
            if (e.s == S.PENDING) expiredPending++
        }
        if (expiredPending > 0) {
            ignored += expiredPending
            skip = "cadence below $thresholdPerMin/min: $expiredPending step(s) ignored"
        }
    }

    private fun evaluate(now: Long) {
        val all = window.size
        val valid = window.count { it.s != S.IGNORED }
        val cadence = valid * 60_000.0 / windowMs
        val allCadence = all * 60_000.0 / windowMs
        val shortCadence = if (shortWindowMs > 0L) {
            window.count { it.t > now - shortWindowMs } * 60_000.0 / shortWindowMs
        } else {
            0.0
        }
        status = when {
            allCadence > maxPerMin || shortCadence > maxPerMin -> CadenceStatus.TOO_FAST
            cadence >= thresholdPerMin -> CadenceStatus.WALKING
            else -> CadenceStatus.NOT_WALKING
        }
    }
}
