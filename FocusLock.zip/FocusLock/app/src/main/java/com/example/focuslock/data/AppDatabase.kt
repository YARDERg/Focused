package com.example.focuslock.data

import android.content.Context
import androidx.room3.Database
import androidx.room3.Room
import androidx.room3.RoomDatabase
import androidx.sqlite.driver.bundled.BundledSQLiteDriver
import kotlinx.coroutines.Dispatchers

/**
 * Version 3. Stage 2 added learning_day and learning_lecture ([MIGRATION_1_2]); Stage 3 adds steps_hour, walk_session and
 * steps_day ([MIGRATION_2_3]). For the next table: add the entity, bump `version`, and add a Migration (never destructive:
 * older data must survive).
 */
@Database(
    entities = [
        ActivityLogEntity::class,
        ScheduleOverrideEntity::class,
        LearningDayEntity::class,
        LearningLectureEntity::class,
        StepsHourEntity::class,
        WalkSessionEntity::class,
        StepsDayEntity::class,
    ],
    version = 3,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun activityLogDao(): ActivityLogDao
    abstract fun scheduleOverrideDao(): ScheduleOverrideDao
    abstract fun learningDao(): LearningDao
    abstract fun stepsDao(): StepsDao
}

fun buildDatabase(context: Context): AppDatabase {
    val appContext = context.applicationContext
    val dbFile = appContext.getDatabasePath("focuslock.db")
    return Room.databaseBuilder<AppDatabase>(
        context = appContext,
        name = dbFile.absolutePath,
    )
        .setDriver(BundledSQLiteDriver())
        .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
        .setQueryCoroutineContext(Dispatchers.IO)
        .build()
}
