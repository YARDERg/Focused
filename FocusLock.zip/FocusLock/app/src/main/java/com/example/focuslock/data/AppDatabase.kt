package com.example.focuslock.data

import android.content.Context
import androidx.room3.Database
import androidx.room3.Room
import androidx.room3.RoomDatabase
import androidx.sqlite.driver.bundled.BundledSQLiteDriver
import kotlinx.coroutines.Dispatchers

/**
 * Version 2 (Stage 2 adds learning_day and learning_lecture, see [MIGRATION_1_2]). For the next table: add the
 * entity, bump `version`, and add a Migration (never destructive: older data must survive).
 */
@Database(
    entities = [
        ActivityLogEntity::class,
        ScheduleOverrideEntity::class,
        LearningDayEntity::class,
        LearningLectureEntity::class,
    ],
    version = 2,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun activityLogDao(): ActivityLogDao
    abstract fun scheduleOverrideDao(): ScheduleOverrideDao
    abstract fun learningDao(): LearningDao
}

fun buildDatabase(context: Context): AppDatabase {
    val appContext = context.applicationContext
    val dbFile = appContext.getDatabasePath("focuslock.db")
    return Room.databaseBuilder<AppDatabase>(
        context = appContext,
        name = dbFile.absolutePath,
    )
        .setDriver(BundledSQLiteDriver())
        .addMigrations(MIGRATION_1_2)
        .setQueryCoroutineContext(Dispatchers.IO)
        .build()
}
