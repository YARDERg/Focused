package com.example.focuslock.learning

import android.annotation.SuppressLint
import android.content.Context
import android.os.Message
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

private const val TAG = "StudyView"

/**
 * Samples the main <video> (and same-origin iframes). Returns "0" (no video) or
 * "1|paused|ended|currentTime|duration|playbackRate" with plain numbers, so no JSON escaping is involved.
 */
private const val VIDEO_SAMPLE_JS = """(function(){try{
function scan(doc,depth){var out=[];var vs=doc.getElementsByTagName('video');
for(var i=0;i<vs.length;i++){out.push(vs[i]);}
if(depth<3){var fs=doc.getElementsByTagName('iframe');
for(var j=0;j<fs.length;j++){try{var d=fs[j].contentDocument;if(d){out=out.concat(scan(d,depth+1));}}catch(e){}}}
return out;}
var vs=scan(document,0);
if(!vs.length){return '0|videos=0';}
var best=null;var bestScore=-1;
for(var k=0;k<vs.length;k++){var v=vs[k];
var dur=isFinite(v.duration)?v.duration:0;
var score=((!v.paused&&!v.ended)?1000000000:0)+dur;
if(score>bestScore){best=v;bestScore=score;}}
var d2=isFinite(best.duration)?best.duration:0;
var err=best.error?best.error.code:0;
var hasSrc=(best.currentSrc&&best.currentSrc.length>0)?1:0;
return '1|'+(best.paused?1:0)+'|'+(best.ended?1:0)+'|'+best.currentTime+'|'+d2+'|'+best.playbackRate+'|'+best.readyState+'|'+best.networkState+'|'+err+'|'+hasSrc+'|'+vs.length;
}catch(e){return '0|js-error';}})()"""

private class StudyWebViewClient(
    private val onVisited: (url: String, canGoBack: Boolean) -> Unit,
    private val onBlocked: (url: String) -> Unit,
    private val onCrashed: () -> Unit,
) : WebViewClient() {

    /** Allowlist: udemy.com, *.udemy.com, udemycdn.com. Everything else is blocked (true = handled = not loaded). */
    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val url = request?.url?.toString() ?: return true
        val allowed = HostAllowlist.isAllowedUrl(url)
        if (!allowed) onBlocked(url)
        return !allowed
    }

    /** Fires for classic loads and for single-page-app (pushState) navigations. */
    override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
        super.doUpdateVisitedHistory(view, url, isReload)
        if (url != null) onVisited(url, view?.canGoBack() == true)
    }

    override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
        onCrashed()
        return true     // keep the app alive; the UI offers "Back to lock" and reopening
    }
}

/** Blocks window.open / target=_blank: no new window is ever created. */
private class BlockingChromeClient : WebChromeClient() {
    override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean = false
}

@SuppressLint("SetJavaScriptEnabled")
private fun createStudyWebView(
    context: Context,
    startUrl: String,
    onVisited: (String, Boolean) -> Unit,
    onBlocked: (String) -> Unit,
    onCrashed: () -> Unit,
): WebView {
    val view = WebView(context)
    val s = view.settings
    // Deliberately the plain configuration: default user agent, default autoplay policy (the user taps play),
    // no multi-window support. This is the setup that is known to play Udemy video in this app's older build.
    s.javaScriptEnabled = true
    s.domStorageEnabled = true
    s.mediaPlaybackRequiresUserGesture = true
    s.setSupportMultipleWindows(false)          // window.open / target=_blank never create a window
    val cookies = CookieManager.getInstance()
    cookies.setAcceptCookie(true)                // cookies persist on disk; flushed when the view pauses
    cookies.setAcceptThirdPartyCookies(view, true)
    view.webViewClient = StudyWebViewClient(onVisited, onBlocked, onCrashed)
    view.webChromeClient = BlockingChromeClient()
    view.loadUrl(startUrl)
    return view
}

private suspend fun WebView.sampleVideoRaw(): String? = withTimeoutOrNull(LearningDefaults.EVAL_TIMEOUT_MS) {
    suspendCancellableCoroutine<String?> { cont ->
        evaluateJavascript(VIDEO_SAMPLE_JS) { result -> if (cont.isActive) cont.resume(result) }
    }
}

private fun fmt(x: Double): String = String.format(Locale.US, "%.1f", x)

private fun debugLines(d: StudyDebug, requiredMinutes: Int?): List<String> = listOf(
    "url: ${d.url ?: "-"}",
    "lecture id: ${d.lectureId ?: "none"} (source: ${d.lectureSource})",
    "video found: ${d.videoFound} ${d.videoDiag}",
    "time: ${fmt(d.currentSec)} / ${fmt(d.durationSec)} s, rate ${fmt(d.playbackRate)}",
    "lecture credited: ${d.lectureCreditedMs} ms (${d.lectureCreditedPercent}%), max pos ${fmt(d.maxPositionSec)} s",
    "counts as watched: ${d.countsAsWatched} (${d.watchedReason})",
    if (requiredMinutes != null) {
        "total credited today: ${d.totalCreditedTodayMs} ms of ${requiredMinutes * 60_000L} ms"
    } else {
        "total credited today: ${d.totalCreditedTodayMs} ms (no target)"
    },
    "last mediaDelta/wallDelta: ${d.lastMediaDeltaMs} / ${d.lastWallDeltaMs} ms",
    "last skip: ${d.lastSkipReason}",
)

/**
 * The one study screen used by both session kinds. It lives inside the lock activity's composition (no separate
 * Activity), so lock enforcement and the immediate relaunch keep working. After a relaunch it reloads the last
 * visited URL; progress comes from the ledger (Room), not from the page.
 */
@Composable
fun StudyView(
    hub: LearningHub,
    /** True for the scheduled task (shows "X / Y min"); false for the optional task (no target anywhere). */
    scheduled: Boolean,
    onBackToLock: () -> Unit,
    onOpened: () -> Unit,
    /** Optional sessions: credit earned since the session began, shown as "This session". */
    sessionCreditedMs: ((DaySnapshot) -> Long)? = null,
) {
    val context = LocalContext.current
    val config by hub.config.collectAsState()
    val day by hub.ledger.snapshot.collectAsState()
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    var resumed by remember { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    val resumedNow by rememberUpdatedState(resumed)
    var canGoBack by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf<String?>(null) }
    val urlNow by rememberUpdatedState(currentUrl)
    var blockedHost by remember { mutableStateOf<String?>(null) }
    var crashed by remember { mutableStateOf(false) }

    val tracker = remember { StudyTracker(hub.ledger) { hub.config.value.minWatchedShare } }
    val debug by tracker.debug.collectAsState()

    val webView = remember {
        val c = hub.config.value
        createStudyWebView(
            context = context,
            startUrl = HostAllowlist.initialUrl(c.lastUrl, c.startUrl),
            onVisited = { url, back ->
                currentUrl = url
                canGoBack = back
                if (HostAllowlist.isAllowedUrl(url)) hub.saveLastUrlAsync(url)
            },
            onBlocked = { url -> blockedHost = HostAllowlist.hostOf(url) ?: url },
            onCrashed = { crashed = true },
        )
    }

    LaunchedEffect(Unit) { onOpened() }

    // Pause/resume the page with the activity, persist cookies, and flush the study episode on pause/stop/close.
    DisposableEffect(lifecycle, webView) {
        val observer = LifecycleEventObserver { _, event ->
            resumed = lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    CookieManager.getInstance().flush()
                    tracker.reset()
                    hub.flushAsync()
                }
                Lifecycle.Event.ON_STOP -> hub.flushAsync()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            hub.flushAsync()                      // study view closed
        }
    }

    DisposableEffect(webView) {
        onDispose {
            try {
                (webView.parent as? ViewGroup)?.removeView(webView)
                webView.stopLoading()
                webView.destroy()
            } catch (t: Throwable) {
                Log.w(TAG, "WebView cleanup failed: $t")
            }
        }
    }

    // Sampler: every 250 ms read the main <video> and hand the sample to the tracker.
    LaunchedEffect(webView) {
        val pm = context.getSystemService(PowerManager::class.java)
        while (isActive) {
            delay(LearningDefaults.SAMPLE_INTERVAL_MS)
            try {
                val raw = webView.sampleVideoRaw()
                val sample = VideoSampleParser.parse(raw)
                val now = SystemClock.elapsedRealtime()
                tracker.onSample(
                    sample = sample,
                    url = urlNow,
                    title = webView.title,
                    wallNowMs = now,
                    interactive = pm?.isInteractive ?: true,
                    resumed = resumedNow,
                )
                hub.ledger.persistIfDue()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                Log.w(TAG, "Sample failed: $t")
            }
        }
    }

    // System Back = page back (the lock activity itself swallows Back).
    BackHandler(enabled = true) {
        if (webView.canGoBack()) webView.goBack()
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedButton(
                onClick = { if (webView.canGoBack()) webView.goBack() },
                enabled = canGoBack,
            ) { Text("Page back") }
            Button(onClick = onBackToLock) { Text("Back to lock") }
            // Reserved, intentionally empty and hidden: slot for a future AI assistant icon (nothing built yet).
            Box(Modifier.size(0.dp))
        }
        Text(
            text = headerText(day, if (scheduled) config.requiredMinutes else null, sessionCreditedMs?.invoke(day)),
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        )
        blockedHost?.let {
            Text(
                "Blocked: $it (only Udemy pages are allowed)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
        }
        if (crashed) {
            Text(
                "The web view stopped. Press \"Back to lock\" and open the study view again.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
        }
        AndroidView(
            factory = {
                webView.apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        )
        if (config.debug) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 150.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 2.dp),
            ) {
                debugLines(debug, if (scheduled) config.requiredMinutes else null).forEach {
                    Text(it, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

/** Scheduled: "Today: X / Y min, lectures N". Optional: no target, "Today: X min, lectures N" (+ this session). */
internal fun headerText(day: DaySnapshot, requiredMinutes: Int?, sessionMs: Long?): String {
    val base = if (requiredMinutes != null) {
        "Today: ${day.creditedMinutes} / $requiredMinutes min, lectures ${day.lecturesWatched}"
    } else {
        "Today: ${day.creditedMinutes} min, lectures ${day.lecturesWatched}"
    }
    return if (sessionMs != null) "This session: ${sessionMs / 60_000L} min. $base" else base
}
