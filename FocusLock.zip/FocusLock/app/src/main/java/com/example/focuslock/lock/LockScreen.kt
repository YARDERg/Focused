package com.example.focuslock.lock

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.Task
import kotlinx.coroutines.launch

@Composable
fun LockScreen(
    container: AppContainer,
    onEmergencyCall: () -> Unit,
    onFinished: () -> Unit,
) {
    val sessions = container.sessions
    val ready by sessions.ready.collectAsState()
    val session by sessions.session.collectAsState()
    val progress by sessions.progress.collectAsState()
    val scope = rememberCoroutineScope()

    var fullScreenTaskId by remember { mutableStateOf<String?>(null) }
    var showDeveloperDialog by remember { mutableStateOf(false) }

    // Close once the session is gone (Unlock or developer exit). Wait for restore first.
    LaunchedEffect(ready, session) {
        if (ready && session == null) onFinished()
    }

    val current = session
    val fullScreenTask: Task? = current?.entries?.firstOrNull { it.task.id == fullScreenTaskId }?.task

    Surface(modifier = Modifier.fillMaxSize()) {
        if (fullScreenTask != null) {
            Box(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
                fullScreenTask.Content()
                TextButton(
                    onClick = { fullScreenTaskId = null },
                    modifier = Modifier.align(Alignment.TopEnd),
                ) { Text("Back to list") }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("Focus Lock", style = MaterialTheme.typography.headlineMedium)

                val titles = current?.moduleIds
                    ?.mapNotNull { container.registry.byId(it)?.title }
                    ?.joinToString(" + ")
                    .orEmpty()
                if (titles.isNotEmpty()) {
                    Text("Session: $titles", style = MaterialTheme.typography.titleMedium)
                }
                Text("${progress.done} / ${progress.total} completed", style = MaterialTheme.typography.titleLarge)

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(current?.entries?.map { it.task }.orEmpty(), key = { it.id }) { task ->
                        TaskRow(task = task, onOpenFullScreen = { fullScreenTaskId = task.id })
                    }
                    if (progress.isComplete) {
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Goals complete", style = MaterialTheme.typography.headlineSmall)
                                    Button(
                                        onClick = { scope.launch { sessions.unlock() } },
                                        modifier = Modifier.fillMaxWidth(),
                                    ) { Text("Unlock") }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(onClick = onEmergencyCall) { Text("Emergency Call") }
                    TextButton(onClick = { showDeveloperDialog = true }) { Text("Developer exit") }
                }
            }
        }
    }

    if (showDeveloperDialog) {
        DeveloperExitDialog(
            onDismiss = { showDeveloperDialog = false },
            onConfirmed = {
                showDeveloperDialog = false
                scope.launch { sessions.forceEnd() }
            },
        )
    }
}

@Composable
private fun TaskRow(task: Task, onOpenFullScreen: () -> Unit) {
    // Read the state in composition so the row recomposes when the task completes.
    val done by task.completed.collectAsState()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = if (done) "✓ ${task.title}" else task.title,
                style = MaterialTheme.typography.titleMedium,
            )
            if (task.hasFullScreenUi) {
                if (done) Text("Completed") else Button(onClick = onOpenFullScreen) { Text("Open") }
            } else {
                task.Content()
            }
        }
    }
}

@Composable
private fun DeveloperExitDialog(onDismiss: () -> Unit, onConfirmed: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Developer exit") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; wrong = false },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    isError = wrong,
                )
                if (wrong) Text("Wrong password", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (DeveloperPassword.matches(password)) onConfirmed() else wrong = true
            }) { Text("Exit") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
