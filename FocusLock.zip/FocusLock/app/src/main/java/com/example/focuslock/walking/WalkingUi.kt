package com.example.focuslock.walking

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.focuslock.AppContainer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun n(value: Int): String = NumberFormat.getIntegerInstance().format(value)

private val timeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

private fun timeText(epochMs: Long?): String =
    if (epochMs == null || epochMs <= 0L) "never" else timeFormat.format(Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault()))

/** ACTIVITY_RECOGNITION: runtime permission launcher, plus a settings shortcut once it is permanently denied. */
@Composable
fun WalkingPermissionCard(hub: WalkingHub) {
    val context = LocalContext.current
    val granted by hub.permissionGranted.collectAsState()
    val config by hub.config.collectAsState()
    val scope = rememberCoroutineScope()

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        scope.launch {
            hub.markPermissionAsked()
            hub.onPermissionChanged()          // re-subscribes (the registration is removed when the permission is lost)
        }
    }

    // Back from system settings: pick up a permission granted there (only acts on a change, so a lock relaunch is cheap).
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        val before = hub.permissionGranted.value
        val now = hub.hasPermission()
        if (now && !before) scope.launch { hub.onPermissionChanged() }
    }

    if (granted) {
        Text("Activity recognition: granted", style = MaterialTheme.typography.bodySmall)
        return
    }
    val permanent = WalkingPermissions.permanentlyDenied(WalkingPermissions.findActivity(context), config.permissionAsked)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Activity recognition: not granted", style = MaterialTheme.typography.titleMedium)
            Text(
                "Needed to count steps. Without it all-day tracking is off and the walking session cannot count steps.",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (permanent) {
                Button(onClick = {
                    try {
                        context.startActivity(WalkingPermissions.appSettingsIntent(context))
                    } catch (_: Exception) {
                    }
                }) { Text("Open app settings") }
            } else {
                Button(onClick = { launcher.launch(Manifest.permission.ACTIVITY_RECOGNITION) }) { Text("Allow activity recognition") }
            }
        }
    }
}

/** Debug panel (shown only while the global debug toggle is on). */
@Composable
fun WalkingDebugPanel(hub: WalkingHub) {
    val live by hub.tracker.live.collectAsState()
    val tracking by hub.tracking.collectAsState()
    val sub by hub.subscription.collectAsState()
    val newest by hub.newestPoint.collectAsState()
    val mirror by hub.lastMirror.collectAsState()
    val hours by hub.hoursToday.collectAsState()
    val playServices by hub.playServices.collectAsState()
    val zone = ZoneId.systemDefault()

    val hourly = hours.filter { it.rawSteps > 0 }.joinToString("  ") {
        "${Instant.ofEpochMilli(it.hourStartEpoch).atZone(zone).hour}h:${it.rawSteps}"
    }.ifEmpty { "none" }
    val s = MaterialTheme.typography.bodySmall

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Walking debug", style = MaterialTheme.typography.labelLarge)
            Text("Play services: $playServices", style = s)
            Text("All-day tracking: ${tracking.text}", style = s)
            Text("Subscription: ${if (sub.ok) "OK" else "not subscribed"} - ${sub.message} (${timeText(sub.atMs)})", style = s)
            Text("Newest data point: ${timeText(newest)}", style = s)
            Text(
                "Last mirror: ${timeText(mirror.atMs)} - ${if (mirror.ok) "OK" else "not ok"}: ${mirror.message} " +
                    "(hours ${mirror.hoursWritten}, days ${mirror.daysUpdated}, sessions ${mirror.sessionsRefreshed})",
                style = s,
            )
            Text("Today's hourly raw steps: $hourly", style = s)
            HorizontalDivider()
            Text("Sensor: ${live.sensor}, raw counter: ${if (live.rawCounter < 0f) "none" else live.rawCounter.toLong().toString()}", style = s)
            Text("Trailing cadence: ${live.cadence} steps/min (${live.status}), pending in window: ${live.pendingSteps}", style = s)
            Text("Counted (session) steps: ${live.sessionSteps}, ignored steps: ${live.ignoredSteps}", style = s)
            Text(
                "Session raw (Recording API): ${live.sessionRawSteps?.toString() ?: "?"} vs session counted: ${live.sessionSteps}",
                style = s,
            )
            Text("Last skip reason: ${live.lastSkipReason.ifEmpty { "-" }}", style = s)
        }
    }
}

@Composable
private fun TrackerCard(title: String, today: Int, month: Int, monthLabel: String, hint: String? = null) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Today", style = MaterialTheme.typography.labelMedium)
                    Text(n(today), style = MaterialTheme.typography.headlineSmall)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(monthLabel, style = MaterialTheme.typography.labelMedium)
                    Text(n(month), style = MaterialTheme.typography.titleLarge)
                }
            }
            if (hint != null) Text(hint, style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Walking page extras (shown under "Today's session"): status, permission, three trackers, last 7 days, debug. */
@Composable
fun WalkingPageCard(container: AppContainer) {
    val hub = container.walking
    val report by hub.report.collectAsState()
    val tracking by hub.tracking.collectAsState()
    val config by hub.config.collectAsState()

    // Refresh when the page opens and every 30 s while it is visible.
    LaunchedEffect(hub) {
        while (true) {
            hub.refreshToday()
            delay(30_000L)
        }
    }

    val monthLabel = java.time.YearMonth.now().month.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault())
    val dayFormat = DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault())

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("All-day tracking: ${tracking.text}", style = MaterialTheme.typography.titleMedium)
                if (!tracking.on) {
                    Text(
                        "Steps outside the session are not recorded while this is off. The walking session and the lock still work.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Text(
                    "Required session steps: ${config.requiredSteps}. Steps taken during the day never count toward the session.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        WalkingPermissionCard(hub)
        TrackerCard("Total steps", report.today.total, report.month.total, monthLabel, "Daily + session")
        TrackerCard("Scheduled session steps", report.today.session, report.month.session, monthLabel)
        TrackerCard("Daily steps (outside the session)", report.today.daily, report.month.daily, monthLabel)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Last 7 days", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth()) {
                    Text("Date", Modifier.weight(1.4f), style = MaterialTheme.typography.labelMedium)
                    Text("Daily", Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                    Text("Session", Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                    Text("Total", Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                }
                HorizontalDivider()
                for (row in report.last7) {
                    Row(Modifier.fillMaxWidth()) {
                        Text(row.date.format(dayFormat), Modifier.weight(1.4f), style = MaterialTheme.typography.bodyMedium)
                        Text(n(row.totals.daily), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(n(row.totals.session), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(n(row.totals.total), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        if (config.debug) WalkingDebugPanel(hub)
    }
}
