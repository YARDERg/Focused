package com.example.focuslock.scheduler

/** Stable, per-module PendingIntent request codes (pure, so it is unit tested). */
object AlarmCodes {
    private const val BASE = 4100
    fun requestCode(moduleId: String): Int = BASE + (moduleId.hashCode() and 0x3FFF)
}
