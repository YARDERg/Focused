package com.example.focuslock.learning

import kotlin.math.max
import kotlin.math.min

/** One reading of the page's main <video>. */
data class VideoSample(
    val found: Boolean,
    val paused: Boolean,
    val ended: Boolean,
    val currentSec: Double,
    val durationSec: Double,
    val playbackRate: Double,
) {
    val playing: Boolean get() = found && !paused && !ended

    companion object {
        val NONE = VideoSample(found = false, paused = true, ended = false, currentSec = 0.0, durationSec = 0.0, playbackRate = 1.0)
    }
}

object VideoSampleParser {
    /**
     * Parses the result of evaluateJavascript: a JSON string literal such as "\"1|0|0|12.5|600|1\"",
     * the string "0" (no video), or null/"null" (the script failed). Returns null when unusable.
     */
    fun parse(raw: String?): VideoSample? {
        if (raw == null) return null
        var text = raw.trim()
        if (text == "null" || text.isEmpty()) return null
        if (text.length >= 2 && text.startsWith("\"") && text.endsWith("\"")) {
            text = text.substring(1, text.length - 1)
        }
        if (text == "0") return VideoSample.NONE
        val parts = text.split('|')
        if (parts.size < 6 || parts[0] != "1") return null
        val current = parts[3].toDoubleOrNull() ?: return null
        val duration = parts[4].toDoubleOrNull() ?: 0.0
        val rate = parts[5].toDoubleOrNull() ?: 1.0
        return VideoSample(
            found = true,
            paused = parts[1] == "1",
            ended = parts[2] == "1",
            currentSec = if (current.isFinite() && current >= 0.0) current else 0.0,
            durationSec = if (duration.isFinite() && duration > 0.0) duration else 0.0,
            playbackRate = if (rate.isFinite() && rate > 0.0) rate else 1.0,
        )
    }
}

data class CreditDecision(val creditedMs: Long, val skipReason: String?)

object CreditCalculator {

    /**
     * Credits min(mediaDelta, wallDelta) only when the video is playing, the screen is interactive, the study
     * UI is resumed, mediaDelta > 0 and mediaDelta <= wallDelta * max(rate, 1) * 1.3 (so seeks and jumps earn
     * nothing). A single sample never credits more than [gapCapMs]. All values are milliseconds.
     */
    fun credit(
        mediaDeltaMs: Long,
        wallDeltaMs: Long,
        playbackRate: Double,
        interactive: Boolean,
        resumed: Boolean,
        playing: Boolean,
        gapCapMs: Long = LearningDefaults.GAP_CAP_MS,
    ): CreditDecision {
        if (!playing) return skip("video not playing")
        if (!resumed) return skip("study view not resumed")
        if (!interactive) return skip("screen not interactive")
        if (wallDeltaMs <= 0L) return skip("no wall time elapsed")
        if (mediaDeltaMs <= 0L) return skip("no media progress ($mediaDeltaMs ms)")
        val rate = if (playbackRate.isFinite()) max(playbackRate, 1.0) else 1.0
        val allowed = wallDeltaMs.toDouble() * rate * LearningDefaults.JITTER_FACTOR
        if (mediaDeltaMs.toDouble() > allowed) {
            return skip("jump: media $mediaDeltaMs ms in $wallDeltaMs ms wall")
        }
        val credited = min(min(mediaDeltaMs, wallDeltaMs), gapCapMs)
        return CreditDecision(credited, null)
    }

    private fun skip(reason: String) = CreditDecision(0L, reason)
}

data class WatchedVerdict(val watched: Boolean, val reason: String)

object WatchedRule {

    /**
     * Watched = max playhead >= 90% of the duration AND credited >= [minSharePercent]% of the duration.
     * Udemy's own completion checkbox is never used. Integer-friendly arithmetic avoids 0.9 rounding traps.
     */
    fun evaluate(maxPositionSec: Double, durationSec: Double, creditedMs: Long, minSharePercent: Int): WatchedVerdict {
        if (!(durationSec > 0.0)) return WatchedVerdict(false, "duration unknown")
        val positionOk = maxPositionSec * 100.0 >= durationSec * LearningDefaults.WATCHED_POSITION_PERCENT
        val creditOk = creditedMs.toDouble() * 100.0 >= durationSec * 1000.0 * minSharePercent
        val positionPct = (maxPositionSec / durationSec * 100.0).toInt()
        val creditPct = (creditedMs / (durationSec * 1000.0) * 100.0).toInt()
        return when {
            positionOk && creditOk -> WatchedVerdict(true, "position $positionPct% and credited $creditPct%")
            !positionOk && !creditOk -> WatchedVerdict(
                false, "position $positionPct% < ${LearningDefaults.WATCHED_POSITION_PERCENT}% and credited $creditPct% < $minSharePercent%",
            )
            !positionOk -> WatchedVerdict(false, "position $positionPct% < ${LearningDefaults.WATCHED_POSITION_PERCENT}%")
            else -> WatchedVerdict(false, "credited $creditPct% < $minSharePercent%")
        }
    }
}
