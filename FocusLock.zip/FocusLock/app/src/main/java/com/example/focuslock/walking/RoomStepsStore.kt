package com.example.focuslock.walking

import com.example.focuslock.data.ActivityLogEntity
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.StepsDao
import com.example.focuslock.data.StepsDayEntity
import com.example.focuslock.data.StepsHourEntity
import com.example.focuslock.data.WalkSessionEntity
import com.example.focuslock.domain.LogSource
import com.example.focuslock.modules.ModuleIds

class RoomStepsStore(private val dao: StepsDao) : StepsStore {

    override suspend fun upsertHours(rows: List<HourRow>) {
        if (rows.isNotEmpty()) dao.upsertHours(rows.map { StepsHourEntity(it.hourStartEpoch, it.rawSteps) })
    }

    override suspend fun hoursBetween(fromEpoch: Long, toEpochExclusive: Long): List<HourRow> =
        dao.hoursBetween(fromEpoch, toEpochExclusive).map { HourRow(it.hourStartEpoch, it.rawSteps) }

    override suspend fun getDay(date: String): DayRow? = dao.getDay(date)?.toRow()

    override suspend fun upsertDay(row: DayRow) {
        dao.upsertDay(StepsDayEntity(row.date, row.requirementNotified, row.dayRawSteps, row.dailySteps, row.updatedAt))
    }

    override suspend fun daysBetween(fromDate: String, toDate: String): List<DayRow> =
        dao.daysBetween(fromDate, toDate).map { it.toRow() }

    override suspend fun markNotified(date: String) {
        val existing = dao.getDay(date)
        dao.upsertDay(
            existing?.copy(requirementNotified = true)
                ?: StepsDayEntity(date, requirementNotified = true, dayRawSteps = 0, dailySteps = 0, updatedAt = 0L)
        )
    }

    override suspend fun upsertSession(row: SessionRow) {
        dao.upsertSession(
            WalkSessionEntity(
                row.startEpochMs, row.endEpochMs, row.sessionSteps, row.sessionWalkingMs,
                row.sessionRawSteps, row.rawByDay, row.ignoredSteps, row.rawRefreshedAt,
            )
        )
    }

    override suspend fun updateProgress(startEpochMs: Long, sessionSteps: Int, walkingMs: Long, ignoredSteps: Int) {
        dao.updateProgress(startEpochMs, sessionSteps, walkingMs, ignoredSteps)
    }

    override suspend fun getSession(startEpochMs: Long): SessionRow? = dao.getSession(startEpochMs)?.toRow()
    override suspend fun openSession(): SessionRow? = dao.openSession()?.toRow()
    override suspend fun deleteSession(startEpochMs: Long) = dao.deleteSession(startEpochMs)

    override suspend fun sessionsOverlapping(fromEpoch: Long, toEpochExclusive: Long): List<SessionRow> =
        dao.sessionsOverlapping(fromEpoch, toEpochExclusive).map { it.toRow() }

    override suspend fun sessionsEndedSince(sinceEpoch: Long): List<SessionRow> =
        dao.sessionsEndedSince(sinceEpoch).map { it.toRow() }

    override suspend fun sessionsStartedBetween(fromEpoch: Long, toEpochExclusive: Long): List<SessionRow> =
        dao.sessionsStartedBetween(fromEpoch, toEpochExclusive).map { it.toRow() }

    private fun StepsDayEntity.toRow() = DayRow(date, requirementNotified, dayRawSteps, dailySteps, updatedAt)

    private fun WalkSessionEntity.toRow() = SessionRow(
        startEpochMs, endEpochMs, sessionSteps, sessionWalkingMs, sessionRawSteps, rawByDay, ignoredSteps, rawRefreshedAt,
    )
}

/**
 * The ActivityLog ledger for Walking. Rows are keyed by (walking, source, startedAt) and updated in place, so mirror
 * runs never create duplicates. "walk_daily": startedAt = start of the day, steps = Daily. "walk_session": startedAt =
 * session start, steps = session (counted) steps, durationSeconds = walking seconds.
 */
class ActivityLogWalkSink(private val logs: ActivityLogRepository) : WalkLogSink {

    override suspend fun upsertDaily(date: String, dayStartMs: Long, dayEndMs: Long, steps: Int) {
        logs.upsertKeyed(
            ActivityLogEntity(
                moduleId = ModuleIds.WALKING, date = date, startedAt = dayStartMs, endedAt = dayEndMs,
                durationSeconds = 0L, steps = steps, items = null, source = LogSource.WALK_DAILY,
            )
        )
    }

    override suspend fun upsertSession(date: String, startMs: Long, endMs: Long, steps: Int, walkingSeconds: Long) {
        logs.upsertKeyed(
            ActivityLogEntity(
                moduleId = ModuleIds.WALKING, date = date, startedAt = startMs, endedAt = endMs,
                durationSeconds = walkingSeconds, steps = steps, items = null, source = LogSource.WALK_SESSION,
            )
        )
    }

    override suspend fun deleteSession(startMs: Long) {
        logs.deleteKeyed(ModuleIds.WALKING, LogSource.WALK_SESSION, startMs)
    }
}
