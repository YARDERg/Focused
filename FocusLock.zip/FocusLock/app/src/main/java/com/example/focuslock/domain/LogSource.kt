package com.example.focuslock.domain

/** Values stored in ActivityLog.source. Only [SCHEDULED] counts toward "today's session completed". */
object LogSource {
    const val SCHEDULED: String = "scheduled_session"
    const val TEST: String = "test_session"
}
