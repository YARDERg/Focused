package com.example.focuslock.domain

/**
 * Values stored in ActivityLog.source.
 *  - [SCHEDULED], [OPTIONAL], [TEST] are "session rows" (one per completed task at Unlock). All count as Sessions in Home.
 *  - Only [SCHEDULED] counts toward "today's session completed" (unlocks "Change tomorrow's time").
 *  - [STUDY] rows are written by the study ledger (hours + lectures); they are never sessions.
 *  - [WALK_DAILY] (steps outside sessions, one row per date) and [WALK_SESSION] (session steps + walking seconds, one row
 *    per session) are the Walking ledger rows; they are never sessions and never test rows: Home's Steps = their sum.
 */
object LogSource {
    const val SCHEDULED: String = "scheduled_session"
    const val OPTIONAL: String = "optional_session"
    const val TEST: String = "test_session"
    const val STUDY: String = "study"
    const val WALK_DAILY: String = "walk_daily"
    const val WALK_SESSION: String = "walk_session"

    fun forKind(kind: SessionKind): String = when (kind) {
        SessionKind.SCHEDULED -> SCHEDULED
        SessionKind.OPTIONAL -> OPTIONAL
    }

    fun isSessionRow(source: String): Boolean = source == SCHEDULED || source == OPTIONAL || source == TEST

    private fun rank(source: String?): Int = when (source) {
        SCHEDULED -> 3
        OPTIONAL -> 2
        TEST -> 1
        else -> 0
    }

    /** Merge rule when a module is triggered again inside an active session: scheduled > optional > test. */
    fun merge(existing: String?, incoming: String): String =
        if (rank(existing) >= rank(incoming)) existing ?: incoming else incoming
}
