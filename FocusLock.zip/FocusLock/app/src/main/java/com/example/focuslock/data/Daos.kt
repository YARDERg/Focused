package com.example.focuslock.data

import androidx.room3.Dao
import androidx.room3.Insert
import androidx.room3.Query
import androidx.room3.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Insert
    suspend fun insertAll(logs: List<ActivityLogEntity>)

    @Query("SELECT * FROM activity_log WHERE date >= :from AND date <= :to ORDER BY startedAt DESC")
    fun observeBetween(from: String, to: String): Flow<List<ActivityLogEntity>>

    @Query(
        "SELECT * FROM activity_log WHERE moduleId = :moduleId AND source = :source " +
            "AND startedAt >= :sinceMillis ORDER BY startedAt DESC"
    )
    fun observeBySourceSince(moduleId: String, source: String, sinceMillis: Long): Flow<List<ActivityLogEntity>>

    @Query(
        "SELECT * FROM activity_log WHERE moduleId = :moduleId AND source = :source " +
            "AND startedAt >= :sinceMillis ORDER BY startedAt DESC"
    )
    suspend fun getBySourceSince(moduleId: String, source: String, sinceMillis: Long): List<ActivityLogEntity>

    /** Stage 3 ledger rows are keyed by (moduleId, source, startedAt): update in place, insert when 0 rows changed. */
    @Query(
        "UPDATE activity_log SET date = :date, endedAt = :endedAt, durationSeconds = :durationSeconds, steps = :steps " +
            "WHERE moduleId = :moduleId AND source = :source AND startedAt = :startedAt"
    )
    suspend fun updateKeyed(
        moduleId: String,
        source: String,
        startedAt: Long,
        date: String,
        endedAt: Long,
        durationSeconds: Long,
        steps: Int,
    ): Int

    @Query("DELETE FROM activity_log WHERE moduleId = :moduleId AND source = :source AND startedAt = :startedAt")
    suspend fun deleteKeyed(moduleId: String, source: String, startedAt: Long)
}

@Dao
interface ScheduleOverrideDao {
    @Upsert
    suspend fun upsert(override: ScheduleOverrideEntity)

    @Query("SELECT * FROM schedule_override WHERE moduleId = :moduleId AND date = :date")
    suspend fun get(moduleId: String, date: String): ScheduleOverrideEntity?

    @Query("SELECT * FROM schedule_override WHERE moduleId = :moduleId")
    fun observeForModule(moduleId: String): Flow<List<ScheduleOverrideEntity>>

    @Query("DELETE FROM schedule_override WHERE moduleId = :moduleId AND date = :date")
    suspend fun deleteFor(moduleId: String, date: String)

    @Query("DELETE FROM schedule_override WHERE date < :before")
    suspend fun deleteOlderThan(before: String)
}

@Dao
interface LearningDao {
    @Query("SELECT * FROM learning_day WHERE date = :date")
    suspend fun getDay(date: String): LearningDayEntity?

    @Upsert
    suspend fun upsertDay(day: LearningDayEntity)

    @Query("SELECT * FROM learning_lecture WHERE date = :date")
    suspend fun getLectures(date: String): List<LearningLectureEntity>

    @Upsert
    suspend fun upsertLectures(lectures: List<LearningLectureEntity>)
}

@Dao
interface StepsDao {
    @Upsert
    suspend fun upsertHours(rows: List<StepsHourEntity>)

    @Query("SELECT * FROM steps_hour WHERE hourStartEpoch >= :from AND hourStartEpoch < :to ORDER BY hourStartEpoch")
    suspend fun hoursBetween(from: Long, to: Long): List<StepsHourEntity>

    @Query("SELECT * FROM steps_day WHERE date = :date")
    suspend fun getDay(date: String): StepsDayEntity?

    @Upsert
    suspend fun upsertDay(day: StepsDayEntity)

    @Query("SELECT * FROM steps_day WHERE date >= :from AND date <= :to ORDER BY date")
    suspend fun daysBetween(from: String, to: String): List<StepsDayEntity>

    @Upsert
    suspend fun upsertSession(session: WalkSessionEntity)

    @Query(
        "UPDATE walk_session SET sessionSteps = :steps, sessionWalkingMs = :walkingMs, ignoredSteps = :ignored " +
            "WHERE startEpochMs = :start AND endEpochMs = 0"
    )
    suspend fun updateProgress(start: Long, steps: Int, walkingMs: Long, ignored: Int): Int

    @Query("SELECT * FROM walk_session WHERE startEpochMs = :start")
    suspend fun getSession(start: Long): WalkSessionEntity?

    @Query("SELECT * FROM walk_session WHERE endEpochMs = 0 ORDER BY startEpochMs DESC LIMIT 1")
    suspend fun openSession(): WalkSessionEntity?

    @Query("DELETE FROM walk_session WHERE startEpochMs = :start")
    suspend fun deleteSession(start: Long)

    @Query(
        "SELECT * FROM walk_session WHERE startEpochMs < :to AND (endEpochMs = 0 OR endEpochMs > :from) ORDER BY startEpochMs"
    )
    suspend fun sessionsOverlapping(from: Long, to: Long): List<WalkSessionEntity>

    @Query("SELECT * FROM walk_session WHERE endEpochMs > 0 AND endEpochMs >= :since ORDER BY startEpochMs")
    suspend fun sessionsEndedSince(since: Long): List<WalkSessionEntity>

    @Query("SELECT * FROM walk_session WHERE startEpochMs >= :from AND startEpochMs < :to ORDER BY startEpochMs")
    suspend fun sessionsStartedBetween(from: Long, to: Long): List<WalkSessionEntity>
}
