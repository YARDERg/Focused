package com.example.focuslock.lock

import com.example.focuslock.data.ActivityLogEntity
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.domain.LogSource
import com.example.focuslock.domain.ModuleRegistry
import com.example.focuslock.domain.SessionKind
import com.example.focuslock.domain.Task
import com.example.focuslock.domain.session.PersistedSession
import com.example.focuslock.domain.session.PersistedTask
import com.example.focuslock.domain.session.UnlockDurations
import com.example.focuslock.scheduler.ScheduleDefaults
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import java.time.ZoneId

data class SessionTask(val moduleId: String, val task: Task, val kind: SessionKind = SessionKind.SCHEDULED)

/** A live lock session: the union of the tasks of every module that triggered while it was active. */
class ActiveSession(
    val moduleStarts: Map<String, Long>,
    val entries: List<SessionTask>,
    /** moduleId -> LogSource value; decides the "source" of the logs written on Unlock. */
    val moduleSources: Map<String, String> = emptyMap(),
) {
    val moduleIds: List<String> get() = moduleStarts.keys.toList()
}

data class Progress(val done: Int, val total: Int) {
    val isComplete: Boolean get() = total > 0 && done == total
}

/**
 * Owns the active lock session. State is persisted so it survives process death and reboot.
 * All mutations go through [mutex] and wait for [ready] (the restore step) first.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class SessionManager(
    private val settings: SettingsRepository,
    private val registry: ModuleRegistry,
    private val logs: ActivityLogRepository,
    private val scope: CoroutineScope,
    private val now: () -> Long = { System.currentTimeMillis() },
    /** Runs before Unlock is evaluated (e.g. flushes the study ledger). Failures never block Unlock. */
    private val beforeUnlock: suspend () -> Unit = {},
) {
    private val mutex = Mutex()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _session = MutableStateFlow<ActiveSession?>(null)
    val session: StateFlow<ActiveSession?> = _session.asStateFlow()

    private val _emergencyUntil = MutableStateFlow(0L)
    val emergencyUntil: StateFlow<Long> = _emergencyUntil.asStateFlow()

    val progress: StateFlow<Progress> = _session
        .flatMapLatest { s ->
            if (s == null || s.entries.isEmpty()) {
                flowOf(Progress(0, 0))
            } else {
                combine(s.entries.map { it.task.completed }) { flags ->
                    Progress(flags.count { it }, flags.size)
                }
            }
        }
        .stateIn(scope, SharingStarted.Eagerly, Progress(0, 0))

    private val completedIds: Flow<Set<String>> = _session.flatMapLatest { s ->
        if (s == null || s.entries.isEmpty()) {
            flowOf(emptySet<String>())
        } else {
            combine(s.entries.map { e -> e.task.completed.map { done -> e.task.id to done } }) { pairs ->
                pairs.filter { it.second }.map { it.first }.toSet()
            }
        }
    }

    suspend fun awaitReady() {
        _ready.first { it }
    }

    /**
     * Starts a session of [kind] for [moduleId], or merges its tasks into the active one (a scheduled trigger
     * while an optional session is active simply adds the scheduled tasks). Returns false if there is nothing
     * to do. [source] is a [LogSource] value (default: derived from [kind]); a scheduled trigger upgrades a
     * module that was started as optional or test, never the other way round.
     */
    suspend fun startSession(
        moduleId: String,
        kind: SessionKind,
        source: String = LogSource.forKind(kind),
    ): Boolean {
        awaitReady()
        return mutex.withLock {
            val module = registry.byId(moduleId) ?: return@withLock false
            val fresh = module.createTasks(kind).filter { it.isEnabled() }
            val current = _session.value
            val updated: ActiveSession
            if (current == null) {
                if (fresh.isEmpty()) return@withLock false
                fresh.forEach { it.reset() }
                fresh.forEach { it.onStarted() }
                _emergencyUntil.value = 0L
                settings.setEmergencyUntil(0L)
                updated = ActiveSession(
                    moduleStarts = mapOf(moduleId to now()),
                    entries = fresh.map { SessionTask(moduleId, it, kind) },
                    moduleSources = mapOf(moduleId to source),
                )
            } else {
                val existing = current.entries.map { it.task.id }.toSet()
                val added = fresh.filter { it.id !in existing }
                added.forEach { it.reset() }
                added.forEach { it.onStarted() }
                updated = ActiveSession(
                    moduleStarts = current.moduleStarts + (moduleId to (current.moduleStarts[moduleId] ?: now())),
                    entries = current.entries + added.map { SessionTask(moduleId, it, kind) },
                    moduleSources = current.moduleSources + (moduleId to LogSource.merge(current.moduleSources[moduleId], source)),
                )
            }
            _session.value = updated
            settings.saveSession(toPersisted(updated))
            true
        }
    }

    /**
     * Unlock after "Goals complete": writes one ActivityLog session row per completed task, then ends the
     * session. Tasks with [Task.reportsOwnActivity] get durationSeconds = 0 (their hours come from their own rows).
     */
    suspend fun unlock(): Boolean {
        awaitReady()
        try {
            beforeUnlock()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            // A failed flush must never trap the user in the lock.
        }
        return mutex.withLock {
            val s = _session.value ?: return@withLock true
            if (s.entries.any { !it.task.completed.value }) return@withLock false
            val end = now()
            val date = Instant.ofEpochMilli(end).atZone(ZoneId.systemDefault()).toLocalDate().toString()
            val rows = s.entries
                .groupBy { it.moduleId }
                .flatMap { (moduleId, entries) ->
                    val start = s.moduleStarts[moduleId] ?: end
                    val seconds = UnlockDurations.perTaskSeconds(
                        elapsedSeconds = (end - start) / 1000L,
                        ownActivity = entries.map { it.task.reportsOwnActivity },
                    )
                    entries.mapIndexed { i, _ ->
                        ActivityLogEntity(
                            moduleId = moduleId,
                            date = date,
                            startedAt = start,
                            endedAt = end,
                            durationSeconds = seconds[i],
                            steps = null,
                            items = null,
                            source = s.moduleSources[moduleId] ?: LogSource.TEST,
                        )
                    }
                }
            logs.insertAll(rows)
            clear()
            true
        }
    }

    /** Developer exit: ends the session without writing any log. */
    suspend fun forceEnd() {
        awaitReady()
        mutex.withLock { clear() }
    }

    /** Emergency Call: the watchdog stays quiet for [ScheduleDefaults.EMERGENCY_WINDOW_MS]. Not suspending on purpose. */
    fun startEmergency() {
        val until = now() + ScheduleDefaults.EMERGENCY_WINDOW_MS
        _emergencyUntil.value = until
        scope.launch { settings.setEmergencyUntil(until) }
    }

    private suspend fun clear() {
        _session.value = null
        _emergencyUntil.value = 0L
        settings.clearSession()
    }

    private fun toPersisted(s: ActiveSession): PersistedSession = PersistedSession(
        moduleStarts = s.moduleStarts,
        tasks = s.entries.map { PersistedTask(it.moduleId, it.task.id, it.kind) },
        completed = s.entries.filter { it.task.completed.value }.map { it.task.id }.toSet(),
        sources = s.moduleSources,
    )

    private suspend fun restore() {
        try {
            _emergencyUntil.value = settings.loadEmergencyUntil()
            val p = settings.loadSession() ?: return
            val entries = ArrayList<SessionTask>()
            for ((moduleId, _) in p.moduleStarts) {
                val module = registry.byId(moduleId) ?: continue
                val mine = p.tasks.filter { it.moduleId == moduleId }
                // A module can hold tasks of several kinds (optional + merged scheduled): rebuild each kind.
                for (kind in mine.map { it.kind }.distinct()) {
                    val wanted = mine.filter { it.kind == kind }.map { it.taskId }.toSet()
                    for (task in module.createTasks(kind)) {
                        if (task.id in wanted) {
                            task.restore(task.id in p.completed)
                            try {
                                task.onRestored()
                            } catch (e: CancellationException) {
                                throw e
                            } catch (_: Throwable) {
                                // A task that cannot reload its extra state still restores with defaults.
                            }
                            entries.add(SessionTask(moduleId, task, kind))
                        }
                    }
                }
            }
            if (entries.isEmpty()) {
                settings.clearSession()
                return
            }
            val starts = p.moduleStarts.filterKeys { k -> entries.any { it.moduleId == k } }
            val sources = starts.keys.associateWith { p.sources[it] ?: LogSource.TEST }
            _session.value = ActiveSession(starts, entries, sources)
        } finally {
            _ready.value = true
        }
    }

    init {
        scope.launch { restore() }
        scope.launch {
            _ready.first { it }
            completedIds.distinctUntilChanged().collect { ids ->
                if (_session.value != null) settings.saveCompleted(ids)
            }
        }
    }
}
