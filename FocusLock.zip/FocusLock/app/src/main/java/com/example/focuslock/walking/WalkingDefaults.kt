package com.example.focuslock.walking

/** Every Walking constant in one place. */
object WalkingDefaults {
    const val DEFAULT_REQUIRED_STEPS: Int = 3000
    const val MIN_REQUIRED_STEPS: Int = 1000
    /** Test values (20 and up) are honoured only while the global debug toggle is on. */
    const val DEBUG_MIN_REQUIRED_STEPS: Int = 20

    const val DEFAULT_CADENCE: Int = 60
    /** Lowest threshold with debug off (the default; it can only be raised). */
    const val MIN_CADENCE: Int = 60
    /** Lowest threshold with debug on (test values). */
    const val DEBUG_MIN_CADENCE: Int = 10
    /** Highest threshold the setting accepts (must stay below [MAX_CADENCE]). */
    const val MAX_CADENCE_SETTING: Int = 200

    /** Cadences above this (steps per minute) are treated as shaking, not walking. */
    const val MAX_CADENCE: Int = 220

    /** Trailing window of step timestamps used for the cadence. */
    const val WINDOW_MS: Long = 30_000L

    /**
     * Extra upper-bound check over a short trailing window (a hand shake starts qualifying in the 30 s window
     * before the 30 s count can exceed the maximum). 0 disables it.
     */
    const val SHORT_WINDOW_MS: Long = 5_000L

    /** A single gap between two evaluations never credits more walking time than this. */
    const val GAP_CAP_MS: Long = 5_000L

    /** Steps reported together by the sensor are spread over at most this span before the cadence rule sees them. */
    const val SPREAD_CAP_MS: Long = 5_000L

    const val TICK_MS: Long = 1_000L
    const val PERSIST_INTERVAL_MS: Long = 5_000L

    const val MIRROR_LOOKBACK_MS: Long = 48L * 3_600_000L
    const val SESSION_RAW_REFRESH_MS: Long = 24L * 3_600_000L
    const val MIRROR_PERIOD_HOURS: Long = 3L
    /** Days (including today) whose day totals are recomputed on every mirror run. */
    const val MIRROR_DAYS: Int = 3
}

object WalkingRules {

    /** At least 1000 steps; 20 and up while the debug toggle is on. */
    fun effectiveRequiredSteps(stored: Int, debug: Boolean): Int =
        stored.coerceAtLeast(if (debug) WalkingDefaults.DEBUG_MIN_REQUIRED_STEPS else WalkingDefaults.MIN_REQUIRED_STEPS)

    /** Under the default only while debug is on; never above 200 (the shake limit is 220). */
    fun effectiveCadence(stored: Int, debug: Boolean): Int =
        stored.coerceIn(
            if (debug) WalkingDefaults.DEBUG_MIN_CADENCE else WalkingDefaults.MIN_CADENCE,
            WalkingDefaults.MAX_CADENCE_SETTING,
        )

    fun isRequirementMet(sessionSteps: Int, requiredSteps: Int): Boolean = sessionSteps >= requiredSteps

    /** Complete is enabled only when the SESSION steps reached the requirement (daily steps never count). */
    fun canComplete(sessionSteps: Int, requiredSteps: Int, alreadyCompleted: Boolean): Boolean =
        !alreadyCompleted && isRequirementMet(sessionSteps, requiredSteps)
}
