package com.example.focuslock.diag

import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Keeps the last [max] uncaught-exception stack traces as small text files. Plain JVM, unit tested. */
class CrashStore(private val dir: File, private val max: Int = 5) {

    fun record(throwable: Throwable, threadName: String, nowMillis: Long) {
        dir.mkdirs()
        var stamp = nowMillis
        var file = File(dir, fileName(stamp))
        while (file.exists()) {
            stamp++
            file = File(dir, fileName(stamp))
        }
        file.writeText(render(throwable, threadName, nowMillis))
        prune()
    }

    /** Newest first. */
    fun readAll(): List<String> = files().map { it.readText() }

    private fun files(): List<File> =
        (dir.listFiles()?.toList() ?: emptyList())
            .filter { it.isFile && it.name.startsWith("crash_") && it.name.endsWith(".txt") }
            .sortedByDescending { it.name }

    private fun prune() {
        files().drop(max).forEach { it.delete() }
    }

    private fun fileName(stamp: Long): String = "crash_" + stamp.toString().padStart(15, '0') + ".txt"

    private fun render(throwable: Throwable, threadName: String, nowMillis: Long): String {
        val time = FORMAT.format(Instant.ofEpochMilli(nowMillis).atZone(ZoneId.systemDefault()))
        val trace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()
        return "=== Crash at $time (thread: $threadName) ===\n$trace"
    }

    private companion object {
        val FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss a", Locale.US)
    }
}
