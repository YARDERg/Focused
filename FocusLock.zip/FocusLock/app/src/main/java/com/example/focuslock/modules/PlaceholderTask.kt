package com.example.focuslock.modules

import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.focuslock.domain.Task
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Stage-1 stand-in for real tasks: one button completes it. */
class PlaceholderTask(
    override val id: String,
    override val title: String,
) : Task {
    private val _completed = MutableStateFlow(false)
    override val completed: StateFlow<Boolean> = _completed.asStateFlow()

    override fun isEnabled(): Boolean = true
    override fun reset() { _completed.value = false }
    override fun restore(done: Boolean) { _completed.value = done }
    fun complete() { _completed.value = true }

    @Composable
    override fun Content() {
        val done by completed.collectAsState()
        if (done) {
            Text("Completed")
        } else {
            Button(onClick = { complete() }) { Text("Complete test task") }
        }
    }
}
