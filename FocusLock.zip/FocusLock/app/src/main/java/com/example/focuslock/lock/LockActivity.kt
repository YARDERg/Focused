package com.example.focuslock.lock

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.focuslock.FocusLockApp
import com.example.focuslock.ui.common.FocusLockTheme

class LockActivity : ComponentActivity() {

    /** Set only when the activity closes because the session ended (Unlock or developer exit). */
    @Volatile
    private var unlockFinishing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as FocusLockApp).container

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT < 27) {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // Back does nothing while locked.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* blocked */ }
        })

        setContent {
            FocusLockTheme {
                LockScreen(
                    container = container,
                    onEmergencyCall = ::startEmergencyCall,
                    onFinished = { unlockFinishing = true; finish() },
                )
            }
        }
        hideSystemBars()
    }

    /** Fail-safe: always available, no checks. Window first, then the dialer. */
    private fun startEmergencyCall() {
        (application as FocusLockApp).container.sessions.startEmergency()
        try {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
            // No dialer available; nothing else to do.
        }
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        visible = true
        hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        relaunchNow()
    }

    override fun onStop() {
        super.onStop()
        relaunchNow()
    }

    override fun onDestroy() {
        super.onDestroy()
        relaunchNow()
    }

    /**
     * Immediate relaunch, no waiting for the watchdog. Every condition is checked by [RelaunchPolicy];
     * the whole call is wrapped so it can never throw.
     */
    private fun relaunchNow() {
        try {
            val sessions = (application as FocusLockApp).container.sessions
            val app = applicationContext
            val interactive = app.getSystemService(PowerManager::class.java)?.isInteractive ?: true
            val go = RelaunchPolicy.immediate(
                sessionActive = sessions.session.value != null,
                nowMillis = System.currentTimeMillis(),
                emergencyUntil = sessions.emergencyUntil.value,
                overlayGranted = Settings.canDrawOverlays(app),
                unlocking = unlockFinishing,
                configChange = isChangingConfigurations,
                interactive = interactive,
                callInProgress = CallGuard.inProgress(app),
            )
            if (go) LockLauncher.launch(app)
        } catch (t: Throwable) {
            Log.w("LockActivity", "Immediate relaunch check failed: $t")
        }
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    companion object {
        /** True while the lock screen is resumed; the watchdog skips relaunching then. */
        @Volatile
        var visible: Boolean = false
    }
}
