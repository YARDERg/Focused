package com.example.focuslock.domain

/** Inclusive range of minutes after local midnight in which a module's session time may be placed. */
data class TimeWindow(val startMinutes: Int, val endMinutes: Int) {
    init {
        require(startMinutes in 0..1439) { "startMinutes out of range: $startMinutes" }
        require(endMinutes in 0..1439) { "endMinutes out of range: $endMinutes" }
        require(startMinutes <= endMinutes) { "window start after end" }
    }

    operator fun contains(minutes: Int): Boolean = minutes in startMinutes..endMinutes
}
