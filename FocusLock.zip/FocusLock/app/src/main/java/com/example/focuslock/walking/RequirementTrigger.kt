package com.example.focuslock.walking

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Fires the "requirement complete" notification at most once per local date. The flag is persisted (steps_day.requirementNotified)
 * BEFORE the notification is sent, so a crash can only lose the notification, never repeat it.
 */
class RequirementTrigger(
    private val store: StepsStore,
    private val notify: suspend () -> Unit,
) {
    private val mutex = Mutex()
    private var cachedDate: String? = null     // a date that is known to be notified

    /** Returns true when the notification was sent by this call. */
    suspend fun check(date: String, sessionSteps: Int, requiredSteps: Int, scheduledTaskActive: Boolean): Boolean {
        if (!scheduledTaskActive || !WalkingRules.isRequirementMet(sessionSteps, requiredSteps)) return false
        return mutex.withLock {
            if (cachedDate == date) return@withLock false
            if (store.getDay(date)?.requirementNotified == true) {
                cachedDate = date
                return@withLock false
            }
            store.markNotified(date)
            cachedDate = date
            try {
                notify()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // A failed notification never affects counting.
            }
            true
        }
    }
}
