package com.example.focuslock.walking

import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

/** Total = Daily + Session. */
data class StepTotals(val daily: Int = 0, val session: Int = 0) {
    val total: Int get() = daily + session
}

data class DayReport(val date: LocalDate, val totals: StepTotals)

data class WalkingReport(
    val today: StepTotals,
    val month: StepTotals,
    /** Newest first: today, yesterday, ... (7 rows, zeros where nothing is stored). */
    val last7: List<DayReport>,
) {
    companion object {
        val EMPTY = WalkingReport(StepTotals(), StepTotals(), emptyList())
    }
}

object WalkingReportBuilder {

    /**
     * Daily comes from the day rows (already "day raw minus session raw"), Session from the session rows by their start
     * date (counted steps, not raw). Nothing is added twice: a step is either outside a session (Daily) or inside (Session).
     */
    fun build(days: List<DayRow>, sessions: List<SessionRow>, today: LocalDate, zone: ZoneId): WalkingReport {
        val dailyByDate = days.associate { it.date to it.dailySteps }
        val sessionByDate = HashMap<String, Int>()
        for (s in sessions) {
            val d = DayMath.dateOf(s.startEpochMs, zone).toString()
            sessionByDate[d] = (sessionByDate[d] ?: 0) + s.sessionSteps
        }
        fun totalsOf(date: LocalDate): StepTotals =
            StepTotals(dailyByDate[date.toString()] ?: 0, sessionByDate[date.toString()] ?: 0)

        val month = YearMonth.from(today)
        var md = 0
        var ms = 0
        for (dom in 1..month.lengthOfMonth()) {
            val t = totalsOf(month.atDay(dom))
            md += t.daily
            ms += t.session
        }
        return WalkingReport(
            today = totalsOf(today),
            month = StepTotals(md, ms),
            last7 = (0..6).map { i -> today.minusDays(i.toLong()).let { DayReport(it, totalsOf(it)) } },
        )
    }
}
