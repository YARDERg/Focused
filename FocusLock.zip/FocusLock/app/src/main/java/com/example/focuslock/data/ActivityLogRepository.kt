package com.example.focuslock.data

import com.example.focuslock.domain.LogSource
import com.example.focuslock.domain.stats.LogEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

class ActivityLogRepository(private val dao: ActivityLogDao) {

    suspend fun insertAll(entities: List<ActivityLogEntity>) {
        if (entities.isNotEmpty()) dao.insertAll(entities)
    }

    fun observeBetween(from: LocalDate, to: LocalDate): Flow<List<LogEntry>> =
        dao.observeBetween(from.toString(), to.toString()).map { rows -> rows.map { it.toLogEntry() } }

    /** Scheduled-session logs of [moduleId] that started at or after [sinceMillis] (test sessions excluded). */
    fun observeScheduledSince(moduleId: String, sinceMillis: Long): Flow<List<LogEntry>> =
        dao.observeBySourceSince(moduleId, LogSource.SCHEDULED, sinceMillis).map { rows -> rows.map { it.toLogEntry() } }

    suspend fun scheduledSince(moduleId: String, sinceMillis: Long): List<LogEntry> =
        dao.getBySourceSince(moduleId, LogSource.SCHEDULED, sinceMillis).map { it.toLogEntry() }

    /** Insert-or-update of a ledger row keyed by (moduleId, source, startedAt); safe to call repeatedly. */
    suspend fun upsertKeyed(entity: ActivityLogEntity) {
        val changed = dao.updateKeyed(
            entity.moduleId, entity.source, entity.startedAt,
            entity.date, entity.endedAt, entity.durationSeconds, entity.steps ?: 0,
        )
        if (changed == 0) dao.insertAll(listOf(entity))
    }

    suspend fun deleteKeyed(moduleId: String, source: String, startedAt: Long) {
        dao.deleteKeyed(moduleId, source, startedAt)
    }

    private fun ActivityLogEntity.toLogEntry(): LogEntry = LogEntry(
        moduleId = moduleId,
        date = LocalDate.parse(date),
        startedAt = startedAt,
        durationSeconds = durationSeconds,
        steps = steps,
        source = source,
    )
}
