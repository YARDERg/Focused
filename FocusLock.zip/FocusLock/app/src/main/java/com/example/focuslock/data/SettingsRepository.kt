package com.example.focuslock.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.focuslock.domain.session.PersistedSession
import com.example.focuslock.domain.session.SessionCodec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "focuslock_settings")

private object Keys {
    val DEBUG = booleanPreferencesKey("debug")
    val SESSION_MODULES = stringPreferencesKey("session_modules")
    val SESSION_TASKS = stringPreferencesKey("session_tasks")
    val SESSION_COMPLETED = stringPreferencesKey("session_completed")
    val EMERGENCY_UNTIL = longPreferencesKey("emergency_until")
    fun enabled(moduleId: String) = booleanPreferencesKey("enabled_$moduleId")
    fun lastFired(moduleId: String) = stringPreferencesKey("last_fired_$moduleId")
}

/** DataStore-backed settings plus the persisted lock-session state. */
class SettingsRepository(context: Context) {
    private val store: DataStore<Preferences> = context.applicationContext.settingsDataStore

    // ---- general ----
    val debugEnabled: Flow<Boolean> = store.data.map { it[Keys.DEBUG] ?: false }
    suspend fun setDebug(value: Boolean) {
        store.edit { it[Keys.DEBUG] = value }
    }

    // ---- per-module ----
    fun moduleEnabled(moduleId: String): Flow<Boolean> = store.data.map { it[Keys.enabled(moduleId)] ?: true }
    suspend fun isModuleEnabled(moduleId: String): Boolean = moduleEnabled(moduleId).first()
    suspend fun setModuleEnabled(moduleId: String, value: Boolean) {
        store.edit { it[Keys.enabled(moduleId)] = value }
    }

    /** ISO date (yyyy-MM-dd) of the last scheduled session that fired for this module. */
    fun lastFired(moduleId: String): Flow<String?> = store.data.map { it[Keys.lastFired(moduleId)] }
    suspend fun lastFiredNow(moduleId: String): String? = lastFired(moduleId).first()
    suspend fun setLastFired(moduleId: String, isoDate: String) {
        store.edit { it[Keys.lastFired(moduleId)] = isoDate }
    }

    // ---- persisted session ----
    suspend fun loadSession(): PersistedSession? {
        val p = store.data.first()
        return SessionCodec.decode(p[Keys.SESSION_MODULES], p[Keys.SESSION_TASKS], p[Keys.SESSION_COMPLETED])
    }

    suspend fun saveSession(session: PersistedSession) {
        store.edit {
            it[Keys.SESSION_MODULES] = SessionCodec.encodeModules(session.moduleStarts)
            it[Keys.SESSION_TASKS] = SessionCodec.encodeTasks(session.tasks)
            it[Keys.SESSION_COMPLETED] = SessionCodec.encodeCompleted(session.completed)
        }
    }

    suspend fun saveCompleted(ids: Set<String>) {
        store.edit { it[Keys.SESSION_COMPLETED] = SessionCodec.encodeCompleted(ids) }
    }

    suspend fun clearSession() {
        store.edit {
            it.remove(Keys.SESSION_MODULES)
            it.remove(Keys.SESSION_TASKS)
            it.remove(Keys.SESSION_COMPLETED)
            it[Keys.EMERGENCY_UNTIL] = 0L
        }
    }

    suspend fun loadEmergencyUntil(): Long = store.data.first()[Keys.EMERGENCY_UNTIL] ?: 0L
    suspend fun setEmergencyUntil(value: Long) {
        store.edit { it[Keys.EMERGENCY_UNTIL] = value }
    }
}
