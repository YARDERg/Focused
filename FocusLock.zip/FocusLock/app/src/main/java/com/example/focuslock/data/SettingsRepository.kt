package com.example.focuslock.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.focuslock.domain.session.PersistedSession
import com.example.focuslock.domain.session.SessionCodec
import com.example.focuslock.learning.LearningDefaults
import com.example.focuslock.learning.LearningRules
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "focuslock_settings")

private object Keys {
    val DEBUG = booleanPreferencesKey("debug")
    val SESSION_MODULES = stringPreferencesKey("session_modules")
    val SESSION_TASKS = stringPreferencesKey("session_tasks")
    val SESSION_COMPLETED = stringPreferencesKey("session_completed")
    val SESSION_SOURCES = stringPreferencesKey("session_sources")
    val BYPASS_TOMORROW = booleanPreferencesKey("bypass_tomorrow")
    val EMERGENCY_UNTIL = longPreferencesKey("emergency_until")
    val LEARNING_START_URL = stringPreferencesKey("learning_start_url")
    val LEARNING_REQUIRED_MIN = intPreferencesKey("learning_required_minutes")
    val LEARNING_MIN_SHARE = intPreferencesKey("learning_min_watched_share")
    val LEARNING_LAST_URL = stringPreferencesKey("learning_last_url")
    val LEARNING_OPTIONAL_STATE = stringPreferencesKey("learning_optional_state")
    fun enabled(moduleId: String) = booleanPreferencesKey("enabled_$moduleId")
    fun lastFired(moduleId: String) = stringPreferencesKey("last_fired_$moduleId")
    fun firedAt(moduleId: String) = longPreferencesKey("last_fired_at_$moduleId")
}

/** DataStore-backed settings plus the persisted lock-session state. */
class SettingsRepository(context: Context) {
    private val store: DataStore<Preferences> = context.applicationContext.settingsDataStore

    // ---- general ----
    val debugEnabled: Flow<Boolean> = store.data.map { it[Keys.DEBUG] ?: false }
    suspend fun setDebug(value: Boolean) {
        store.edit { it[Keys.DEBUG] = value }
    }

    /** Raw state of the debug-only switch "Allow changing tomorrow without completing today". */
    val tomorrowBypassSwitch: Flow<Boolean> = store.data.map { it[Keys.BYPASS_TOMORROW] ?: false }
    suspend fun setTomorrowBypass(value: Boolean) {
        store.edit { it[Keys.BYPASS_TOMORROW] = value }
    }

    /** The bypass only works while the debug toggle is on. */
    val tomorrowBypassActive: Flow<Boolean> =
        store.data.map { (it[Keys.DEBUG] ?: false) && (it[Keys.BYPASS_TOMORROW] ?: false) }
    suspend fun isTomorrowBypassActive(): Boolean = tomorrowBypassActive.first()

    // ---- per-module ----
    fun moduleEnabled(moduleId: String): Flow<Boolean> = store.data.map { it[Keys.enabled(moduleId)] ?: true }
    suspend fun isModuleEnabled(moduleId: String): Boolean = moduleEnabled(moduleId).first()
    suspend fun setModuleEnabled(moduleId: String, value: Boolean) {
        store.edit { it[Keys.enabled(moduleId)] = value }
    }

    /** ISO date (yyyy-MM-dd) of the last scheduled session that fired for this module. */
    fun lastFired(moduleId: String): Flow<String?> = store.data.map { it[Keys.lastFired(moduleId)] }
    suspend fun lastFiredNow(moduleId: String): String? = lastFired(moduleId).first()
    /** Epoch millis of the trigger that fired last (shows the real session time after the override is deleted). */
    fun lastFiredAt(moduleId: String): Flow<Long?> = store.data.map { it[Keys.firedAt(moduleId)] }
    suspend fun setLastFired(moduleId: String, isoDate: String, triggerAtMillis: Long) {
        store.edit {
            it[Keys.lastFired(moduleId)] = isoDate
            it[Keys.firedAt(moduleId)] = triggerAtMillis
        }
    }

    // ---- persisted session ----
    suspend fun loadSession(): PersistedSession? {
        val p = store.data.first()
        return SessionCodec.decode(
            p[Keys.SESSION_MODULES], p[Keys.SESSION_TASKS], p[Keys.SESSION_COMPLETED], p[Keys.SESSION_SOURCES],
        )
    }

    suspend fun saveSession(session: PersistedSession) {
        store.edit {
            it[Keys.SESSION_MODULES] = SessionCodec.encodeModules(session.moduleStarts)
            it[Keys.SESSION_TASKS] = SessionCodec.encodeTasks(session.tasks)
            it[Keys.SESSION_COMPLETED] = SessionCodec.encodeCompleted(session.completed)
            it[Keys.SESSION_SOURCES] = SessionCodec.encodeSources(session.sources)
        }
    }

    suspend fun saveCompleted(ids: Set<String>) {
        store.edit { it[Keys.SESSION_COMPLETED] = SessionCodec.encodeCompleted(ids) }
    }

    suspend fun clearSession() {
        store.edit {
            it.remove(Keys.SESSION_MODULES)
            it.remove(Keys.SESSION_TASKS)
            it.remove(Keys.SESSION_COMPLETED)
            it.remove(Keys.SESSION_SOURCES)
            it[Keys.EMERGENCY_UNTIL] = 0L
        }
    }

    suspend fun loadEmergencyUntil(): Long = store.data.first()[Keys.EMERGENCY_UNTIL] ?: 0L
    suspend fun setEmergencyUntil(value: Long) {
        store.edit { it[Keys.EMERGENCY_UNTIL] = value }
    }

    // ---- learning (Stage 2) ----
    /** Stored raw values; the effective required minutes also depend on the debug toggle (LearningRules). */
    val learningStartUrl: Flow<String> = store.data.map { it[Keys.LEARNING_START_URL] ?: LearningDefaults.START_URL }
    suspend fun setLearningStartUrl(value: String) {
        store.edit { it[Keys.LEARNING_START_URL] = value }
    }

    val learningRequiredMinutes: Flow<Int> =
        store.data.map { it[Keys.LEARNING_REQUIRED_MIN] ?: LearningDefaults.REQUIRED_MINUTES }
    suspend fun setLearningRequiredMinutes(value: Int) {
        store.edit { it[Keys.LEARNING_REQUIRED_MIN] = value.coerceAtLeast(1) }
    }

    val learningMinWatchedShare: Flow<Int> = store.data.map {
        LearningRules.clampShare(it[Keys.LEARNING_MIN_SHARE] ?: LearningDefaults.MIN_WATCHED_SHARE)
    }
    suspend fun setLearningMinWatchedShare(value: Int) {
        store.edit { it[Keys.LEARNING_MIN_SHARE] = LearningRules.clampShare(value) }
    }

    val learningLastUrl: Flow<String?> = store.data.map { it[Keys.LEARNING_LAST_URL] }
    suspend fun setLearningLastUrl(value: String) {
        store.edit { it[Keys.LEARNING_LAST_URL] = value }
    }

    suspend fun loadLearningOptionalState(): String? = store.data.first()[Keys.LEARNING_OPTIONAL_STATE]
    suspend fun setLearningOptionalState(value: String) {
        store.edit { it[Keys.LEARNING_OPTIONAL_STATE] = value }
    }
}
