package com.example.focuslock.domain.stats

import com.example.focuslock.domain.LogSource
import java.time.LocalDate
import java.time.YearMonth

enum class Metric { HOURS, SESSIONS, STEPS }

/** One ActivityLog row as seen by the statistics code. */
data class LogEntry(
    val moduleId: String,
    val date: LocalDate,
    val startedAt: Long,
    val durationSeconds: Long,
    val steps: Int?,
    val source: String = LogSource.SCHEDULED,
)

data class Totals(
    val sessions: Int = 0,
    val seconds: Long = 0L,
    val steps: Long = 0L,
) {
    fun value(metric: Metric): Double = when (metric) {
        Metric.HOURS -> seconds / 3600.0
        Metric.SESSIONS -> sessions.toDouble()
        Metric.STEPS -> steps.toDouble()
    }
}

data class ModuleCard(val moduleId: String, val today: Totals, val month: Totals)

data class HomeStats(val cards: List<ModuleCard>, val isEmpty: Boolean)

object HomeAggregator {

    /** A "session" is a distinct startedAt per module (one session may log several tasks). */
    fun totalsOf(entries: List<LogEntry>): Totals = Totals(
        sessions = entries.map { it.startedAt }.distinct().size,
        seconds = entries.sumOf { it.durationSeconds },
        steps = entries.sumOf { (it.steps ?: 0).toLong() },
    )

    fun aggregate(
        entries: List<LogEntry>,
        moduleIds: List<String>,
        today: LocalDate,
        month: YearMonth,
        metric: Metric,
        /** With the Steps metric only these modules are listed (null = no restriction). */
        stepModuleIds: Set<String>? = null,
        /** Test sessions are excluded unless this is true (Home passes the debug toggle). */
        includeTestSessions: Boolean = false,
    ): HomeStats {
        val visible = if (includeTestSessions) entries else entries.filter { it.source != LogSource.TEST }
        val ids = if (metric == Metric.STEPS && stepModuleIds != null) {
            moduleIds.filter { it in stepModuleIds }
        } else {
            moduleIds
        }
        val cards = ids.map { id ->
            val mine = visible.filter { it.moduleId == id }
            ModuleCard(
                moduleId = id,
                today = totalsOf(mine.filter { it.date == today }),
                month = totalsOf(mine.filter { YearMonth.from(it.date) == month }),
            )
        }
        // sortedWith is stable: ties keep registry order.
        val sorted = cards.sortedWith(
            compareByDescending<ModuleCard> { it.month.value(metric) }
                .thenByDescending { it.today.value(metric) }
        )
        val empty = sorted.all { it.month.sessions == 0 && it.today.sessions == 0 }
        return HomeStats(sorted, empty)
    }
}
