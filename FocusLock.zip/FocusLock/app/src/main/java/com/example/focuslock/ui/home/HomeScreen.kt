package com.example.focuslock.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.stats.Metric
import com.example.focuslock.domain.stats.ModuleCard
import com.example.focuslock.lock.LockLauncher
import com.example.focuslock.ui.common.Format
import com.example.focuslock.ui.common.SimpleFactory
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun HomeScreen(container: AppContainer) {
    val vm: HomeViewModel = viewModel(
        key = "home",
        factory = SimpleFactory {
            HomeViewModel(
                logs = container.activityLogs,
                moduleIds = container.registry.lockingModules.map { it.id },
                sessions = container.sessions,
            )
        },
    )
    val ui by vm.state.collectAsState()
    val sessionActive by vm.sessionActive.collectAsState()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Focus Lock", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 16.dp)) }

        if (sessionActive) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("A lock session is in progress", style = MaterialTheme.typography.titleMedium)
                        Button(onClick = { LockLauncher.launch(context) }) { Text("Open lock screen") }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(onClick = vm::previousMonth) { Text("‹ Prev") }
                Text(monthLabel(ui.month), style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = vm::nextMonth, enabled = ui.canGoNext) { Text("Next ›") }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricChip("Hours", Metric.HOURS, ui.metric, vm::setMetric)
                MetricChip("Sessions", Metric.SESSIONS, ui.metric, vm::setMetric)
                MetricChip("Steps", Metric.STEPS, ui.metric, vm::setMetric)
            }
        }

        if (ui.stats.isEmpty) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("No activity yet", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Finish a lock session and tap Unlock - your totals will show up here.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        } else {
            items(ui.stats.cards, key = { it.moduleId }) { card ->
                StatCard(
                    title = container.registry.byId(card.moduleId)?.title ?: card.moduleId,
                    card = card,
                    metric = ui.metric,
                    monthText = monthLabel(ui.month),
                )
            }
        }
    }
}

@Composable
private fun MetricChip(label: String, value: Metric, selected: Metric, onSelect: (Metric) -> Unit) {
    FilterChip(
        selected = selected == value,
        onClick = { onSelect(value) },
        label = { Text(label) },
    )
}

@Composable
private fun StatCard(title: String, card: ModuleCard, metric: Metric, monthText: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Today", style = MaterialTheme.typography.labelMedium)
                    Text(Format.metric(metric, card.today), style = MaterialTheme.typography.titleMedium)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(monthText, style = MaterialTheme.typography.labelMedium)
                    Text(Format.metric(metric, card.month), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

private fun monthLabel(month: YearMonth): String =
    month.month.getDisplayName(TextStyle.FULL, Locale.getDefault()) + " " + month.year
