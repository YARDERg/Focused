package com.example.focuslock.modules

import androidx.compose.runtime.Composable
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.FeatureModule
import com.example.focuslock.domain.TimeWindow
import com.example.focuslock.ui.module.ModuleScreen

/** Base for modules that lock the phone on a daily schedule and share the standard module screen. */
abstract class ScheduledModule(
    private val container: AppContainer,
    override val id: String,
    override val title: String,
    override val defaultScheduleMinutes: Int,
    override val iconEmoji: String,
    override val allowedWindow: TimeWindow,
    override val recordsSteps: Boolean = false,
) : FeatureModule {
    override val locksPhoneOnSchedule: Boolean = true

    @Composable
    override fun Screen() {
        ModuleScreen(module = this, container = container, extras = { Extras() })
    }

    /** Module-specific cards shown under "Today's session" on the standard module screen. */
    @Composable
    protected open fun Extras() {}
}
