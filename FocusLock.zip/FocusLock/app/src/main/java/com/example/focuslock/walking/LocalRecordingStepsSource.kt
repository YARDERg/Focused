package com.example.focuslock.walking

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.fitness.FitnessLocal
import com.google.android.gms.fitness.LocalRecordingClient
import com.google.android.gms.fitness.data.LocalDataType
import com.google.android.gms.fitness.data.LocalField
import com.google.android.gms.fitness.request.LocalDataReadRequest
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

/**
 * All-day steps from the Recording API on mobile (accountless, data kept on the device for up to 10 days after
 * subscribing). Every method catches its failures: no Play services, an old version or a missing permission switch
 * all-day tracking off, they never crash the app.
 */
class LocalRecordingStepsSource(context: Context) : StepsSource {
    private val appContext = context.applicationContext
    private val client by lazy { FitnessLocal.getLocalRecordingClient(appContext) }

    override suspend fun status(): SourceStatus {
        if (!WalkingPermissions.hasActivityRecognition(appContext)) {
            return SourceStatus(SourceAvailability.NO_PERMISSION, "ACTIVITY_RECOGNITION not granted")
        }
        return try {
            val code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(
                appContext, LocalRecordingClient.LOCAL_RECORDING_CLIENT_STEPS_MIN_VERSION_CODE,
            )
            when (code) {
                ConnectionResult.SUCCESS -> SourceStatus(SourceAvailability.OK)
                ConnectionResult.SERVICE_VERSION_UPDATE_REQUIRED ->
                    SourceStatus(SourceAvailability.UPDATE_REQUIRED, "Google Play services must be updated")
                ConnectionResult.SERVICE_MISSING, ConnectionResult.SERVICE_DISABLED, ConnectionResult.SERVICE_INVALID ->
                    SourceStatus(SourceAvailability.NO_PLAY_SERVICES, "Google Play services missing or disabled (code $code)")
                else -> SourceStatus(SourceAvailability.ERROR, "Play services check returned code $code")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            SourceStatus(SourceAvailability.ERROR, "${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /** Safe to call as often as you like: subscribe() is a no-op when the subscription already exists. */
    override suspend fun ensureSubscribed(): SubscribeInfo {
        val now = System.currentTimeMillis()
        val st = status()
        if (!st.ok) return SubscribeInfo(false, now, "not subscribed: ${st.availability} ${st.detail}".trim())
        return try {
            client.subscribe(LocalDataType.TYPE_STEP_COUNT_DELTA).awaitTask()
            SubscribeInfo(true, now, "subscribe() succeeded")
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            SubscribeInfo(false, now, "subscribe() failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    override suspend fun readSteps(startMs: Long, endMs: Long): Int? {
        if (endMs <= startMs) return 0
        return try {
            val request = LocalDataReadRequest.Builder()
                .aggregate(LocalDataType.TYPE_STEP_COUNT_DELTA)
                .bucketByTime(1, TimeUnit.DAYS)         // buckets start at the range start; all returned buckets are summed
                .setTimeRange(startMs, endMs, TimeUnit.MILLISECONDS)
                .build()
            val response = client.readData(request).awaitTask() ?: return null
            response.buckets
                .flatMap { it.dataSets }
                .flatMap { it.dataPoints }
                .sumOf { it.getValue(LocalField.FIELD_STEPS).asInt() }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            null
        }
    }

    override suspend fun readHourly(startMs: Long, endMs: Long): List<HourRow>? {
        if (endMs <= startMs) return emptyList()
        return try {
            val request = LocalDataReadRequest.Builder()
                .aggregate(LocalDataType.TYPE_STEP_COUNT_DELTA)
                .bucketByTime(1, TimeUnit.HOURS)
                .setTimeRange(startMs, endMs, TimeUnit.MILLISECONDS)
                .build()
            val response = client.readData(request).awaitTask() ?: return null
            response.buckets.map { bucket ->
                val steps = bucket.dataSets.flatMap { it.dataPoints }.sumOf { it.getValue(LocalField.FIELD_STEPS).asInt() }
                HourRow(bucket.getStartTime(TimeUnit.MILLISECONDS), steps)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            null
        }
    }

    /** Debug: end time of the newest recorded data point in the last 24 h (an un-aggregated read). */
    override suspend fun newestPointMs(): Long? {
        return try {
            val end = System.currentTimeMillis()
            val request = LocalDataReadRequest.Builder()
                .read(LocalDataType.TYPE_STEP_COUNT_DELTA)
                .setTimeRange(end - 24L * 3_600_000L, end, TimeUnit.MILLISECONDS)
                .build()
            val response = client.readData(request).awaitTask() ?: return null
            response.getDataSet(LocalDataType.TYPE_STEP_COUNT_DELTA).dataPoints
                .maxOfOrNull { it.getEndTime(TimeUnit.MILLISECONDS) }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            null
        }
    }

    /** Google Play services version name/code for the debug panel. */
    fun playServicesVersion(): String = try {
        val info = appContext.packageManager.getPackageInfo("com.google.android.gms", 0)
        "${info.versionName} (${PackageInfoCompat.getLongVersionCode(info)})"
    } catch (_: PackageManager.NameNotFoundException) {
        "not installed"
    } catch (t: Throwable) {
        "unknown (${t.javaClass.simpleName})"
    }
}
