package com.example.focuslock

import android.app.Application
import android.content.pm.ApplicationInfo
import android.webkit.WebView
import com.example.focuslock.diag.Diagnostics
import com.example.focuslock.lock.LockForegroundService
import com.example.focuslock.walking.StepsMirrorWorker
import com.example.focuslock.walking.WalkingMainTask
import kotlinx.coroutines.launch

class FocusLockApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        Diagnostics.install(this)   // first: records the last 5 uncaught exceptions
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)    // chrome://inspect for the study WebView (debug builds only)
        }
        container = AppContainer(this)
        container.scope.launch {
            container.sessions.awaitReady()
            // Process restarted while a session was active: bring the watchdog back.
            if (container.sessions.session.value != null) LockForegroundService.start(this@FocusLockApp)
            container.scheduler.rescheduleAll()
            // Walking: an open walking session row without a walking task in the restored session is stale.
            val walkingActive = container.sessions.session.value?.entries?.any { it.task.id == WalkingMainTask.TASK_ID } == true
            container.walking.reconcile(walkingActive)
            container.walking.onAppEvent()          // subscribe (no-op if already), mirror
        }
        StepsMirrorWorker.schedule(this)
    }
}
