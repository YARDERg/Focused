package com.example.focuslock

import android.app.Application
import android.content.pm.ApplicationInfo
import android.webkit.WebView
import com.example.focuslock.diag.Diagnostics
import com.example.focuslock.lock.LockForegroundService
import kotlinx.coroutines.launch

class FocusLockApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        Diagnostics.install(this)   // first: records the last 5 uncaught exceptions
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)    // chrome://inspect for the study WebView (debug builds only)
        }
        container = AppContainer(this)
        container.scope.launch {
            container.sessions.awaitReady()
            // Process restarted while a session was active: bring the watchdog back.
            if (container.sessions.session.value != null) LockForegroundService.start(this@FocusLockApp)
            container.scheduler.rescheduleAll()
        }
    }
}
