package com.example.focuslock.learning

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.focuslock.domain.LocalOpenFullScreen
import com.example.focuslock.domain.Task
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Re-reads today's progress every 30 s so a midnight rollover is picked up even when nothing is playing. */
@Composable
internal fun RefreshDayEffect(hub: LearningHub) {
    LaunchedEffect(hub) {
        while (true) {
            try {
                hub.ledger.refreshDay()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
            }
            delay(30_000L)
        }
    }
}

/**
 * SCHEDULED learning task ("main"): done when today's credited study time reached the requirement.
 * Complete only marks this task done; it never ends the lock (the "Goals complete / Unlock" card does).
 */
class LearningMainTask(private val hub: LearningHub) : Task {
    override val id: String = TASK_ID
    override val title: String = "Learning: study today's requirement"

    private val _completed = MutableStateFlow(false)
    override val completed: StateFlow<Boolean> = _completed.asStateFlow()

    override val hasFullScreenUi: Boolean = true
    override val reportsOwnActivity: Boolean = true

    override fun isEnabled(): Boolean = true
    override fun reset() { _completed.value = false }
    override fun restore(done: Boolean) { _completed.value = done }

    /** Re-checks against today's stored progress (rolls the day over first). Returns true when marked complete. */
    suspend fun tryComplete(): Boolean {
        hub.ledger.refreshDay()
        val credited = hub.ledger.snapshot.value.creditedMs
        if (!LearningRules.canCompleteScheduled(credited, hub.config.value.requiredMinutes, _completed.value)) return false
        _completed.value = true
        return true
    }

    @Composable
    override fun Content() {
        val day by hub.ledger.snapshot.collectAsState()
        val config by hub.config.collectAsState()
        val done by completed.collectAsState()
        val openStudy = LocalOpenFullScreen.current
        val scope = rememberCoroutineScope()
        RefreshDayEffect(hub)

        val required = config.requiredMinutes
        val met = LearningRules.isRequirementMet(day.creditedMs, required)
        val fraction = (day.creditedMs.toFloat() / (required * 60_000f)).coerceIn(0f, 1f)

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Today: ${day.creditedMinutes} / $required min, lectures ${day.lecturesWatched}",
                style = MaterialTheme.typography.bodyLarge,
            )
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = openStudy) { Text(if (day.creditedMs > 0L) "Continue" else "Start") }
                Button(
                    onClick = { scope.launch { tryComplete() } },
                    enabled = met && !done,
                ) { Text("Complete") }
            }
            when {
                done -> Text("Completed. You can keep studying; that time is recorded.", style = MaterialTheme.typography.bodySmall)
                met -> Text("Requirement met. Press Complete when you are ready.", style = MaterialTheme.typography.bodySmall)
                else -> Text(
                    "${required - day.creditedMinutes} min to go. Studying earlier today counts.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }

    @Composable
    override fun FullScreenContent(onClose: () -> Unit) {
        StudyView(hub = hub, scheduled = true, onBackToLock = onClose, onOpened = {})
    }

    companion object {
        const val TASK_ID: String = "learning.main"
    }
}
