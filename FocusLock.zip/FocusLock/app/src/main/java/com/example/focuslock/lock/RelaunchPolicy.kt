package com.example.focuslock.lock

/**
 * Pure decision rules for relaunching [LockActivity] (no Android types, unit tested on the JVM).
 *
 * Neither rule looks at task completion: once a session is active the lock keeps coming back until
 * the user taps Unlock (or uses the developer exit), even when every task is already complete.
 * Both rules stay quiet during the emergency window and during a call (fail-safe: never block calls).
 */
object RelaunchPolicy {

    /** Used from LockActivity.onUserLeaveHint / onStop / onDestroy. */
    fun immediate(
        sessionActive: Boolean,
        nowMillis: Long,
        emergencyUntil: Long,
        overlayGranted: Boolean,
        unlocking: Boolean,
        configChange: Boolean,
        interactive: Boolean,
        callInProgress: Boolean,
    ): Boolean =
        sessionActive &&
            nowMillis >= emergencyUntil &&
            overlayGranted &&
            !unlocking &&
            !configChange &&
            interactive &&
            !callInProgress

    /** Used by the foreground-service watchdog every [com.example.focuslock.scheduler.ScheduleDefaults.WATCHDOG_INTERVAL_MS]. */
    fun watchdog(
        sessionActive: Boolean,
        nowMillis: Long,
        emergencyUntil: Long,
        overlayGranted: Boolean,
        lockVisible: Boolean,
        callInProgress: Boolean,
    ): Boolean =
        sessionActive &&
            nowMillis >= emergencyUntil &&
            overlayGranted &&
            !lockVisible &&
            !callInProgress
}
