package com.example.focuslock.walking

import android.content.Context
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.data.StepsDao
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.time.ZoneId

/** Effective Walking settings (already adjusted for the debug toggle). */
data class WalkingConfig(
    val requiredSteps: Int,
    val storedRequiredSteps: Int,
    val cadenceThreshold: Int,
    val storedCadence: Int,
    val debug: Boolean,
    val permissionAsked: Boolean,
) {
    companion object {
        val DEFAULT = WalkingConfig(
            WalkingDefaults.DEFAULT_REQUIRED_STEPS, WalkingDefaults.DEFAULT_REQUIRED_STEPS,
            WalkingDefaults.DEFAULT_CADENCE, WalkingDefaults.DEFAULT_CADENCE, false, false,
        )
    }
}

/** What the "All-day tracking" status line shows. */
data class TrackingStatus(val on: Boolean, val text: String)

/**
 * Everything the Walking feature shares: settings, the live session tracker, the Recording API mirror, the ledger, the
 * notification. Created lazily by the container; modules only see it through [WalkingMainTask].
 *
 * Failure rule: nothing here may throw into callers. All-day tracking can be off (no permission, no Play services); the
 * session tracker and the lock keep working.
 */
class WalkingHub(
    appContext: Context,
    val settings: SettingsRepository,
    stepsDao: StepsDao,
    logs: ActivityLogRepository,
    val scope: CoroutineScope,
    /** True while the active session holds the scheduled walking task (set by the container). */
    private val scheduledTaskActive: () -> Boolean = { true },
    /** Completes when the SessionManager has restored its state (set by the container). */
    private val awaitSessionsReady: suspend () -> Unit = {},
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val zone: () -> ZoneId = { ZoneId.systemDefault() },
) {
    private val context = appContext.applicationContext

    val config: StateFlow<WalkingConfig> = combine(
        settings.walkingRequiredSteps,
        settings.walkingCadence,
        settings.debugEnabled,
        settings.walkingPermissionAsked,
    ) { stored, cadence, debug, asked ->
        WalkingConfig(
            requiredSteps = WalkingRules.effectiveRequiredSteps(stored, debug),
            storedRequiredSteps = stored,
            cadenceThreshold = WalkingRules.effectiveCadence(cadence, debug),
            storedCadence = cadence,
            debug = debug,
            permissionAsked = asked,
        )
    }.stateIn(scope, SharingStarted.Eagerly, WalkingConfig.DEFAULT)

    private val source = LocalRecordingStepsSource(context)
    private val store = RoomStepsStore(stepsDao)
    private val mirror = StepsMirror(source, store, ActivityLogWalkSink(logs), clock, zone)
    private val notifier = WalkingNotifier(context)
    private val trigger = RequirementTrigger(store) { notifier.notifyRequirementComplete() }

    val tracker = WalkSessionTracker()

    private val lifecycleMutex = Mutex()

    // ---- observable state ----
    private val _tracking = MutableStateFlow(TrackingStatus(false, "Checking..."))
    val tracking: StateFlow<TrackingStatus> = _tracking.asStateFlow()

    private val _permission = MutableStateFlow(WalkingPermissions.hasActivityRecognition(context))
    val permissionGranted: StateFlow<Boolean> = _permission.asStateFlow()

    private val _subscription = MutableStateFlow(SubscribeInfo(false, 0L, "not attempted yet"))
    val subscription: StateFlow<SubscribeInfo> = _subscription.asStateFlow()

    private val _lastMirror = MutableStateFlow(MirrorResult.NONE)
    val lastMirror: StateFlow<MirrorResult> = _lastMirror.asStateFlow()

    private val _newestPoint = MutableStateFlow<Long?>(null)
    val newestPoint: StateFlow<Long?> = _newestPoint.asStateFlow()

    private val _hoursToday = MutableStateFlow<List<HourRow>>(emptyList())
    val hoursToday: StateFlow<List<HourRow>> = _hoursToday.asStateFlow()

    private val _playServices = MutableStateFlow("?")
    val playServices: StateFlow<String> = _playServices.asStateFlow()

    private val _report = MutableStateFlow(WalkingReport.EMPTY)
    val report: StateFlow<WalkingReport> = _report.asStateFlow()

    init {
        // Requirement notification: once per date, only while the scheduled task is active.
        scope.launch {
            tracker.live.map { it.sessionSteps }.distinctUntilChanged().collect { steps ->
                if (steps > 0) {
                    val date = DayMath.dateOf(clock(), zone()).toString()
                    safely { trigger.check(date, steps, config.value.requiredSteps, scheduledTaskActive()) }
                }
            }
        }
    }

    // ---- permission / subscription / mirror ----

    fun hasPermission(): Boolean = WalkingPermissions.hasActivityRecognition(context).also { _permission.value = it }

    suspend fun markPermissionAsked() = safely { settings.setWalkingPermissionAsked(true) }

    /** Permission result (or a return from system settings): re-subscribe, restart the session service, refresh. */
    suspend fun onPermissionChanged() {
        hasPermission()
        subscribeAndMirror()
        if (tracker.isActive) startServiceIfPossible()
    }

    /** App start / onResume / boot: subscribe (no-op when already subscribed), refresh status, mirror, reload. */
    suspend fun onAppEvent() {
        hasPermission()
        subscribeAndMirror()
    }

    private suspend fun subscribeAndMirror() {
        safely {
            _playServices.value = source.playServicesVersion()
            if (hasPermission()) _subscription.value = source.ensureSubscribed()
            updateTracking()
            mirrorNow()
        }
    }

    /** One full mirror pass (worker, app open, session start). */
    suspend fun mirrorNow(): MirrorResult {
        val r = try {
            mirror.run()
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            MirrorResult(false, clock(), "failed: ${t.message}")
        }
        _lastMirror.value = r
        safely {
            _newestPoint.value = if (r.ok) source.newestPointMs() else _newestPoint.value
            reloadDerived()
        }
        return r
    }

    /** Cheap refresh for the Walking page: today's day total (and the running session's raw steps). */
    suspend fun refreshToday() {
        safely {
            if (hasPermission() && !_subscription.value.ok) _subscription.value = source.ensureSubscribed()
            updateTracking()
            val today = DayMath.dateOf(clock(), zone()).toString()
            mirror.refreshDay(today)
            val live = tracker.live.value
            if (live.active) tracker.setSessionRaw(mirror.readSessionRaw(live.startMs, clock())?.first)
            reloadDerived()
        }
    }

    private suspend fun updateTracking() {
        val st = source.status()
        _tracking.value = when {
            st.ok && _subscription.value.ok -> TrackingStatus(true, "On (Recording API)")
            st.ok -> TrackingStatus(false, "Off: ${_subscription.value.message}")
            else -> TrackingStatus(false, "Off: ${st.detail.ifBlank { st.availability.name }}")
        }
    }

    suspend fun reloadDerived() {
        safely {
            val z = zone()
            val today = DayMath.dateOf(clock(), z)
            val month = java.time.YearMonth.from(today)
            val from = month.atDay(1).minusDays(7).toString()
            val days = store.daysBetween(from, today.toString())
            val sessions = store.sessionsStartedBetween(
                DayMath.dayStart(month.atDay(1).minusDays(7), z), DayMath.dayEnd(today, z),
            )
            _report.value = WalkingReportBuilder.build(days, sessions, today, z)
            val dayStart = DayMath.dayStart(today, z)
            _hoursToday.value = store.hoursBetween(dayStart, DayMath.dayEnd(today, z))
        }
    }

    // ---- session lifecycle (called by WalkingMainTask / SessionManager hooks) ----

    /** The scheduled walking task became part of a session. Fast: the mirror pass runs in the background. */
    suspend fun startSession() {
        lifecycleMutex.withLock {
            safely {
                val stale = store.openSession()
                if (stale != null) mirror.discardSession(stale.startEpochMs)   // a session that never ended cleanly
                val start = clock()
                mirror.openSession(start)
                tracker.begin(start, config.value.cadenceThreshold)
                startServiceIfPossible()
            }
        }
        scope.launch { safely { mirrorNow() } }     // session start: copy what is recorded so far
    }

    /** The session was restored after process death / reboot: reload the running totals and restart the service. */
    suspend fun restoreSession() {
        lifecycleMutex.withLock {
            safely {
                val row = store.openSession()
                if (row == null) {
                    val start = clock()
                    mirror.openSession(start)
                    tracker.begin(start, config.value.cadenceThreshold)
                } else {
                    tracker.restore(
                        row.startEpochMs, row.sessionSteps, row.sessionWalkingMs, row.ignoredSteps,
                        config.value.cadenceThreshold,
                    )
                }
                startServiceIfPossible()
            }
        }
    }

    /**
     * Called after the lock session ended. [discard] = developer exit: the session is forgotten (its steps count as Daily).
     * Otherwise: record the end, stop the service, store sessionRawSteps (exact range read), write the ledger, mirror.
     */
    fun endSessionAsync(endMs: Long, discard: Boolean) {
        scope.launch {
            lifecycleMutex.withLock {
                safely {
                    val snap = tracker.end()
                    StepTrackingService.stop(context)
                    val start = snap?.startMs ?: store.openSession()?.startEpochMs
                    if (start != null) {
                        if (discard) {
                            mirror.discardSession(start)
                        } else if (snap != null) {
                            mirror.closeSession(start, endMs, snap.sessionSteps, snap.walkingMs, snap.ignoredSteps)
                        } else {
                            mirror.discardSession(start)
                        }
                    }
                }
            }
            safely { mirrorNow() }
        }
    }

    /** After the process restarted: an open row without a walking task in the restored session is stale. */
    suspend fun reconcile(walkingTaskActive: Boolean) {
        if (walkingTaskActive) return
        lifecycleMutex.withLock {
            safely {
                val stale = store.openSession()
                if (stale != null) mirror.discardSession(stale.startEpochMs)
                tracker.end()
                StepTrackingService.stop(context)
            }
        }
    }

    /** Writes the running totals to Room (about every 5 s while the service runs). */
    suspend fun persistProgress() {
        val snap = tracker.snapshot() ?: return
        safely {
            store.updateProgress(snap.startMs, snap.sessionSteps, snap.walkingMs, snap.ignoredSteps)
        }
    }

    /** Never starts the service without the permission (it would crash on Android 14+). */
    fun startServiceIfPossible() {
        if (hasPermission() && tracker.isActive) StepTrackingService.start(context)
    }

    suspend fun awaitReady() {
        awaitSessionsReady()
    }

    private suspend inline fun safely(block: () -> Unit) {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            // Walking must never take the app or the lock down.
        }
    }
}
