package com.example.focuslock.walking

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.focuslock.FocusLockApp
import com.example.focuslock.lock.LockActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Health foreground service that feeds the SESSION counter from the step sensor while a walking session runs. The
 * Recording API is not used here. Partial wake lock so counting continues with the screen off. It stops itself as
 * soon as no walking session is active.
 */
class StepTrackingService : Service(), SensorEventListener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var sensorManager: SensorManager? = null
    private var registered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH,
            )
        } catch (_: Throwable) {
            // E.g. permission revoked between the check in start() and now, or background start not allowed.
            stopSelf()
            return START_NOT_STICKY
        }
        if (loop?.isActive != true) loop = scope.launch { run() }
        return START_STICKY
    }

    private suspend fun run() {
        val container = (application as FocusLockApp).container
        val hub = container.walking
        try {
            // After a sticky restart the session is restored by the SessionManager first.
            container.sessions.awaitReady()
            if (!hub.tracker.isActive) {
                stopSelf()
                return
            }
            acquireWakeLock()
            registerSensor(hub)
            var lastPersist = 0L
            var lastRaw = 0L
            while (scope.isActive) {
                val now = System.currentTimeMillis()
                if (!hub.tracker.isActive) {
                    stopSelf()
                    return
                }
                hub.tracker.tick(now)
                if (now - lastPersist >= WalkingDefaults.PERSIST_INTERVAL_MS) {
                    hub.persistProgress()
                    lastPersist = now
                }
                if (hub.config.value.debug && now - lastRaw >= 15_000L) {
                    hub.refreshToday()
                    lastRaw = now
                }
                delay(WalkingDefaults.TICK_MS)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            Log.w("StepTracking", "Step tracking loop failed: $t")
        }
    }

    private fun registerSensor(hub: WalkingHub) {
        val sm = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        sensorManager = sm
        if (sm == null) {
            hub.tracker.setSensor(SensorKind.NONE)
            return
        }
        val counter = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        val detector = if (counter == null) sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) else null
        val chosen = counter ?: detector
        if (chosen == null) {
            hub.tracker.setSensor(SensorKind.NONE)          // the lock card shows "No step sensor"
            return
        }
        hub.tracker.setSensor(if (counter != null) SensorKind.STEP_COUNTER else SensorKind.STEP_DETECTOR)
        // maxReportLatency 0: deliver events immediately (no batching).
        registered = try {
            sm.registerListener(this, chosen, SensorManager.SENSOR_DELAY_NORMAL, 0)
        } catch (_: Throwable) {
            false
        }
        if (!registered) hub.tracker.setSensor(SensorKind.NONE)
    }

    override fun onSensorChanged(event: SensorEvent) {
        try {
            val tracker = (application as FocusLockApp).container.walking.tracker
            val now = System.currentTimeMillis()
            when (event.sensor.type) {
                Sensor.TYPE_STEP_COUNTER -> tracker.onCounterValue(event.values[0], now)
                Sensor.TYPE_STEP_DETECTOR -> tracker.onDetectorStep(now)
            }
        } catch (_: Throwable) {
            // A sensor callback must never crash the process.
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "focuslock:steps")
            wl.setReferenceCounted(false)
            wl.acquire(12L * 3_600_000L)       // a session never needs more than this; released in onDestroy
            wakeLock = wl
        } catch (_: Throwable) {
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Walking session", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, LockActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_directions)
            .setContentTitle("Focus Lock: walking session")
            .setContentText("Counting your steps")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    override fun onDestroy() {
        try {
            if (registered) sensorManager?.unregisterListener(this)
        } catch (_: Throwable) {
        }
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {
        }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "walking_session"
        private const val NOTIFICATION_ID = 1002

        /** Starts the service only with ACTIVITY_RECOGNITION granted (without it startForeground crashes on Android 14+). */
        fun start(context: Context) {
            if (!WalkingPermissions.hasActivityRecognition(context)) return
            try {
                ContextCompat.startForegroundService(context, Intent(context, StepTrackingService::class.java))
            } catch (_: Throwable) {
                // Not allowed from this background state; the lock screen's next start/resume tries again.
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, StepTrackingService::class.java))
            } catch (_: Throwable) {
            }
        }
    }
}
