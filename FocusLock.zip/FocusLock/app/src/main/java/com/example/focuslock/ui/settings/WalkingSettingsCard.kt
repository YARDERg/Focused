package com.example.focuslock.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.focuslock.AppContainer
import com.example.focuslock.walking.WalkingDefaults
import com.example.focuslock.walking.WalkingRules
import kotlinx.coroutines.launch

/** Walking settings: required session steps and the cadence threshold (low test values need the debug toggle). */
@Composable
fun WalkingSettingsCard(container: AppContainer) {
    val hub = container.walking
    val config by hub.config.collectAsState()
    val scope = rememberCoroutineScope()

    var steps by remember { mutableStateOf("") }
    var cadence by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    // Fill the fields once with the stored values (not the debug-adjusted effective ones).
    LaunchedEffect(Unit) {
        val c = hub.config.value
        steps = c.storedRequiredSteps.toString()
        cadence = c.storedCadence.toString()
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Walking", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = steps,
                onValueChange = { steps = it.filter { ch -> ch.isDigit() }.take(6); message = null },
                label = { Text("Required session steps") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = cadence,
                onValueChange = { cadence = it.filter { ch -> ch.isDigit() }.take(3); message = null },
                label = { Text("Cadence threshold, steps per minute") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Effective: ${config.requiredSteps} session steps, cadence >= ${config.cadenceThreshold}/min " +
                    "(and at most ${WalkingDefaults.MAX_CADENCE}/min). Default ${WalkingDefaults.DEFAULT_REQUIRED_STEPS} steps " +
                    "(minimum ${WalkingDefaults.MIN_REQUIRED_STEPS}) and ${WalkingDefaults.DEFAULT_CADENCE}/min. Test values " +
                    "(${WalkingDefaults.DEBUG_MIN_REQUIRED_STEPS}+ steps, cadence from ${WalkingDefaults.DEBUG_MIN_CADENCE}) only apply while Debug info is on.",
                style = MaterialTheme.typography.bodySmall,
            )
            Button(
                onClick = {
                    val s = steps.toIntOrNull()
                    val c = cadence.toIntOrNull()
                    when {
                        s == null || s < 1 -> message = "Enter the number of session steps."
                        c == null || c < 1 -> message = "Enter a cadence in steps per minute."
                        else -> scope.launch {
                            hub.settings.setWalkingRequiredSteps(s)
                            hub.settings.setWalkingCadence(c)
                            val debug = hub.config.value.debug
                            message = "Saved. Effective now: ${WalkingRules.effectiveRequiredSteps(s, debug)} steps, " +
                                "cadence ${WalkingRules.effectiveCadence(c, debug)}/min."
                        }
                    }
                },
            ) { Text("Save") }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
