package com.example.focuslock.learning

/** Navigation allowlist of the study WebView: udemy.com, *.udemy.com and udemycdn.com. */
object HostAllowlist {

    fun isAllowedHost(host: String?): Boolean {
        val h = host?.trim()?.trimEnd('.')?.lowercase() ?: return false
        if (h.isEmpty()) return false
        return h == "udemy.com" || h.endsWith(".udemy.com") || h == "udemycdn.com"
    }

    /** Host of an http(s) URL, or null. Strips user info and port ("https://udemy.com@evil.com" -> evil.com). */
    fun hostOf(url: String?): String? {
        if (url.isNullOrBlank()) return null
        val scheme = url.substringBefore("://", "").lowercase()
        if (scheme != "http" && scheme != "https") return null
        val authority = url.substringAfter("://").substringBefore('/').substringBefore('?').substringBefore('#')
        val noUser = authority.substringAfterLast('@')
        val host = noUser.substringBefore(':')
        return host.ifEmpty { null }
    }

    fun isAllowedUrl(url: String?): Boolean = isAllowedHost(hostOf(url))

    /** Where the study view starts: the last visited URL, else the configured start URL, else the default. */
    fun initialUrl(lastUrl: String?, startUrl: String?): String = when {
        isAllowedUrl(lastUrl) -> lastUrl!!
        isAllowedUrl(startUrl) -> startUrl!!
        else -> LearningDefaults.START_URL
    }
}
