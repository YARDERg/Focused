package com.example.focuslock.lock

/** Stage-1 developer exit. Delete this file (and its single use in LockScreen) to remove the escape hatch. */
object DeveloperPassword {
    const val VALUE: String = "Stage1Exit"
    fun matches(input: String): Boolean = input == VALUE
}
