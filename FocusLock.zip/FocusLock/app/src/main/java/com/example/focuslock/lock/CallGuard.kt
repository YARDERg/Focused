package com.example.focuslock.lock

import android.content.Context
import android.media.AudioManager

/** Never fight the dialer: no relaunch while the phone is ringing or in a call. Never throws. */
object CallGuard {
    fun inProgress(context: Context): Boolean = try {
        val mode = (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode
        mode == AudioManager.MODE_RINGTONE ||
            mode == AudioManager.MODE_IN_CALL ||
            mode == AudioManager.MODE_IN_COMMUNICATION
    } catch (_: Throwable) {
        false
    }
}
