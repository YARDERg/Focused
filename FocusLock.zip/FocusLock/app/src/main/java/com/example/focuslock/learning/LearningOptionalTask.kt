package com.example.focuslock.learning

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.unit.dp
import com.example.focuslock.domain.LocalOpenFullScreen
import com.example.focuslock.domain.Task
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * OPTIONAL learning task: no minutes or lectures requirement. Complete needs only that the study view was
 * opened at least once in this session (plus [OPTIONAL_MIN_CREDIT_SECONDS] of credited time, 0 for now).
 */
class LearningOptionalTask(private val hub: LearningHub) : Task {
    override val id: String = TASK_ID
    override val title: String = "Learning: optional study session"

    private val _completed = MutableStateFlow(false)
    override val completed: StateFlow<Boolean> = _completed.asStateFlow()

    private val _state = MutableStateFlow(OptionalState.NONE)
    val state: StateFlow<OptionalState> = _state.asStateFlow()

    override val hasFullScreenUi: Boolean = true
    override val reportsOwnActivity: Boolean = true

    override fun isEnabled(): Boolean = true
    override fun reset() { _completed.value = false }
    override fun restore(done: Boolean) { _completed.value = done }

    /** Fresh session: not opened yet, and remember today's credit so only this session's study counts. */
    override suspend fun onStarted() {
        hub.ledger.refreshDay()
        val snap = hub.ledger.snapshot.value
        save(OptionalState(opened = false, baselineDate = snap.date, baselineMs = snap.creditedMs))
    }

    /** After a restart: reload the persisted "opened" flag and baseline. */
    override suspend fun onRestored() {
        _state.value = OptionalState.decode(hub.settings.loadLearningOptionalState()) ?: OptionalState.NONE
    }

    private suspend fun save(state: OptionalState) {
        _state.value = state
        hub.settings.setLearningOptionalState(state.encode())
    }

    /** Called by the study view when it opens. Persisted so it survives process death. */
    fun markOpened() {
        val next = _state.value.copy(opened = true)
        if (next == _state.value) return
        _state.value = next
        hub.scope.launch {
            try {
                hub.settings.setLearningOptionalState(next.encode())
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
            }
        }
    }

    private fun sessionCreditedSeconds(snapshot: DaySnapshot): Long =
        _state.value.sessionCreditedMs(snapshot.date, snapshot.creditedMs) / 1000L

    suspend fun tryComplete(): Boolean {
        hub.ledger.refreshDay()
        val snap = hub.ledger.snapshot.value
        if (!LearningRules.canCompleteOptional(_state.value.opened, sessionCreditedSeconds(snap), _completed.value)) return false
        _completed.value = true
        return true
    }

    @Composable
    override fun Content() {
        val day by hub.ledger.snapshot.collectAsState()
        val st by state.collectAsState()
        val done by completed.collectAsState()
        val openRequest by hub.openStudyRequest.collectAsState()
        val openStudy = LocalOpenFullScreen.current
        val scope = rememberCoroutineScope()
        RefreshDayEffect(hub)

        // "Start learning session" asked for the study view: open it once, right away.
        LaunchedEffect(openRequest) {
            if (openRequest) {
                hub.consumeOpenStudyRequest()
                openStudy()
            }
        }

        val canComplete = LearningRules.canCompleteOptional(
            st.opened, st.sessionCreditedMs(day.date, day.creditedMs) / 1000L, done,
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Today: ${day.creditedMinutes} min studied, lectures ${day.lecturesWatched}",
                style = MaterialTheme.typography.bodyLarge,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = openStudy) { Text(if (st.opened) "Continue" else "Start") }
                Button(
                    onClick = { scope.launch { tryComplete() } },
                    enabled = canComplete,
                ) { Text("Complete") }
            }
            when {
                done -> Text("Completed. You can keep studying; that time is recorded.", style = MaterialTheme.typography.bodySmall)
                !st.opened -> Text("Open the study view once to be able to complete.", style = MaterialTheme.typography.bodySmall)
                else -> Text("No minimum. Press Complete when you are done.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    @Composable
    override fun FullScreenContent(onClose: () -> Unit) {
        StudyView(hub = hub, onBackToLock = onClose, onOpened = { markOpened() })
    }

    companion object {
        const val TASK_ID: String = "learning.optional"
    }
}
