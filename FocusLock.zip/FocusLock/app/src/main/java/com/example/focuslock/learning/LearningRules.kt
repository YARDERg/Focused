package com.example.focuslock.learning

import java.time.Instant
import java.time.ZoneId

object DayKey {
    /** Local date key (yyyy-MM-dd) of [epochMs] in [zone]. Study progress resets when this changes. */
    fun of(epochMs: Long, zone: ZoneId): String =
        Instant.ofEpochMilli(epochMs).atZone(zone).toLocalDate().toString()
}

object LearningRules {

    /**
     * Values under the default (30) are only honoured while the global debug toggle is on; 1 is the
     * absolute minimum. With debug off the requirement can be raised but never lowered below the default.
     */
    fun effectiveRequiredMinutes(stored: Int, debug: Boolean): Int =
        if (debug) stored.coerceAtLeast(1) else stored.coerceAtLeast(LearningDefaults.REQUIRED_MINUTES)

    fun clampShare(percent: Int): Int =
        percent.coerceIn(LearningDefaults.MIN_WATCHED_SHARE_LOW, LearningDefaults.MIN_WATCHED_SHARE_HIGH)

    fun isRequirementMet(creditedMs: Long, requiredMinutes: Int): Boolean =
        creditedMs >= requiredMinutes * 60_000L

    /** SCHEDULED task: Complete is enabled only when today's credited time reached the requirement. */
    fun canCompleteScheduled(creditedMs: Long, requiredMinutes: Int, alreadyCompleted: Boolean): Boolean =
        !alreadyCompleted && isRequirementMet(creditedMs, requiredMinutes)

    /** OPTIONAL task: the study view was opened at least once (and, if raised, enough seconds were credited). */
    fun optionalConditionMet(
        openedOnce: Boolean,
        sessionCreditedSeconds: Long,
        minCreditSeconds: Long = OPTIONAL_MIN_CREDIT_SECONDS,
    ): Boolean = openedOnce && sessionCreditedSeconds >= minCreditSeconds

    fun canCompleteOptional(
        openedOnce: Boolean,
        sessionCreditedSeconds: Long,
        alreadyCompleted: Boolean,
        minCreditSeconds: Long = OPTIONAL_MIN_CREDIT_SECONDS,
    ): Boolean = !alreadyCompleted && optionalConditionMet(openedOnce, sessionCreditedSeconds, minCreditSeconds)
}

/** Persisted state of the optional task: was the study view opened, and today's credit when the session began. */
data class OptionalState(val opened: Boolean, val baselineDate: String, val baselineMs: Long) {

    fun encode(): String = "${if (opened) 1 else 0}|$baselineDate|$baselineMs"

    /** Credit earned since the session began (all of today's credit if the date changed meanwhile). */
    fun sessionCreditedMs(todayDate: String, todayCreditedMs: Long): Long =
        if (baselineDate == todayDate) (todayCreditedMs - baselineMs).coerceAtLeast(0L) else todayCreditedMs.coerceAtLeast(0L)

    companion object {
        val NONE = OptionalState(false, "", 0L)

        fun decode(raw: String?): OptionalState? {
            if (raw.isNullOrBlank()) return null
            val parts = raw.split('|')
            if (parts.size != 3) return null
            val baseline = parts[2].toLongOrNull() ?: return null
            if (parts[0] != "0" && parts[0] != "1") return null
            return OptionalState(parts[0] == "1", parts[1], baseline)
        }
    }
}
