package com.example.focuslock.domain

import androidx.compose.runtime.Composable

/** A pluggable feature (Learning, Walking, Habits, ...). The engine only knows this interface. */
interface FeatureModule {
    val id: String
    val title: String
    val defaultScheduleMinutes: Int
    val locksPhoneOnSchedule: Boolean

    /** Window in which "Change tomorrow's time" may place this module's session. Default: the whole day. */
    val allowedWindow: TimeWindow get() = TimeWindow(0, 1439)

    /** True when the module logs steps; only such modules are listed under Home's Steps metric. */
    val recordsSteps: Boolean get() = false

    /** Short glyph shown in the bottom bar (emoji, so no icon dependency is needed). */
    val iconEmoji: String get() = "•"

    /** Must return fresh Task instances on every call. */
    fun createTasks(): List<Task>

    @Composable
    fun Screen()
}
