package com.example.focuslock.domain

import androidx.compose.runtime.Composable

/** A pluggable feature (Learning, Walking, Habits, ...). The engine only knows this interface. */
interface FeatureModule {
    val id: String
    val title: String
    val defaultScheduleMinutes: Int
    val locksPhoneOnSchedule: Boolean

    /** Short glyph shown in the bottom bar (emoji, so no icon dependency is needed). */
    val iconEmoji: String get() = "•"

    /** Must return fresh Task instances on every call. */
    fun createTasks(): List<Task>

    @Composable
    fun Screen()
}
