package com.example.focuslock.walking

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.focuslock.domain.Task
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * SCHEDULED walking task ("main"): done when the SESSION steps reached the requirement. Steps taken before the session
 * never count. Complete only marks this task done; it never ends the lock (the "Goals complete / Unlock" card does).
 * Steps after the requirement, until Unlock, keep counting as session steps. There is no optional walking session.
 */
class WalkingMainTask(private val hub: WalkingHub) : Task {
    override val id: String = TASK_ID
    override val title: String = "Walking: reach today's session steps"

    private val _completed = MutableStateFlow(false)
    override val completed: StateFlow<Boolean> = _completed.asStateFlow()

    /** Hours come from the "walk_session" rows (walking seconds), so the session row itself carries 0 seconds. */
    override val reportsOwnActivity: Boolean = true

    override fun isEnabled(): Boolean = true
    override fun reset() { _completed.value = false }
    override fun restore(done: Boolean) { _completed.value = done }

    override suspend fun onStarted() {
        hub.startSession()
    }

    override suspend fun onRestored() {
        hub.restoreSession()
    }

    /** Re-checks against the live session steps. Returns true when marked complete. */
    fun tryComplete(): Boolean {
        val steps = hub.tracker.live.value.sessionSteps
        if (!WalkingRules.canComplete(steps, hub.config.value.requiredSteps, _completed.value)) return false
        _completed.value = true
        return true
    }

    @Composable
    override fun Content() {
        val live by hub.tracker.live.collectAsState()
        val config by hub.config.collectAsState()
        val granted by hub.permissionGranted.collectAsState()
        val done by completed.collectAsState()
        val scope = rememberCoroutineScope()

        // The lock screen is in the foreground here, which is the safe moment to (re)start the health service: it covers a
        // session that began from a background alarm, and a permission granted from this card.
        LaunchedEffect(granted, live.active) {
            if (granted && live.active) hub.startServiceIfPossible()
        }

        val required = config.requiredSteps
        val met = WalkingRules.isRequirementMet(live.sessionSteps, required)
        val fraction = (live.sessionSteps.toFloat() / required.toFloat()).coerceIn(0f, 1f)

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!granted) WalkingPermissionCard(hub)

            Text("Session steps ${live.sessionSteps} / $required", style = MaterialTheme.typography.bodyLarge)
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
            Text("Walking time ${live.walkingMinutes} min", style = MaterialTheme.typography.bodyMedium)
            Text(
                when {
                    live.sensor == SensorKind.NONE -> "No step sensor"
                    live.status == CadenceStatus.WALKING -> "Walking (${live.cadence} steps/min)"
                    live.status == CadenceStatus.TOO_FAST -> "Not walking: too fast (${live.cadence} steps/min)"
                    else -> "Not walking (${live.cadence} steps/min)"
                },
                style = MaterialTheme.typography.titleMedium,
            )
            Button(
                onClick = { scope.launch { tryComplete() } },
                enabled = met && !done,
            ) { Text("Complete") }
            when {
                done -> Text("Completed. Steps you take now still count until you unlock.", style = MaterialTheme.typography.bodySmall)
                met -> Text("Requirement met. Press Complete when you are ready.", style = MaterialTheme.typography.bodySmall)
                else -> Text(
                    "${required - live.sessionSteps} steps to go. Only steps during this session count (not earlier steps today).",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            if (config.debug) WalkingDebugPanel(hub)
        }
    }

    @Composable
    override fun FullScreenContent(onClose: () -> Unit) {
        Content()
    }

    companion object {
        const val TASK_ID: String = "walking.main"
    }
}
