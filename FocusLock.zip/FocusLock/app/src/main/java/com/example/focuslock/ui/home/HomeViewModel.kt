package com.example.focuslock.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.domain.stats.HomeAggregator
import com.example.focuslock.domain.stats.HomeStats
import com.example.focuslock.domain.stats.Metric
import com.example.focuslock.lock.SessionManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.Clock
import java.time.LocalDate
import java.time.YearMonth

data class HomeUiState(
    val month: YearMonth,
    val metric: Metric,
    val today: LocalDate,
    val stats: HomeStats,
    val canGoNext: Boolean,
)

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(
    private val logs: ActivityLogRepository,
    private val moduleIds: List<String>,
    sessions: SessionManager,
    private val clock: Clock = Clock.systemDefaultZone(),
) : ViewModel() {

    private val month = MutableStateFlow(YearMonth.now(clock))
    private val metric = MutableStateFlow(Metric.HOURS)

    private val today: Flow<LocalDate> = flow {
        while (true) {
            emit(LocalDate.now(clock))
            delay(30_000)
        }
    }.distinctUntilChanged()

    val state: StateFlow<HomeUiState> = combine(month, metric, today) { m, mt, td -> Triple(m, mt, td) }
        .flatMapLatest { (m, mt, td) ->
            val monthStart = m.atDay(1)
            val monthEnd = m.atEndOfMonth()
            val from = if (monthStart.isBefore(td)) monthStart else td
            val to = if (monthEnd.isAfter(td)) monthEnd else td
            logs.observeBetween(from, to).map { entries ->
                HomeUiState(
                    month = m,
                    metric = mt,
                    today = td,
                    stats = HomeAggregator.aggregate(entries, moduleIds, td, m, mt),
                    canGoNext = m.isBefore(YearMonth.from(td)),
                )
            }
        }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            HomeUiState(
                month = month.value,
                metric = metric.value,
                today = LocalDate.now(clock),
                stats = HomeAggregator.aggregate(emptyList(), moduleIds, LocalDate.now(clock), month.value, metric.value),
                canGoNext = false,
            ),
        )

    val sessionActive: StateFlow<Boolean> = sessions.session
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun previousMonth() { month.value = month.value.minusMonths(1) }

    fun nextMonth() {
        val next = month.value.plusMonths(1)
        if (!next.isAfter(YearMonth.now(clock))) month.value = next
    }

    fun setMetric(value: Metric) { metric.value = value }
}
