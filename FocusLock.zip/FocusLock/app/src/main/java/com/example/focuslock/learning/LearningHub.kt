package com.example.focuslock.learning

import android.content.Context
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.LearningDao
import com.example.focuslock.data.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Effective Learning settings (requiredMinutes already reflects the debug toggle). */
data class LearningConfig(
    val startUrl: String,
    val requiredMinutes: Int,
    val storedRequiredMinutes: Int,
    val minWatchedShare: Int,
    val lastUrl: String?,
    val debug: Boolean,
) {
    companion object {
        val DEFAULT = LearningConfig(
            startUrl = LearningDefaults.START_URL,
            requiredMinutes = LearningDefaults.REQUIRED_MINUTES,
            storedRequiredMinutes = LearningDefaults.REQUIRED_MINUTES,
            minWatchedShare = LearningDefaults.MIN_WATCHED_SHARE,
            lastUrl = null,
            debug = false,
        )
    }
}

/** Everything the Learning feature shares: settings, the study ledger, the notifier and the "open study view" request. */
class LearningHub(
    appContext: Context,
    val settings: SettingsRepository,
    dao: LearningDao,
    logs: ActivityLogRepository,
    val scope: CoroutineScope,
) {
    val config: StateFlow<LearningConfig> = combine(
        settings.learningStartUrl,
        settings.learningRequiredMinutes,
        settings.learningMinWatchedShare,
        settings.learningLastUrl,
        settings.debugEnabled,
    ) { startUrl, stored, share, last, debug ->
        LearningConfig(
            startUrl = startUrl,
            requiredMinutes = LearningRules.effectiveRequiredMinutes(stored, debug),
            storedRequiredMinutes = stored,
            minWatchedShare = share,
            lastUrl = last,
            debug = debug,
        )
    }.stateIn(scope, SharingStarted.Eagerly, LearningConfig.DEFAULT)

    private val notifier = StudyNotifier(appContext.applicationContext)

    val ledger: StudyLedger = StudyLedger(
        store = RoomStudyStore(dao),
        sink = ActivityLogStudySink(logs),
        requiredMinutes = { config.value.requiredMinutes },
        minSharePercent = { config.value.minWatchedShare },
        onRequirementMet = { notifier.notifyRequirementComplete() },
    )

    /** Set by "Start learning session"; the optional task's card consumes it and opens the study view. */
    private val _openStudyRequest = MutableStateFlow(false)
    val openStudyRequest: StateFlow<Boolean> = _openStudyRequest

    fun requestOpenStudy() {
        _openStudyRequest.value = true
    }

    fun consumeOpenStudyRequest() {
        _openStudyRequest.value = false
    }

    /** Fire-and-forget flush on the app scope (the composition may already be gone). Never throws. */
    fun flushAsync() {
        scope.launch {
            try {
                ledger.flush()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // The next flush retries; the ledger only clears its dirty state after a successful write.
            }
        }
    }

    fun saveLastUrlAsync(url: String) {
        scope.launch {
            try {
                settings.setLearningLastUrl(url)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
            }
        }
    }
}
