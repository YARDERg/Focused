package com.example.focuslock.scheduler

import com.example.focuslock.domain.LogSource
import com.example.focuslock.domain.TimeFormat
import com.example.focuslock.domain.TimeWindow
import com.example.focuslock.domain.stats.LogEntry
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

enum class ChangeVerdict { ALLOWED, TODAY_NOT_COMPLETED, ALREADY_CHANGED }

/** Pure rules for "Change tomorrow's time" (no Android types, unit tested on the JVM). */
object TomorrowChange {

    /**
     * (a) today's scheduled session must be completed (unless the debug bypass is active),
     * (b) at most one change: no override may exist yet for tomorrow.
     * "Already changed" wins, because it is final.
     */
    fun verdict(
        todayCompleted: Boolean,
        tomorrowOverrideExists: Boolean,
        bypassCompletion: Boolean,
    ): ChangeVerdict = when {
        tomorrowOverrideExists -> ChangeVerdict.ALREADY_CHANGED
        !todayCompleted && !bypassCompletion -> ChangeVerdict.TODAY_NOT_COMPLETED
        else -> ChangeVerdict.ALLOWED
    }

    fun disabledReason(verdict: ChangeVerdict): String? = when (verdict) {
        ChangeVerdict.ALLOWED -> null
        ChangeVerdict.TODAY_NOT_COMPLETED -> "Finish today's session first."
        ChangeVerdict.ALREADY_CHANGED -> "Already changed for tomorrow."
    }

    /** (c) the time must lie inside the module's allowed window. Returns an error message or null. */
    fun validate(minutes: Int, window: TimeWindow): String? =
        if (minutes in window) null
        else "Pick a time between ${TimeFormat.format12h(window.startMinutes)} and ${TimeFormat.format12h(window.endMinutes)}."
}

/** Decides whether a module's scheduled session of a given date was completed with Unlock. */
object CompletionRule {

    /**
     * True when a log with source "scheduled_session" exists for [moduleId] whose session STARTED on
     * [date] (local zone). Test sessions never count.
     */
    fun isCompletedOn(entries: List<LogEntry>, moduleId: String, date: LocalDate, zone: ZoneId): Boolean =
        entries.any {
            it.moduleId == moduleId &&
                it.source == LogSource.SCHEDULED &&
                Instant.ofEpochMilli(it.startedAt).atZone(zone).toLocalDate() == date
        }
}
