package com.example.focuslock.modules

import androidx.compose.runtime.Composable
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.SessionKind
import com.example.focuslock.domain.Task
import com.example.focuslock.domain.TimeWindow
import com.example.focuslock.scheduler.ScheduleDefaults
import com.example.focuslock.walking.WalkingMainTask
import com.example.focuslock.walking.WalkingPageCard

/**
 * Walking: all-day step tracking (Recording API) plus a scheduled steps session (live sensor in a health foreground
 * service). There is no optional walking session.
 */
class WalkingModule(private val appContainer: AppContainer) : ScheduledModule(
    container = appContainer,
    id = ModuleIds.WALKING,
    title = "Walking",
    defaultScheduleMinutes = ScheduleDefaults.WALKING_MINUTES,
    iconEmoji = "\uD83D\uDEB6",
    allowedWindow = TimeWindow(ScheduleDefaults.WALKING_WINDOW_START, ScheduleDefaults.WALKING_WINDOW_END),
    recordsSteps = true,
) {
    override fun createTasks(kind: SessionKind): List<Task> = when (kind) {
        SessionKind.SCHEDULED -> listOf(WalkingMainTask(appContainer.walking))
        SessionKind.OPTIONAL -> emptyList()      // no optional walking session
    }

    @Composable
    override fun Extras() {
        WalkingPageCard(appContainer)
    }
}
