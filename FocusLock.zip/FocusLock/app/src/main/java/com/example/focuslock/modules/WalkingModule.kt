package com.example.focuslock.modules

import com.example.focuslock.AppContainer
import com.example.focuslock.domain.Task
import com.example.focuslock.scheduler.ScheduleDefaults

class WalkingModule(container: AppContainer) : ScheduledModule(
    container = container,
    id = ModuleIds.WALKING,
    title = "Walking",
    defaultScheduleMinutes = ScheduleDefaults.WALKING_MINUTES,
    iconEmoji = "🚶",
) {
    // Placeholder: the steps-based health task replaces this in a later stage.
    override fun createTasks(): List<Task> =
        listOf(PlaceholderTask("walking.test_task", "Walking: complete test task"))
}
