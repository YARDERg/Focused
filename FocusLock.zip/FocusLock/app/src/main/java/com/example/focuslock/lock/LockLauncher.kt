package com.example.focuslock.lock

import android.content.Context
import android.content.Intent

object LockLauncher {
    fun launch(context: Context) {
        val intent = Intent(context, LockActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        )
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            // Background activity start can be refused; the foreground-service watchdog retries.
        }
    }
}
