package com.example.focuslock.lock

import android.content.Context
import android.content.Intent
import android.util.Log

object LockLauncher {
    private const val TAG = "LockLauncher"

    /** Never throws: a refused background start is retried by the watchdog. */
    fun launch(context: Context) {
        try {
            val intent = Intent(context, LockActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            )
            context.startActivity(intent)
        } catch (t: Throwable) {
            Log.w(TAG, "Lock relaunch failed: $t")
        }
    }
}
