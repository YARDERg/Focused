package com.example.focuslock.learning

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.ZoneId
import kotlin.math.max

data class LectureState(
    val key: String,
    val creditedMs: Long = 0L,
    val maxPositionSec: Double = 0.0,
    val durationSec: Double = 0.0,
    val watched: Boolean = false,
)

data class DayRecord(val creditedMs: Long, val requirementNotified: Boolean)

/** What the UI shows for the current local day. */
data class DaySnapshot(
    val date: String,
    val creditedMs: Long,
    val lecturesWatched: Int,
    val requirementNotified: Boolean,
) {
    val creditedMinutes: Int get() = (creditedMs / 60_000L).toInt()
}

/** Persistence port (Room in the app, a fake in tests). */
interface StudyStore {
    suspend fun loadDay(date: String): DayRecord?
    suspend fun loadLectures(date: String): List<LectureState>
    suspend fun saveDay(date: String, record: DayRecord)
    suspend fun saveLectures(date: String, lectures: List<LectureState>)
}

/** Where finished study episodes go (one ActivityLog row each). */
interface StudyLogSink {
    suspend fun writeStudyRow(date: String, startedAt: Long, endedAt: Long, durationSeconds: Long, newlyWatched: Int)
}

/**
 * Single accumulator of credited study time. Every credit goes through [record], so a second of study can only
 * be counted once. It keeps the current local day in memory, persists it at most every
 * [LearningDefaults.PERSIST_INTERVAL_MS] ([persistIfDue]), and turns each study episode into ONE log row on
 * [flush] (study view closed, app paused/stopped, Unlock) or when the date changes.
 */
class StudyLedger(
    private val store: StudyStore,
    private val sink: StudyLogSink,
    private val requiredMinutes: () -> Int,
    private val minSharePercent: () -> Int,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val zone: () -> ZoneId = { ZoneId.systemDefault() },
    private val onRequirementMet: suspend (date: String) -> Unit = {},
) {
    private val mutex = Mutex()

    private var date: String? = null
    private var creditedMs = 0L
    private var notified = false
    private val lectures = LinkedHashMap<String, LectureState>()
    private val dirtyLectures = LinkedHashSet<String>()
    private var dayDirty = false
    private var lastPersistAt = 0L

    // The open study episode.
    private var epDate: String? = null
    private var epStart = 0L
    private var epLastAt = 0L
    private var epMs = 0L
    private var epWatched = 0

    private val _snapshot = MutableStateFlow(DaySnapshot("", 0L, 0, false))
    val snapshot: StateFlow<DaySnapshot> = _snapshot.asStateFlow()

    /** Loads today's progress (and rolls over at midnight). Cheap when nothing changed. */
    suspend fun refreshDay() {
        mutex.withLock { ensureDay(clock()) }
    }

    /**
     * Adds [deltaMs] of credited time (may be 0) to the lecture [key] and updates its max playhead position.
     * Returns the lecture's new state.
     */
    suspend fun record(key: String, deltaMs: Long, positionSec: Double, durationSec: Double): LectureState =
        mutex.withLock {
            val now = clock()
            ensureDay(now)
            val today = date ?: ""
            val before = lectures[key] ?: LectureState(key)
            val dur = if (durationSec > 0.0) durationSec else before.durationSec
            val pos = if (dur > 0.0) positionSec.coerceIn(0.0, dur) else positionSec.coerceAtLeast(0.0)
            val newMax = max(before.maxPositionSec, pos)
            val delta = deltaMs.coerceAtLeast(0L)
            val credited = before.creditedMs + delta
            val isWatched = before.watched ||
                WatchedRule.evaluate(newMax, dur, credited, minSharePercent()).watched
            val after = LectureState(key, credited, newMax, dur, isWatched)
            if (after != before) {
                lectures[key] = after
                dirtyLectures.add(key)
            }
            val newlyWatched = !before.watched && isWatched

            if (delta > 0L || newlyWatched) {
                if (epDate == null) {
                    epDate = today
                    epStart = now
                    epMs = 0L
                    epWatched = 0
                }
                epLastAt = now
                epMs += delta
                if (newlyWatched) epWatched += 1
            }
            if (delta > 0L) {
                creditedMs += delta
                dayDirty = true
            }

            var fireDate: String? = null
            if (!notified && creditedMs >= requiredMinutes() * 60_000L) {
                notified = true
                dayDirty = true
                fireDate = today
            }
            publish()
            if (fireDate != null) {
                persistLocked(now)                 // the notified flag must survive a crash
                try {
                    onRequirementMet(fireDate)
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    // A failed notification never affects crediting.
                }
            }
            after
        }

    /** Persists the day if something changed and the last persist is older than the interval. */
    suspend fun persistIfDue() {
        mutex.withLock {
            val now = clock()
            if ((dayDirty || dirtyLectures.isNotEmpty()) && now - lastPersistAt >= LearningDefaults.PERSIST_INTERVAL_MS) {
                persistLocked(now)
            }
        }
    }

    /** Persists everything and writes the open episode as one study row. Safe to call any time. */
    suspend fun flush() {
        mutex.withLock {
            persistLocked(clock())
            flushEpisodeLocked(dropRemainder = false)
        }
    }

    // ---- internals (call with the mutex held) ----

    private suspend fun ensureDay(now: Long) {
        val key = DayKey.of(now, zone())
        if (date == key) return
        if (date != null) {
            persistLocked(now)
            flushEpisodeLocked(dropRemainder = true)
        }
        val record = store.loadDay(key)
        val loaded = store.loadLectures(key)
        creditedMs = record?.creditedMs ?: 0L
        notified = record?.requirementNotified ?: false
        lectures.clear()
        loaded.forEach { lectures[it.key] = it }
        dirtyLectures.clear()
        dayDirty = false
        lastPersistAt = now
        date = key
        publish()
    }

    private suspend fun persistLocked(now: Long) {
        val d = date ?: return
        if (dayDirty) {
            store.saveDay(d, DayRecord(creditedMs, notified))
            dayDirty = false
        }
        if (dirtyLectures.isNotEmpty()) {
            store.saveLectures(d, dirtyLectures.mapNotNull { lectures[it] })
            dirtyLectures.clear()
        }
        lastPersistAt = now
    }

    private suspend fun flushEpisodeLocked(dropRemainder: Boolean) {
        val d = epDate ?: return
        val seconds = epMs / 1000L
        if (seconds == 0L && epWatched == 0) {
            if (dropRemainder) resetEpisode()
            return                                   // nothing worth a row yet; keep accumulating
        }
        sink.writeStudyRow(d, epStart, epLastAt, seconds, epWatched)
        if (dropRemainder) {
            resetEpisode()
        } else {
            epMs -= seconds * 1000L                  // sub-second remainder carries into the next episode
            epWatched = 0
            if (epMs == 0L) resetEpisode() else epStart = epLastAt
        }
    }

    private fun resetEpisode() {
        epDate = null
        epMs = 0L
        epWatched = 0
        epStart = 0L
        epLastAt = 0L
    }

    private fun publish() {
        _snapshot.value = DaySnapshot(
            date = date ?: "",
            creditedMs = creditedMs,
            lecturesWatched = lectures.values.count { it.watched },
            requirementNotified = notified,
        )
    }
}
