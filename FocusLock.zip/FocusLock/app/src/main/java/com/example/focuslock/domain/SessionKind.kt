package com.example.focuslock.domain

/** How a lock session was started. Task ids differ per kind (e.g. learning.main vs learning.optional). */
enum class SessionKind {
    /** Started by the daily alarm (or by "Test session now"). */
    SCHEDULED,

    /** Started by the user from a module page (e.g. Learning > "Start learning session"). */
    OPTIONAL;

    companion object {
        /** Unknown or missing names (older persisted sessions) decode as [SCHEDULED]. */
        fun parse(name: String?): SessionKind = entries.firstOrNull { it.name == name } ?: SCHEDULED
    }
}
