package com.example.focuslock.walking

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.ZoneId

/**
 * Copies Recording API data into Room and keeps the Daily numbers right. Everything is idempotent: hours are upserted
 * by their start, day rows by date, ledger rows by key, so re-reading the last 48 h (late data) never duplicates.
 *
 *  Daily(date) = whole-local-day aggregate (one range read)  -  sum of the session raw steps of that date.
 *  Both reads use the same API and exact [start, end) boundaries, so Day raw = Daily + session raw by construction
 *  (error: at most one data point at each boundary).
 */
class StepsMirror(
    private val source: StepsSource,
    private val store: StepsStore,
    private val sink: WalkLogSink,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val zone: () -> ZoneId = { ZoneId.systemDefault() },
) {
    private val mutex = Mutex()

    /** Full pass: last 48 h of hourly buckets, raw refresh of sessions ended within 24 h, day totals of the last 3 days. */
    suspend fun run(): MirrorResult = mutex.withLock {
        val now = clock()
        val st = source.status()
        if (!st.ok) return@withLock MirrorResult(false, now, "skipped: ${st.availability} ${st.detail}".trim())
        try {
            val z = zone()
            val from = HourMath.hourStart(now - WalkingDefaults.MIRROR_LOOKBACK_MS, z)
            val hours = source.readHourly(from, now)
            var written = 0
            if (hours != null) {
                val useful = hours.filter { it.rawSteps > 0 }
                store.upsertHours(useful)
                written = useful.size
            }
            val refreshed = refreshSessionsLocked(now)
            var days = 0
            val today = DayMath.dateOf(now, z)
            for (i in (WalkingDefaults.MIRROR_DAYS - 1) downTo 0) {
                if (updateDayLocked(today.minusDays(i.toLong()).toString(), now)) days++
            }
            val ok = hours != null && days > 0
            MirrorResult(ok, now, if (ok) "ok" else "partial: some reads failed", written, days, refreshed)
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            MirrorResult(false, now, "failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /** Cheap refresh of one day (app open, Walking page). */
    suspend fun refreshDay(date: String): Boolean = mutex.withLock {
        val st = source.status()
        if (!st.ok) return@withLock false
        updateDayLocked(date, clock())
    }

    /** Raw steps of the open session so far, split by date (read-only; nothing is stored). */
    suspend fun readSessionRaw(startMs: Long, endMs: Long): Pair<Int, Map<String, Int>>? {
        val z = zone()
        val map = LinkedHashMap<String, Int>()
        for (seg in DayMath.segments(startMs, endMs, z)) {
            val r = source.readSteps(seg.startMs, seg.endMs) ?: return null
            map[seg.date] = r
        }
        return map.values.sum() to map
    }

    /** A new session begins (no raw data yet). Any stale open row is the caller's business. */
    suspend fun openSession(startMs: Long) = mutex.withLock {
        store.upsertSession(SessionRow(startMs, SessionRow.OPEN, 0, 0L, 0, "", 0, 0L))
    }

    /**
     * Ends the session: stores sessionRawSteps with exact range reads, writes the ledger row and refreshes the
     * affected days. If the source is unavailable the raw value stays 0 and later mirror runs fill it in (24 h).
     */
    suspend fun closeSession(startMs: Long, endMs: Long, steps: Int, walkingMs: Long, ignored: Int): MirrorResult =
        mutex.withLock {
            val now = clock()
            val z = zone()
            var raw = 0
            var map: Map<String, Int> = emptyMap()
            var refreshedAt = 0L
            if (source.status().ok) {
                val r = readSessionRaw(startMs, endMs)
                if (r != null) {
                    raw = r.first
                    map = r.second
                    refreshedAt = now
                }
            }
            store.upsertSession(
                SessionRow(startMs, endMs, steps, walkingMs, raw, RawByDay.encode(map), ignored, refreshedAt)
            )
            sink.upsertSession(DayMath.dateOf(startMs, z).toString(), startMs, endMs, steps, walkingMs / 1000L)
            var days = 0
            val segs = DayMath.segments(startMs, endMs, z)
            for (seg in segs) if (updateDayLocked(seg.date, now)) days++
            MirrorResult(true, now, "session closed", 0, days, 1)
        }

    /** Developer exit: the session never happened. Its steps count as Daily again (nothing is excluded any more). */
    suspend fun discardSession(startMs: Long) = mutex.withLock {
        val now = clock()
        val z = zone()
        store.deleteSession(startMs)
        sink.deleteSession(startMs)
        if (source.status().ok) {
            for (seg in DayMath.segments(startMs, maxOf(now, startMs + 1), z)) updateDayLocked(seg.date, now)
        }
    }

    // ---- internals (mutex held) ----

    private suspend fun refreshSessionsLocked(now: Long): Int {
        var n = 0
        val recent = store.sessionsEndedSince(now - WalkingDefaults.SESSION_RAW_REFRESH_MS)
        for (s in recent) {
            val r = readSessionRaw(s.startEpochMs, s.endEpochMs) ?: continue
            // Late data only adds steps: keep the larger value per day.
            val old = RawByDay.decode(s.rawByDay)
            val merged = LinkedHashMap<String, Int>()
            for ((d, v) in r.second) merged[d] = maxOf(v, old[d] ?: 0)
            store.upsertSession(
                s.copy(sessionRawSteps = merged.values.sum(), rawByDay = RawByDay.encode(merged), rawRefreshedAt = now)
            )
            n++
        }
        return n
    }

    /** Recomputes one day. Returns false (and changes nothing) when the whole-day read failed. */
    private suspend fun updateDayLocked(date: String, now: Long): Boolean {
        val z = zone()
        val local = java.time.LocalDate.parse(date)
        val start = DayMath.dayStart(local, z)
        val end = DayMath.dayEnd(local, z)
        val read = source.readSteps(start, end) ?: return false
        val existing = store.getDay(date)
        val dayRaw = DailyMath.mergeRaw(existing?.dayRawSteps ?: 0, read)
        var sessionRaw = 0
        for (s in store.sessionsOverlapping(start, end)) {
            sessionRaw += if (s.isOpen) {
                // Running session: its raw steps so far (same API, same boundaries).
                val from = maxOf(s.startEpochMs, start)
                val to = minOf(now, end)
                (if (to > from) source.readSteps(from, to) else 0) ?: (RawByDay.decode(s.rawByDay)[date] ?: 0)
            } else {
                RawByDay.decode(s.rawByDay)[date] ?: 0
            }
        }
        val daily = DailyMath.daily(dayRaw, sessionRaw)
        store.upsertDay(DayRow(date, existing?.requirementNotified ?: false, dayRaw, daily, now))
        sink.upsertDaily(date, start, end, daily)
        return true
    }
}
