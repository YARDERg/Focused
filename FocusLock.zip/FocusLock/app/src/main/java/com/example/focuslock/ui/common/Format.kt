package com.example.focuslock.ui.common

import com.example.focuslock.domain.stats.Metric
import com.example.focuslock.domain.stats.Totals
import java.text.NumberFormat

object Format {
    fun duration(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        return if (h > 0) "$h h ${m.toString().padStart(2, '0')} min" else "$m min"
    }

    fun metric(metric: Metric, totals: Totals): String = when (metric) {
        Metric.HOURS -> duration(totals.seconds)
        Metric.SESSIONS -> totals.sessions.toString()
        Metric.STEPS -> NumberFormat.getIntegerInstance().format(totals.steps)
    }
}
