package com.example.focuslock.diag

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Installs the global crash recorder and reads the data shown in Settings (debug only). */
object Diagnostics {

    private const val CRASH_DIR = "crashes"

    fun install(context: Context) {
        val store = CrashStore(File(context.applicationContext.filesDir, CRASH_DIR))
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                store.record(throwable, thread.name, System.currentTimeMillis())
            } catch (_: Throwable) {
                // Recording must never mask the real crash.
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    fun collect(context: Context): DiagnosticsReport {
        val app = context.applicationContext
        val crashes = try {
            CrashStore(File(app.filesDir, CRASH_DIR)).readAll()
        } catch (t: Throwable) {
            listOf("Could not read crash files: $t")
        }
        return DiagnosticsReport(crashes = crashes, exits = readExitReasons(app, 10))
    }

    private fun readExitReasons(context: Context, max: Int): List<String> {
        if (Build.VERSION.SDK_INT < 30) return listOf("Exit reasons need Android 11 or newer.")
        return try {
            val am = context.getSystemService(ActivityManager::class.java)
            val list = am.getHistoricalProcessExitReasons(context.packageName, 0, max)
            if (list.isEmpty()) listOf("No recorded process exits.") else list.map { format(it) }
        } catch (t: Throwable) {
            listOf("Could not read exit reasons: $t")
        }
    }

    @RequiresApi(30)
    private fun format(info: ApplicationExitInfo): String {
        val time = TIME.format(Instant.ofEpochMilli(info.timestamp).atZone(ZoneId.systemDefault()))
        return "reason=${reasonName(info.reason)}, description=${info.description}, " +
            "time=$time, importance=${importanceName(info.importance)}"
    }

    private fun reasonName(reason: Int): String = when (reason) {
        0 -> "UNKNOWN"
        1 -> "EXIT_SELF"
        2 -> "SIGNALED"
        3 -> "LOW_MEMORY"
        4 -> "CRASH"
        5 -> "CRASH_NATIVE"
        6 -> "ANR"
        7 -> "INITIALIZATION_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        13 -> "OTHER"
        14 -> "FREEZER"
        15 -> "PACKAGE_STATE_CHANGE"
        16 -> "PACKAGE_UPDATED"
        else -> "CODE_$reason"
    }

    private fun importanceName(importance: Int): String = when (importance) {
        100 -> "FOREGROUND"
        125 -> "FOREGROUND_SERVICE"
        150 -> "TOP_SLEEPING"
        200 -> "VISIBLE"
        230 -> "PERCEPTIBLE"
        300 -> "SERVICE"
        400 -> "CACHED"
        1000 -> "GONE"
        else -> "CODE_$importance"
    }

    private val TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss a", Locale.US)
}

data class DiagnosticsReport(val crashes: List<String>, val exits: List<String>) {
    fun asText(): String = buildString {
        appendLine("## Last crashes (newest first)")
        if (crashes.isEmpty()) appendLine("None recorded.") else crashes.forEach { appendLine(it); appendLine() }
        appendLine("## Last process exits (newest first)")
        exits.forEach { appendLine(it) }
    }
}
