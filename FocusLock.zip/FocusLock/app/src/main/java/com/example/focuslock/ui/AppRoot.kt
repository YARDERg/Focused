package com.example.focuslock.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.ModuleRegistry
import com.example.focuslock.ui.home.HomeScreen
import com.example.focuslock.ui.settings.SettingsScreen

private const val TAB_HOME = "tab:home"
private const val TAB_SETTINGS = "tab:settings"

private data class Tab(val key: String, val label: String, val emoji: String)

/** Tabs are Home + whatever modules the registry holds + Settings (not hard-wired to two modules). */
private fun buildTabs(registry: ModuleRegistry): List<Tab> =
    listOf(Tab(TAB_HOME, "Home", "🏠")) +
        registry.modules.map { Tab(it.id, it.title, it.iconEmoji) } +
        Tab(TAB_SETTINGS, "Settings", "⚙")

@Composable
fun AppRoot(container: AppContainer) {
    val tabs = remember(container) { buildTabs(container.registry) }
    var selected by rememberSaveable { mutableStateOf(TAB_HOME) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = selected == tab.key,
                        onClick = { selected = tab.key },
                        icon = { Text(tab.emoji) },
                        label = { Text(tab.label, maxLines = 1) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (selected) {
                TAB_HOME -> HomeScreen(container)
                TAB_SETTINGS -> SettingsScreen(container)
                else -> container.registry.byId(selected)?.Screen()
            }
        }
    }
}
