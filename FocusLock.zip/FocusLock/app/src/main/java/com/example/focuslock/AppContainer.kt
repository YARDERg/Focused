package com.example.focuslock

import android.content.Context
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.AppDatabase
import com.example.focuslock.data.ScheduleRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.data.buildDatabase
import com.example.focuslock.domain.ModuleRegistry
import com.example.focuslock.learning.LearningHub
import com.example.focuslock.learning.LearningMainTask
import com.example.focuslock.lock.SessionManager
import com.example.focuslock.modules.HabitsModule
import com.example.focuslock.modules.LearningModule
import com.example.focuslock.modules.WalkingModule
import com.example.focuslock.walking.WalkingHub
import com.example.focuslock.walking.WalkingMainTask
import com.example.focuslock.scheduler.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Manual dependency container, created once in [FocusLockApp]. */
class AppContainer(private val appContext: Context) {
    val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings: SettingsRepository by lazy { SettingsRepository(appContext) }
    val database: AppDatabase by lazy { buildDatabase(appContext) }
    val activityLogs: ActivityLogRepository by lazy { ActivityLogRepository(database.activityLogDao()) }
    val schedules: ScheduleRepository by lazy { ScheduleRepository(database.scheduleOverrideDao()) }

    /** Add future modules (Habits-as-dynamic, Udemy, ...) here; the engine only sees FeatureModule. */
    val registry: ModuleRegistry by lazy {
        ModuleRegistry(listOf(LearningModule(this), WalkingModule(this), HabitsModule()))
    }

    /** Learning (Udemy study view): settings, the study ledger, notifier. Created lazily; modules only see it via tasks. */
    val learning: LearningHub by lazy {
        LearningHub(
            appContext, settings, database.learningDao(), activityLogs, scope,
            scheduledTaskActive = {
                sessions.session.value?.entries?.any { it.task.id == LearningMainTask.TASK_ID } == true
            },
        )
    }

    /** Walking (all-day steps + the scheduled steps session): settings, tracker, mirror, ledger, notifier. */
    val walking: WalkingHub by lazy {
        WalkingHub(
            appContext, settings, database.stepsDao(), activityLogs, scope,
            scheduledTaskActive = {
                sessions.session.value?.entries?.any { it.task.id == WalkingMainTask.TASK_ID } == true
            },
            awaitSessionsReady = { sessions.awaitReady() },
        )
    }

    val sessions: SessionManager by lazy {
        SessionManager(
            settings = settings,
            registry = registry,
            logs = activityLogs,
            scope = scope,
            beforeUnlock = { learning.ledger.flush() },     // study episode becomes its ActivityLog row before Unlock
            // Walking: record the end, stop the step service, store sessionRawSteps, write the ledger (or forget it on a developer exit).
            afterSessionEnd = { endMs, discarded -> walking.endSessionAsync(endMs, discarded) },
        )
    }
    val scheduler: AlarmScheduler by lazy { AlarmScheduler(appContext, registry, settings, schedules) }
}
