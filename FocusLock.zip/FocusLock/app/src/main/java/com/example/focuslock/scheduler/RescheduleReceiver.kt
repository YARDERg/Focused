package com.example.focuslock.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.focuslock.FocusLockApp
import com.example.focuslock.lock.LockForegroundService
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** BOOT_COMPLETED, MY_PACKAGE_REPLACED, TIMEZONE_CHANGED, TIME_SET, exact-alarm permission changes. */
class RescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as FocusLockApp
        val pending = goAsync()
        app.container.scope.launch {
            try {
                app.container.scheduler.rescheduleAll()
                // BOOT_COMPLETED: re-subscribe the all-day step recording (persistence across reboot is unverified) and mirror.
                // Bounded so the receiver finishes inside its budget.
                withTimeoutOrNull(8_000L) { app.container.walking.onAppEvent() }
                app.container.sessions.awaitReady()
                if (app.container.sessions.session.value != null) LockForegroundService.start(app)
            } finally {
                pending.finish()
            }
        }
    }
}
