package com.example.focuslock.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.focuslock.FocusLockApp
import com.example.focuslock.lock.LockForegroundService
import kotlinx.coroutines.launch

/** BOOT_COMPLETED, MY_PACKAGE_REPLACED, TIMEZONE_CHANGED, TIME_SET, exact-alarm permission changes. */
class RescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as FocusLockApp
        val pending = goAsync()
        app.container.scope.launch {
            try {
                app.container.scheduler.rescheduleAll()
                app.container.sessions.awaitReady()
                if (app.container.sessions.session.value != null) LockForegroundService.start(app)
            } finally {
                pending.finish()
            }
        }
    }
}
