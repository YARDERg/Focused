package com.example.focuslock.walking

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.focuslock.MainActivity

/** The one local notification per day: "Walking requirement complete" on the "Walking" channel. */
class WalkingNotifier(private val context: Context) {

    /** Never throws; silently does nothing without notification permission. */
    fun notifyRequirementComplete() {
        try {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT))
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) return
            val compat = NotificationManagerCompat.from(context)
            if (!compat.areNotificationsEnabled()) return
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Walking requirement complete")
                .setContentText("You reached today's session steps. You can press Complete on the lock screen.")
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            compat.notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {
            // Notifications are a convenience; they must never break counting.
        }
    }

    companion object {
        const val CHANNEL_ID = "walking"
        const val CHANNEL_NAME = "Walking"
        private const val NOTIFICATION_ID = 2002
    }
}
