package com.example.focuslock.ui.module

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focuslock.data.ScheduleRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.domain.FeatureModule
import com.example.focuslock.lock.LockForegroundService
import com.example.focuslock.lock.LockLauncher
import com.example.focuslock.lock.SessionManager
import com.example.focuslock.scheduler.AlarmScheduler
import com.example.focuslock.scheduler.ResolvedSchedule
import com.example.focuslock.scheduler.ScheduleResolver
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Clock
import java.time.ZonedDateTime

data class ModuleUiState(
    val enabled: Boolean,
    val resolved: ResolvedSchedule,
    val canChangeToday: Boolean,
    val defaultMinutes: Int,
)

class ModuleViewModel(
    private val appContext: Context,
    private val module: FeatureModule,
    private val settings: SettingsRepository,
    private val schedules: ScheduleRepository,
    private val scheduler: AlarmScheduler,
    private val sessions: SessionManager,
    private val clock: Clock = Clock.systemDefaultZone(),
) : ViewModel() {

    private val ticker = flow {
        while (true) {
            emit(Unit)
            delay(15_000)
        }
    }

    val state: StateFlow<ModuleUiState> = combine(
        settings.moduleEnabled(module.id),
        schedules.observeOverrides(module.id),
        settings.lastFired(module.id),
        ticker,
    ) { enabled, overrides, lastFired, _ ->
        compute(enabled, overrides.map { it.date to it.minutes }, lastFired)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), compute(true, emptyList(), null))

    val sessionActive: StateFlow<Boolean> = sessions.session
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private fun compute(enabled: Boolean, overrides: List<Pair<String, Int>>, lastFired: String?): ModuleUiState {
        val now = ZonedDateTime.now(clock)
        val todayKey = now.toLocalDate().toString()
        val override = overrides.firstOrNull { it.first == todayKey }?.second
        val resolved = ScheduleResolver.resolve(now, module.defaultScheduleMinutes, override, lastFired == todayKey)
        return ModuleUiState(
            enabled = enabled,
            resolved = resolved,
            canChangeToday = resolved.isToday,
            defaultMinutes = module.defaultScheduleMinutes,
        )
    }

    fun setEnabled(value: Boolean) {
        viewModelScope.launch {
            settings.setModuleEnabled(module.id, value)
            scheduler.schedule(module.id)
        }
    }

    /** Calls [onResult] with an error message, or null when the override was saved. */
    fun setOverride(minutes: Int, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val now = ZonedDateTime.now(clock)
            val today = now.toLocalDate()
            val current = schedules.getOverride(module.id, today)
            val fired = settings.lastFiredNow(module.id) == today.toString()
            val error = when {
                !ScheduleResolver.canOverrideToday(now, module.defaultScheduleMinutes, current, fired) ->
                    "Today's session has already started."
                !ScheduleResolver.isFutureToday(now, minutes) -> "Pick a time later than now."
                else -> null
            }
            if (error == null) {
                schedules.setOverride(module.id, today, minutes)
                scheduler.schedule(module.id)
            }
            onResult(error)
        }
    }

    fun clearOverride() {
        viewModelScope.launch {
            schedules.clearOverride(module.id, ZonedDateTime.now(clock).toLocalDate())
            scheduler.schedule(module.id)
        }
    }

    /** Starts a session right now without touching alarms, overrides or lastFired. */
    fun testSession(onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val started = sessions.startSession(module.id)
            if (started) {
                LockForegroundService.start(appContext)
                LockLauncher.launch(appContext)
            }
            onResult(started)
        }
    }
}
