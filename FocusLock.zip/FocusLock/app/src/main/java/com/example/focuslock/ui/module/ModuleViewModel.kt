package com.example.focuslock.ui.module

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.ScheduleRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.domain.FeatureModule
import com.example.focuslock.domain.LogSource
import com.example.focuslock.domain.TimeWindow
import com.example.focuslock.domain.stats.LogEntry
import com.example.focuslock.lock.LockForegroundService
import com.example.focuslock.lock.LockLauncher
import com.example.focuslock.lock.SessionManager
import com.example.focuslock.scheduler.AlarmScheduler
import com.example.focuslock.scheduler.ChangeVerdict
import com.example.focuslock.scheduler.CompletionRule
import com.example.focuslock.scheduler.TomorrowChange
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Clock
import java.time.Instant
import java.time.ZonedDateTime

data class ModuleUiState(
    val enabled: Boolean,
    val todayMinutes: Int,
    /** True when today's time differs from the default (it was changed yesterday). */
    val todayChanged: Boolean,
    val todayCompleted: Boolean,
    val tomorrowMinutes: Int,
    val tomorrowChanged: Boolean,
    val window: TimeWindow,
    val defaultMinutes: Int,
    val verdict: ChangeVerdict,
    val bypassActive: Boolean,
) {
    val canChangeTomorrow: Boolean get() = verdict == ChangeVerdict.ALLOWED
}

private data class SettingsSnap(
    val enabled: Boolean,
    val lastFiredDate: String?,
    val lastFiredAt: Long?,
    val bypass: Boolean,
)

class ModuleViewModel(
    private val appContext: Context,
    private val module: FeatureModule,
    private val settings: SettingsRepository,
    private val schedules: ScheduleRepository,
    private val logs: ActivityLogRepository,
    private val scheduler: AlarmScheduler,
    private val sessions: SessionManager,
    private val clock: Clock = Clock.systemDefaultZone(),
) : ViewModel() {

    /** Serialises "Change tomorrow's time" so a double tap can never create two changes. */
    private val changeLock = Mutex()

    private val ticker = flow {
        while (true) {
            emit(Unit)
            delay(15_000)
        }
    }

    private val settingsSnap = combine(
        settings.moduleEnabled(module.id),
        settings.lastFired(module.id),
        settings.lastFiredAt(module.id),
        settings.tomorrowBypassActive,
    ) { enabled, firedDate, firedAt, bypass -> SettingsSnap(enabled, firedDate, firedAt, bypass) }

    /** Lower bound only: logs of later days are always newer, so it never goes stale. */
    private val sinceMillis: Long =
        ZonedDateTime.now(clock).toLocalDate().atStartOfDay(clock.zone).toInstant().toEpochMilli()

    val state: StateFlow<ModuleUiState> = combine(
        settingsSnap,
        schedules.observeOverrides(module.id),
        logs.observeScheduledSince(module.id, sinceMillis),
        ticker,
    ) { snap, overrides, scheduledLogs, _ ->
        compute(snap, overrides.associate { it.date to it.minutes }, scheduledLogs)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        compute(SettingsSnap(true, null, null, false), emptyMap(), emptyList()),
    )

    val sessionActive: StateFlow<Boolean> = sessions.session
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private fun compute(snap: SettingsSnap, overrides: Map<String, Int>, scheduledLogs: List<LogEntry>): ModuleUiState {
        val now = ZonedDateTime.now(clock)
        val today = now.toLocalDate()
        val tomorrow = today.plusDays(1)
        val default = module.defaultScheduleMinutes
        val todayOverride = overrides[today.toString()]
        val tomorrowOverride = overrides[tomorrow.toString()]

        // After the session fired its override row is deleted, so show the time it really fired at.
        val firedAt = snap.lastFiredAt
        val todayMinutes: Int
        val todayChanged: Boolean
        if (snap.lastFiredDate == today.toString() && firedAt != null) {
            val t = Instant.ofEpochMilli(firedAt).atZone(now.zone)
            todayMinutes = t.hour * 60 + t.minute
            todayChanged = todayMinutes != default
        } else {
            todayMinutes = todayOverride ?: default
            todayChanged = todayOverride != null
        }

        val completed = CompletionRule.isCompletedOn(scheduledLogs, module.id, today, now.zone)
        return ModuleUiState(
            enabled = snap.enabled,
            todayMinutes = todayMinutes,
            todayChanged = todayChanged,
            todayCompleted = completed,
            tomorrowMinutes = tomorrowOverride ?: default,
            tomorrowChanged = tomorrowOverride != null,
            window = module.allowedWindow,
            defaultMinutes = default,
            verdict = TomorrowChange.verdict(completed, tomorrowOverride != null, snap.bypass),
            bypassActive = snap.bypass,
        )
    }

    fun setEnabled(value: Boolean) {
        viewModelScope.launch {
            settings.setModuleEnabled(module.id, value)
            scheduler.schedule(module.id)
        }
    }

    /**
     * Saves tomorrow's time once. Every rule is re-checked against the database (not the UI state).
     * Calls [onResult] with an error message, or null when the change was saved.
     */
    fun setTomorrowTime(minutes: Int, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val error = changeLock.withLock {
                try {
                    val now = ZonedDateTime.now(clock)
                    val today = now.toLocalDate()
                    val tomorrow = today.plusDays(1)
                    val exists = schedules.getOverride(module.id, tomorrow) != null
                    val since = today.atStartOfDay(now.zone).toInstant().toEpochMilli()
                    val completed = CompletionRule.isCompletedOn(
                        logs.scheduledSince(module.id, since), module.id, today, now.zone,
                    )
                    val verdict = TomorrowChange.verdict(completed, exists, settings.isTomorrowBypassActive())
                    val problem = TomorrowChange.disabledReason(verdict) ?: TomorrowChange.validate(minutes, module.allowedWindow)
                    if (problem == null) {
                        schedules.setOverride(module.id, tomorrow, minutes)
                        scheduler.schedule(module.id)
                    }
                    problem
                } catch (t: Exception) {
                    "Could not save the change: ${t.message}"
                }
            }
            onResult(error)
        }
    }

    /** Starts a TEST session right now: no alarms, overrides or lastFired are touched, and its log never counts. */
    fun testSession(onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val started = sessions.startSession(module.id, LogSource.TEST)
            if (started) {
                LockForegroundService.start(appContext)
                LockLauncher.launch(appContext)
            }
            onResult(started)
        }
    }
}
