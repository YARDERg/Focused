package com.example.focuslock.data

import androidx.room3.Entity
import androidx.room3.Index
import androidx.room3.PrimaryKey

/** One row per completed task of a finished session. `date` is the local ISO date (yyyy-MM-dd). */
@Entity(
    tableName = "activity_log",
    indices = [Index(value = ["date"]), Index(value = ["moduleId"])],
)
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleId: String,
    val date: String,
    val startedAt: Long,
    val endedAt: Long,
    val durationSeconds: Long,
    val steps: Int? = null,
    val items: Int? = null,
    val source: String,
)

/** One-day schedule override. `date` is the local ISO date it applies to. */
@Entity(tableName = "schedule_override", primaryKeys = ["moduleId", "date"])
data class ScheduleOverrideEntity(
    val moduleId: String,
    val date: String,
    val minutes: Int,
)
