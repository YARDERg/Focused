package com.example.focuslock.data

import androidx.room3.Entity
import androidx.room3.Index
import androidx.room3.PrimaryKey

/** One row per completed task of a finished session. `date` is the local ISO date (yyyy-MM-dd). */
@Entity(
    tableName = "activity_log",
    indices = [Index(value = ["date"]), Index(value = ["moduleId"])],
)
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleId: String,
    val date: String,
    val startedAt: Long,
    val endedAt: Long,
    val durationSeconds: Long,
    val steps: Int? = null,
    val items: Int? = null,
    val source: String,
)

/** One-day schedule override. `date` is the local ISO date it applies to. */
@Entity(tableName = "schedule_override", primaryKeys = ["moduleId", "date"])
data class ScheduleOverrideEntity(
    val moduleId: String,
    val date: String,
    val minutes: Int,
)

/** Study progress of one local day (shared by scheduled and optional sessions). `date` is yyyy-MM-dd. */
@Entity(tableName = "learning_day")
data class LearningDayEntity(
    @PrimaryKey val date: String,
    val creditedMs: Long,
    val requirementNotified: Boolean,
)

/** Per-lecture progress for one local day. `lectureKey` is the Udemy lecture id or a fingerprint ("fp-..."). */
@Entity(tableName = "learning_lecture", primaryKeys = ["date", "lectureKey"])
data class LearningLectureEntity(
    val date: String,
    val lectureKey: String,
    val creditedMs: Long,
    val maxPositionSec: Double,
    val durationSec: Double,
    val watched: Boolean,
)
