package com.example.focuslock.data

import androidx.room3.Entity
import androidx.room3.Index
import androidx.room3.PrimaryKey

/** One row per completed task of a finished session. `date` is the local ISO date (yyyy-MM-dd). */
@Entity(
    tableName = "activity_log",
    indices = [Index(value = ["date"]), Index(value = ["moduleId"])],
)
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleId: String,
    val date: String,
    val startedAt: Long,
    val endedAt: Long,
    val durationSeconds: Long,
    val steps: Int? = null,
    val items: Int? = null,
    val source: String,
)

/** One-day schedule override. `date` is the local ISO date it applies to. */
@Entity(tableName = "schedule_override", primaryKeys = ["moduleId", "date"])
data class ScheduleOverrideEntity(
    val moduleId: String,
    val date: String,
    val minutes: Int,
)

/** Study progress of one local day (shared by scheduled and optional sessions). `date` is yyyy-MM-dd. */
@Entity(tableName = "learning_day")
data class LearningDayEntity(
    @PrimaryKey val date: String,
    val creditedMs: Long,
    val requirementNotified: Boolean,
)

/** Per-lecture progress for one local day. `lectureKey` is the Udemy lecture id or a fingerprint ("fp-..."). */
@Entity(tableName = "learning_lecture", primaryKeys = ["date", "lectureKey"])
data class LearningLectureEntity(
    val date: String,
    val lectureKey: String,
    val creditedMs: Long,
    val maxPositionSec: Double,
    val durationSec: Double,
    val watched: Boolean,
)

/** Stage 3: hourly raw steps mirrored from the Recording API (charts and history only). [hourStartEpoch] = epoch ms of the hour start. */
@Entity(tableName = "steps_hour")
data class StepsHourEntity(
    @PrimaryKey val hourStartEpoch: Long,
    val rawSteps: Int,
)

/**
 * Stage 3: one walking session. endEpochMs == 0 while it runs. rawByDay = "yyyy-MM-dd:steps,..." (the raw steps of the
 * exact [start, end) range split by local date). ignoredSteps and rawRefreshedAt are additions to the spec'd columns.
 */
@Entity(tableName = "walk_session")
data class WalkSessionEntity(
    @PrimaryKey val startEpochMs: Long,
    val endEpochMs: Long,
    val sessionSteps: Int,
    val sessionWalkingMs: Long,
    val sessionRawSteps: Int,
    val rawByDay: String,
    val ignoredSteps: Int,
    val rawRefreshedAt: Long,
)

/** Stage 3: one local day. dayRawSteps and dailySteps keep the history after the Recording API forgets it (10 days). */
@Entity(tableName = "steps_day")
data class StepsDayEntity(
    @PrimaryKey val date: String,
    val requirementNotified: Boolean,
    val dayRawSteps: Int,
    val dailySteps: Int,
    val updatedAt: Long,
)
