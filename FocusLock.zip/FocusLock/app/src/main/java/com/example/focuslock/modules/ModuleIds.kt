package com.example.focuslock.modules

/** Ids must not contain the characters , | @ (used by the session persistence format). */
object ModuleIds {
    const val LEARNING = "learning"
    const val WALKING = "walking"
    const val HABITS = "habits"
}
