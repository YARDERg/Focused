package com.example.focuslock.domain.session

/** Pure rule for the durationSeconds of the session rows written at Unlock. */
object UnlockDurations {

    /**
     * [ownActivity] has one flag per task of a module ([com.example.focuslock.domain.Task.reportsOwnActivity]).
     * Tasks that report their own activity get 0 (their hours come from their own rows); the elapsed time is
     * split evenly among the remaining tasks.
     */
    fun perTaskSeconds(elapsedSeconds: Long, ownActivity: List<Boolean>): List<Long> {
        val counted = ownActivity.count { !it }
        val share = if (counted == 0) 0L else (elapsedSeconds / counted).coerceAtLeast(0L)
        return ownActivity.map { if (it) 0L else share }
    }
}
