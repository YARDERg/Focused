package com.example.focuslock.learning

import kotlin.math.roundToInt

/** Pure URL helpers (no android.net.Uri, so they run in JVM tests). */
object UrlParts {
    /** Path of [url] without query and fragment ("/" when there is none). */
    fun path(url: String): String {
        val noFragment = url.substringBefore('#')
        val noQuery = noFragment.substringBefore('?')
        val afterScheme = if ("://" in noQuery) noQuery.substringAfter("://") else noQuery
        val slash = afterScheme.indexOf('/')
        return if (slash >= 0) afterScheme.substring(slash) else "/"
    }
}

object LectureId {
    private val PATTERN = Regex("/lecture/(\\d+)")

    /** Verified Udemy format: /course/<slug>/learn/lecture/<id>. Only the path is searched. */
    fun fromUrl(url: String?): String? {
        if (url.isNullOrBlank()) return null
        return PATTERN.find(UrlParts.path(url))?.groupValues?.get(1)
    }
}

data class LectureKey(val key: String, val source: String) {
    /** Only set when the key is a real Udemy lecture id. */
    val lectureId: String? get() = if (source == SOURCE_URL) key else null

    companion object {
        const val SOURCE_URL: String = "url"
        const val SOURCE_FINGERPRINT: String = "fingerprint"
    }
}

object LectureKeys {

    /** "/course/<slug>" for course URLs, otherwise the whole path. */
    fun coursePath(url: String?): String {
        if (url.isNullOrBlank()) return "/"
        val path = UrlParts.path(url).let { if (it.length > 1) it.trimEnd('/') else it }
        val segments = path.split('/').filter { it.isNotEmpty() }
        return if (segments.size >= 2 && segments[0] == "course") "/course/${segments[1]}" else path
    }

    /** FNV-1a 64 bit: stable across JVMs and runs (unlike hashCode of other types). */
    private fun fnv1a64(text: String): Long {
        var h = -3750763034362895579L          // 0xcbf29ce484222325
        for (b in text.toByteArray(Charsets.UTF_8)) {
            h = h xor (b.toLong() and 0xffL)
            h *= 1099511628211L
        }
        return h
    }

    /** hash(course path + rounded video duration + document.title). */
    fun fingerprint(coursePath: String, durationSec: Double, title: String): String {
        val rounded = if (durationSec.isFinite()) durationSec.roundToInt() else 0
        val raw = "$coursePath|$rounded|${title.trim()}"
        return "fp-" + java.lang.Long.toHexString(fnv1a64(raw))
    }

    /** Never returns null: no lecture id in the URL means the fingerprint is used. */
    fun resolve(url: String?, durationSec: Double, title: String?): LectureKey {
        val id = LectureId.fromUrl(url)
        if (id != null) return LectureKey(id, LectureKey.SOURCE_URL)
        return LectureKey(
            fingerprint(coursePath(url), durationSec, title.orEmpty()),
            LectureKey.SOURCE_FINGERPRINT,
        )
    }
}
