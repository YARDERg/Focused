package com.example.focuslock.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.focuslock.AppContainer
import com.example.focuslock.learning.HostAllowlist
import com.example.focuslock.learning.LearningDefaults
import com.example.focuslock.learning.LearningRules
import kotlinx.coroutines.launch

/** Learning settings: start URL, required minutes, minimum watched share. */
@Composable
fun LearningSettingsCard(container: AppContainer) {
    val hub = container.learning
    val config by hub.config.collectAsState()
    val scope = rememberCoroutineScope()

    var url by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("") }
    var share by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    // Fill the fields once with the stored values (the stored minutes, not the debug-adjusted effective ones).
    LaunchedEffect(Unit) {
        val c = hub.config.value
        url = c.startUrl
        minutes = c.storedRequiredMinutes.toString()
        share = c.minWatchedShare.toString()
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Learning", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = url,
                onValueChange = { url = it; message = null },
                label = { Text("Start URL (Udemy only)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = minutes,
                onValueChange = { minutes = it.filter { ch -> ch.isDigit() }.take(3); message = null },
                label = { Text("Required study minutes per day") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = share,
                onValueChange = { share = it.filter { ch -> ch.isDigit() }.take(3); message = null },
                label = { Text("Min. watched share of a lecture, % (50 to 100)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Effective requirement (scheduled session only): ${config.requiredMinutes} min. Values under " +
                    "${LearningDefaults.REQUIRED_MINUTES} min only apply while Debug info is on.",
                style = MaterialTheme.typography.bodySmall,
            )
            Button(
                onClick = {
                    val m = minutes.toIntOrNull()
                    val p = share.toIntOrNull()
                    when {
                        !HostAllowlist.isAllowedUrl(url.trim()) ->
                            message = "The start URL must be an https://...udemy.com address."
                        m == null || m < 1 -> message = "Enter at least 1 minute."
                        p == null -> message = "Enter a percentage between 50 and 100."
                        else -> scope.launch {
                            hub.settings.setLearningStartUrl(url.trim())
                            hub.settings.setLearningRequiredMinutes(m)
                            hub.settings.setLearningMinWatchedShare(LearningRules.clampShare(p))
                            message = "Saved."
                        }
                    }
                },
            ) { Text("Save") }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
