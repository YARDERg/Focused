package com.example.focuslock.scheduler

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Result of resolving which session instant is next for a module. */
data class ResolvedSchedule(
    val trigger: ZonedDateTime,
    /** True when [trigger] falls on the same local date as "now". */
    val isToday: Boolean,
    /** True when [trigger] comes from a one-day override rather than the default. */
    val isOverride: Boolean,
)

/**
 * Pure schedule logic (no Android types) so it can be unit tested on the JVM.
 *
 * An override is stored for one specific date. It is created today for TOMORROW (after today's
 * scheduled session was completed) and is deleted when that session fires. The override is
 * therefore resolved by the TRIGGER date: [todayOverrideMinutes] applies to a trigger today,
 * [tomorrowOverrideMinutes] to a trigger tomorrow.
 */
object ScheduleResolver {

    /**
     * Local date + local time in [zone]. Uses ZonedDateTime.of, so a DST gap moves the
     * time forward by the gap length and a DST overlap picks the earlier offset.
     */
    fun triggerAt(date: LocalDate, minutesOfDay: Int, zone: ZoneId): ZonedDateTime {
        val m = minutesOfDay.coerceIn(0, 24 * 60 - 1)
        return ZonedDateTime.of(date, LocalTime.of(m / 60, m % 60), zone)
    }

    /**
     * Today: the override if it is still in the future, otherwise the default if still in the future
     * (skipped entirely when [firedToday]). Otherwise tomorrow: tomorrow's override, else the default.
     */
    fun resolve(
        now: ZonedDateTime,
        defaultMinutes: Int,
        todayOverrideMinutes: Int?,
        tomorrowOverrideMinutes: Int? = null,
        firedToday: Boolean = false,
    ): ResolvedSchedule {
        val zone = now.zone
        val today = now.toLocalDate()
        if (!firedToday) {
            if (todayOverrideMinutes != null) {
                val o = triggerAt(today, todayOverrideMinutes, zone)
                if (o.isAfter(now)) return ResolvedSchedule(o, isToday = true, isOverride = true)
            }
            val d = triggerAt(today, defaultMinutes, zone)
            if (d.isAfter(now)) return ResolvedSchedule(d, isToday = true, isOverride = false)
        }
        val tomorrow = today.plusDays(1)
        return if (tomorrowOverrideMinutes != null) {
            ResolvedSchedule(triggerAt(tomorrow, tomorrowOverrideMinutes, zone), isToday = false, isOverride = true)
        } else {
            ResolvedSchedule(triggerAt(tomorrow, defaultMinutes, zone), isToday = false, isOverride = false)
        }
    }

    fun nextTrigger(
        now: ZonedDateTime,
        defaultMinutes: Int,
        todayOverrideMinutes: Int?,
        tomorrowOverrideMinutes: Int? = null,
        firedToday: Boolean = false,
    ): ZonedDateTime =
        resolve(now, defaultMinutes, todayOverrideMinutes, tomorrowOverrideMinutes, firedToday).trigger
}
