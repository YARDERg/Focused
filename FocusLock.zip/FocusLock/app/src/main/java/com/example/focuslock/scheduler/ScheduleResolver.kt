package com.example.focuslock.scheduler

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Result of resolving which session instant is next for a module. */
data class ResolvedSchedule(
    val trigger: ZonedDateTime,
    /** True when [trigger] falls on the same local date as "now". */
    val isToday: Boolean,
    /** True when [trigger] comes from today's one-day override rather than the default. */
    val isOverride: Boolean,
)

/**
 * Pure schedule logic (no Android types) so it can be unit tested on the JVM.
 *
 * Effective time = today's override if it exists and is still in the future,
 * otherwise the default. [firedToday] prevents a second session on the same
 * date after an override-time session has already fired.
 */
object ScheduleResolver {

    /**
     * Local date + local time in [zone]. Uses ZonedDateTime.of, so a DST gap moves the
     * time forward by the gap length and a DST overlap picks the earlier offset.
     */
    fun triggerAt(date: LocalDate, minutesOfDay: Int, zone: ZoneId): ZonedDateTime {
        val m = minutesOfDay.coerceIn(0, 24 * 60 - 1)
        return ZonedDateTime.of(date, LocalTime.of(m / 60, m % 60), zone)
    }

    fun resolve(
        now: ZonedDateTime,
        defaultMinutes: Int,
        todayOverrideMinutes: Int?,
        firedToday: Boolean = false,
    ): ResolvedSchedule {
        val zone = now.zone
        val today = now.toLocalDate()
        if (!firedToday) {
            if (todayOverrideMinutes != null) {
                val o = triggerAt(today, todayOverrideMinutes, zone)
                if (o.isAfter(now)) return ResolvedSchedule(o, isToday = true, isOverride = true)
            }
            val d = triggerAt(today, defaultMinutes, zone)
            if (d.isAfter(now)) return ResolvedSchedule(d, isToday = true, isOverride = false)
        }
        val tomorrow = triggerAt(today.plusDays(1), defaultMinutes, zone)
        return ResolvedSchedule(tomorrow, isToday = false, isOverride = false)
    }

    fun nextTrigger(
        now: ZonedDateTime,
        defaultMinutes: Int,
        todayOverrideMinutes: Int?,
        firedToday: Boolean = false,
    ): ZonedDateTime = resolve(now, defaultMinutes, todayOverrideMinutes, firedToday).trigger

    /** An override may only be set while today's session has not fired yet. */
    fun canOverrideToday(
        now: ZonedDateTime,
        defaultMinutes: Int,
        todayOverrideMinutes: Int?,
        firedToday: Boolean,
    ): Boolean = resolve(now, defaultMinutes, todayOverrideMinutes, firedToday).isToday

    /** True when [minutesOfDay] today is strictly later than [now]. */
    fun isFutureToday(now: ZonedDateTime, minutesOfDay: Int): Boolean =
        triggerAt(now.toLocalDate(), minutesOfDay, now.zone).isAfter(now)
}
