package com.example.focuslock.domain

class ModuleRegistry(val modules: List<FeatureModule>) {
    private val index: Map<String, FeatureModule> = modules.associateBy { it.id }

    fun byId(id: String): FeatureModule? = index[id]

    val lockingModules: List<FeatureModule>
        get() = modules.filter { it.locksPhoneOnSchedule }
}
