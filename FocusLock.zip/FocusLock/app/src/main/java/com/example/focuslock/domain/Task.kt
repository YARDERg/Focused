package com.example.focuslock.domain

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import kotlinx.coroutines.flow.StateFlow

/**
 * Provided by the lock screen around every task card: calling it opens the task's [Task.FullScreenContent].
 * The default is a no-op so a card can also be composed outside the lock screen.
 */
val LocalOpenFullScreen = staticCompositionLocalOf<() -> Unit> { {} }

/**
 * One unit of work inside a lock session.
 *
 * State lives in [completed]; UI must read it via collectAsState() AND use the value,
 * otherwise nothing recomposes.
 */
interface Task {
    val id: String
    val title: String
    val completed: StateFlow<Boolean>

    /** True when the task offers [FullScreenContent] (its card opens it through [LocalOpenFullScreen]). */
    val hasFullScreenUi: Boolean get() = false

    /**
     * True when the task writes its own activity rows while it runs (e.g. study time). At Unlock such a
     * task produces only a session row with durationSeconds = 0, so hours are not counted twice.
     */
    val reportsOwnActivity: Boolean get() = false

    fun isEnabled(): Boolean
    fun isCompleted(): Boolean = completed.value
    fun reset()

    /** Called when a persisted session is restored after process death or reboot. */
    fun restore(done: Boolean) {}

    /** Called right after [reset] when the task becomes part of a session (new or merged in). */
    suspend fun onStarted() {}

    /** Called after [restore] when the task is rebuilt from a persisted session. */
    suspend fun onRestored() {}

    /** The inline card body shown in the lock screen's task list. */
    @Composable
    fun Content()

    /** Full-screen UI; only reached when the card calls [LocalOpenFullScreen]. Must offer its own way back. */
    @Composable
    fun FullScreenContent(onClose: () -> Unit)
}
