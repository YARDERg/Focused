package com.example.focuslock.domain

import androidx.compose.runtime.Composable
import kotlinx.coroutines.flow.StateFlow

/**
 * One unit of work inside a lock session.
 *
 * State lives in [completed]; UI must read it via collectAsState() AND use the value,
 * otherwise nothing recomposes.
 */
interface Task {
    val id: String
    val title: String
    val completed: StateFlow<Boolean>

    /** When true the lock screen opens [Content] full screen instead of inline. */
    val hasFullScreenUi: Boolean get() = false

    fun isEnabled(): Boolean
    fun isCompleted(): Boolean = completed.value
    fun reset()

    /** Called when a persisted session is restored after process death or reboot. */
    fun restore(done: Boolean) {}

    @Composable
    fun Content()
}
