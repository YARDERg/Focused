package com.example.focuslock.learning

/**
 * Minimum credited study seconds an OPTIONAL session needs besides having opened the study view once.
 * 0 means: opening the study view is enough. Raise it later (e.g. 60L) to require real study time.
 */
const val OPTIONAL_MIN_CREDIT_SECONDS: Long = 0L

/** Every Learning constant in one place. */
object LearningDefaults {
    const val START_URL: String = "https://www.udemy.com"

    const val REQUIRED_MINUTES: Int = 30
    const val MIN_WATCHED_SHARE: Int = 70
    const val MIN_WATCHED_SHARE_LOW: Int = 50
    const val MIN_WATCHED_SHARE_HIGH: Int = 100

    /** A lecture is "watched" only if the playhead reached this share of the duration (percent) ... */
    const val WATCHED_POSITION_PERCENT: Int = 90

    const val SAMPLE_INTERVAL_MS: Long = 250L

    /** Credit of one sample never exceeds this, whatever the gap between samples was. */
    const val GAP_CAP_MS: Long = 5_000L

    /** Media may advance up to this factor faster than wall time x max(rate, 1) before it counts as a jump. */
    const val JITTER_FACTOR: Double = 1.3

    const val PERSIST_INTERVAL_MS: Long = 5_000L
    const val EVAL_TIMEOUT_MS: Long = 1_000L
}
