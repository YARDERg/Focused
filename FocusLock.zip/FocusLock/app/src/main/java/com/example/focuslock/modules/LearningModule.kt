package com.example.focuslock.modules

import androidx.compose.runtime.Composable
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.SessionKind
import com.example.focuslock.domain.Task
import com.example.focuslock.domain.TimeWindow
import com.example.focuslock.learning.LearningMainTask
import com.example.focuslock.learning.LearningOptionalTask
import com.example.focuslock.learning.LearningPageCard
import com.example.focuslock.scheduler.ScheduleDefaults

/**
 * Learning: Udemy in-app WebView with study-time tracking. Task ids differ per session kind
 * (learning.main for the scheduled session, learning.optional for the user-started one).
 */
class LearningModule(private val appContainer: AppContainer) : ScheduledModule(
    container = appContainer,
    id = ModuleIds.LEARNING,
    title = "Learning",
    defaultScheduleMinutes = ScheduleDefaults.LEARNING_MINUTES,
    iconEmoji = "📚",
    allowedWindow = TimeWindow(ScheduleDefaults.LEARNING_WINDOW_START, ScheduleDefaults.LEARNING_WINDOW_END),
) {
    override fun createTasks(kind: SessionKind): List<Task> = when (kind) {
        SessionKind.SCHEDULED -> listOf(LearningMainTask(appContainer.learning))
        SessionKind.OPTIONAL -> listOf(LearningOptionalTask(appContainer.learning))
    }

    @Composable
    override fun Extras() {
        LearningPageCard(appContainer)
    }
}
