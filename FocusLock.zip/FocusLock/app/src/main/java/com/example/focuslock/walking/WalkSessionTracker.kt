package com.example.focuslock.walking

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SensorKind { UNKNOWN, STEP_COUNTER, STEP_DETECTOR, NONE }

/** Everything the UI (lock card, debug panel) shows about the running session. */
data class SessionLive(
    val active: Boolean = false,
    val startMs: Long = 0L,
    val sessionSteps: Int = 0,
    val walkingMs: Long = 0L,
    val ignoredSteps: Int = 0,
    val pendingSteps: Int = 0,
    val cadence: Int = 0,
    val status: CadenceStatus = CadenceStatus.NOT_WALKING,
    val sensor: SensorKind = SensorKind.UNKNOWN,
    /** Latest raw TYPE_STEP_COUNTER value (-1 = none yet). */
    val rawCounter: Float = -1f,
    val lastSkipReason: String = "",
    /** Recording API raw steps of this session so far (debug; null = unknown). */
    val sessionRawSteps: Int? = null,
) {
    val walkingMinutes: Int get() = (walkingMs / 60_000L).toInt()
}

data class TrackerSnapshot(val startMs: Long, val sessionSteps: Int, val walkingMs: Long, val ignoredSteps: Int)

/**
 * Live accumulator of the SESSION steps (fed by the foreground service). Thread-safe: sensor events arrive on the
 * main thread, ticks on a worker. All time is passed in. Steps taken outside a session never reach this class.
 */
class WalkSessionTracker {
    private val lock = Any()
    private var counter: CadenceCounter? = null
    private var baseline = SensorBaseline()
    private var startMs = 0L
    private var prevEventAt = -1L
    private var sensor = SensorKind.UNKNOWN
    private var rawCounter = -1f
    private var extraSkip = ""
    private var sessionRaw: Int? = null

    private val _live = MutableStateFlow(SessionLive())
    val live: StateFlow<SessionLive> = _live.asStateFlow()

    val isActive: Boolean get() = synchronized(lock) { counter != null }

    fun begin(startMs: Long, thresholdPerMin: Int) = synchronized(lock) {
        init(startMs, thresholdPerMin)
        publish()
    }

    /** After process death or reboot: totals come back, the window and the sensor baseline start fresh. */
    fun restore(startMs: Long, steps: Int, walkingMs: Long, ignored: Int, thresholdPerMin: Int) = synchronized(lock) {
        init(startMs, thresholdPerMin)
        counter?.restore(steps, ignored, walkingMs)
        publish()
    }

    private fun init(startMs: Long, thresholdPerMin: Int) {
        this.startMs = startMs
        counter = CadenceCounter(thresholdPerMin)
        baseline = SensorBaseline()
        prevEventAt = -1L
        rawCounter = -1f
        extraSkip = ""
        sessionRaw = null
    }

    fun setSensor(kind: SensorKind) = synchronized(lock) {
        sensor = kind
        if (counter != null) publish()
    }

    fun setSessionRaw(value: Int?) = synchronized(lock) {
        sessionRaw = value
        if (counter != null) publish()
    }

    /** TYPE_STEP_COUNTER event (steps since boot). Returns the delta that was fed to the cadence rule. */
    fun onCounterValue(raw: Float, nowMs: Long): Int = synchronized(lock) {
        val c = counter ?: return 0
        val before = baseline.rebases
        val d = baseline.delta(raw)
        rawCounter = raw
        if (baseline.rebases != before) extraSkip = "step counter went down (reboot): baseline rebased"
        if (d > 0) {
            for (t in StepSpreader.spread(prevEventAt, nowMs, d)) c.onStep(t)
        }
        c.advance(nowMs)
        prevEventAt = nowMs
        publish()
        d
    }

    /** TYPE_STEP_DETECTOR event: exactly one step. */
    fun onDetectorStep(nowMs: Long): Unit = synchronized(lock) {
        val c = counter ?: return
        c.onStep(nowMs)
        prevEventAt = nowMs
        publish()
    }

    fun tick(nowMs: Long): Unit = synchronized(lock) {
        val c = counter ?: return
        c.advance(nowMs)
        publish()
    }

    fun snapshot(): TrackerSnapshot? = synchronized(lock) {
        val c = counter ?: return null
        val s = c.state()
        TrackerSnapshot(startMs, s.countedSteps, s.walkingMs, s.ignoredSteps)
    }

    /** Ends the session and returns the final totals (null if none was running). */
    fun end(): TrackerSnapshot? = synchronized(lock) {
        val c = counter ?: return null
        val s = c.state()
        val snap = TrackerSnapshot(startMs, s.countedSteps, s.walkingMs, s.ignoredSteps)
        counter = null
        sensor = SensorKind.UNKNOWN
        _live.value = SessionLive()
        snap
    }

    private fun publish() {
        val c = counter ?: return
        val s = c.state()
        _live.value = SessionLive(
            active = true,
            startMs = startMs,
            sessionSteps = s.countedSteps,
            walkingMs = s.walkingMs,
            ignoredSteps = s.ignoredSteps,
            pendingSteps = s.pendingSteps,
            cadence = s.cadencePerMin,
            status = s.status,
            sensor = sensor,
            rawCounter = rawCounter,
            lastSkipReason = if (s.lastSkipReason.isNotEmpty()) s.lastSkipReason else extraSkip,
            sessionRawSteps = sessionRaw,
        )
    }
}
