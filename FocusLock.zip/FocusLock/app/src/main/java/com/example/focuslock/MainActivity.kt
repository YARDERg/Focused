package com.example.focuslock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.focuslock.ui.AppRoot
import com.example.focuslock.ui.common.FocusLockTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as FocusLockApp).container
        setContent {
            FocusLockTheme {
                AppRoot(container)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Cheap and idempotent: picks up permission changes made in system settings.
        val container = (application as FocusLockApp).container
        container.scope.launch { container.scheduler.rescheduleAll() }
    }
}
