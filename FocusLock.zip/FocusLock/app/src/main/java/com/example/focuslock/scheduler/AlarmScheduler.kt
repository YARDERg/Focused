package com.example.focuslock.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.focuslock.data.ScheduleRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.domain.FeatureModule
import com.example.focuslock.domain.ModuleRegistry
import java.time.Clock
import java.time.ZonedDateTime

/** One exact alarm per locking module (distinct request codes). */
class AlarmScheduler(
    private val context: Context,
    private val registry: ModuleRegistry,
    private val settings: SettingsRepository,
    private val schedules: ScheduleRepository,
    private val clock: Clock = Clock.systemDefaultZone(),
) {
    private val alarmManager: AlarmManager = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(): Boolean =
        if (Build.VERSION.SDK_INT >= 31) alarmManager.canScheduleExactAlarms() else true

    /** Idempotent: safe to call on boot, time/zone change, permission change and app resume. */
    suspend fun rescheduleAll() {
        schedules.deleteOlderThan(ZonedDateTime.now(clock).toLocalDate())
        registry.lockingModules.forEach { schedule(it) }
    }

    suspend fun schedule(moduleId: String) {
        registry.byId(moduleId)?.let { schedule(it) }
    }

    private suspend fun schedule(module: FeatureModule) {
        if (!module.locksPhoneOnSchedule || !settings.isModuleEnabled(module.id)) {
            cancel(module.id)
            return
        }
        val now = ZonedDateTime.now(clock)
        val today = now.toLocalDate()
        val override = schedules.getOverride(module.id, today)
        val firedToday = settings.lastFiredNow(module.id) == today.toString()
        val trigger = ScheduleResolver.nextTrigger(now, module.defaultScheduleMinutes, override, firedToday)
        setAlarm(module.id, trigger.toInstant().toEpochMilli())
    }

    private fun pendingIntent(moduleId: String, triggerAtMillis: Long): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra(EXTRA_MODULE_ID, moduleId)
            .putExtra(EXTRA_TRIGGER_AT, triggerAtMillis)
        return PendingIntent.getBroadcast(
            context,
            AlarmCodes.requestCode(moduleId),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun setAlarm(moduleId: String, triggerAtMillis: Long) {
        val pi = pendingIntent(moduleId, triggerAtMillis)
        try {
            if (canScheduleExact()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                // Exact-alarm permission missing: fall back to an inexact alarm; Settings shows the warning card.
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    private fun cancel(moduleId: String) {
        alarmManager.cancel(pendingIntent(moduleId, 0L))
    }

    companion object {
        const val ACTION_FIRE = "com.example.focuslock.ACTION_FIRE"
        const val EXTRA_MODULE_ID = "module_id"
        const val EXTRA_TRIGGER_AT = "trigger_at"
    }
}
