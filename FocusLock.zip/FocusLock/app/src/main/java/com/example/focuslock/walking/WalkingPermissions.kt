package com.example.focuslock.walking

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object WalkingPermissions {

    /** ACTIVITY_RECOGNITION is a runtime permission from Android 10; before that it is implicitly granted. */
    fun hasActivityRecognition(context: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACTIVITY_RECOGNITION) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Permanently denied = it was asked before, is still not granted, and the system will not show the dialog again
     * (shouldShowRequestPermissionRationale is false after the user chose "don't ask again").
     */
    fun permanentlyDenied(activity: Activity?, askedBefore: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < 29 || activity == null) return false
        if (hasActivityRecognition(activity)) return false
        return askedBefore &&
            !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.ACTIVITY_RECOGNITION)
    }

    fun appSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun findActivity(context: Context): Activity? {
        var c: Context? = context
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return null
    }
}
