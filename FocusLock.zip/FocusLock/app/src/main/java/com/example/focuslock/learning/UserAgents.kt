package com.example.focuslock.learning

/**
 * Android WebView's default user agent contains "; wv" and "Version/4.0", which many sites use to detect an
 * embedded WebView and serve a reduced page (sometimes without the video player). These helpers make the
 * agent look like the normal Chrome browser. Pure string logic, unit tested.
 */
object UserAgents {
    private val CHROME_VERSION = Regex("Chrome/([0-9.]+)")

    /** Mobile Chrome look-alike: drops the WebView markers, keeps everything else. */
    fun asChromeMobile(default: String): String =
        default.replace("; wv)", ")").replace(" Version/4.0", "").replace("  ", " ")

    /** Desktop Chrome on Linux, with the same Chrome version as the installed WebView. */
    fun asChromeDesktop(default: String): String {
        val version = CHROME_VERSION.find(default)?.groupValues?.get(1) ?: "120.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/$version Safari/537.36"
    }

    fun forMode(default: String, desktop: Boolean): String =
        if (desktop) asChromeDesktop(default) else asChromeMobile(default)
}
