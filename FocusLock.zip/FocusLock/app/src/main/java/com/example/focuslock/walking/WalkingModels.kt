package com.example.focuslock.walking

/** One local hour of raw (Recording API) steps. [hourStartEpoch] is the epoch ms of the hour start. Charts and history only. */
data class HourRow(val hourStartEpoch: Long, val rawSteps: Int)

/** One local day. [dayRawSteps] = whole-day aggregate, [dailySteps] = dayRawSteps minus the session raw steps of that date. */
data class DayRow(
    val date: String,
    val requirementNotified: Boolean,
    val dayRawSteps: Int,
    val dailySteps: Int,
    val updatedAt: Long,
)

/**
 * One walking session. [endEpochMs] == [OPEN] while it runs. [sessionSteps] = counted by the live sensor (anti-shake),
 * [sessionRawSteps] = Recording API aggregate over exactly [startEpochMs, endEpochMs); [rawByDay] splits that raw value
 * by local date (a session may cross midnight), see [RawByDay].
 */
data class SessionRow(
    val startEpochMs: Long,
    val endEpochMs: Long,
    val sessionSteps: Int,
    val sessionWalkingMs: Long,
    val sessionRawSteps: Int,
    val rawByDay: String,
    val ignoredSteps: Int,
    val rawRefreshedAt: Long,
) {
    val isOpen: Boolean get() = endEpochMs == OPEN

    companion object {
        const val OPEN: Long = 0L
    }
}

enum class SourceAvailability { OK, NO_PERMISSION, NO_PLAY_SERVICES, UPDATE_REQUIRED, ERROR }

data class SourceStatus(val availability: SourceAvailability, val detail: String = "") {
    val ok: Boolean get() = availability == SourceAvailability.OK
}

data class SubscribeInfo(val ok: Boolean, val atMs: Long, val message: String)

data class MirrorResult(
    val ok: Boolean,
    val atMs: Long,
    val message: String,
    val hoursWritten: Int = 0,
    val daysUpdated: Int = 0,
    val sessionsRefreshed: Int = 0,
) {
    companion object {
        val NONE = MirrorResult(false, 0L, "not run yet")
    }
}

/** Where the day/hour numbers come from (the Recording API in the app, a fake in tests). All ranges are [start, end). */
interface StepsSource {
    suspend fun status(): SourceStatus
    suspend fun ensureSubscribed(): SubscribeInfo

    /** Aggregate steps over exactly [startMs, endMs); null when the read failed. */
    suspend fun readSteps(startMs: Long, endMs: Long): Int?

    /** bucketByTime(1 hour) buckets; [startMs] must be an hour start. Null when the read failed. */
    suspend fun readHourly(startMs: Long, endMs: Long): List<HourRow>?

    /** End time of the newest recorded data point (debug), or null. */
    suspend fun newestPointMs(): Long?
}

/** Persistence port for the Stage 3 tables (Room in the app, a fake in tests). */
interface StepsStore {
    suspend fun upsertHours(rows: List<HourRow>)
    suspend fun hoursBetween(fromEpoch: Long, toEpochExclusive: Long): List<HourRow>

    suspend fun getDay(date: String): DayRow?
    suspend fun upsertDay(row: DayRow)
    suspend fun daysBetween(fromDate: String, toDate: String): List<DayRow>
    /** Sets the notified flag, creating the day row if needed. */
    suspend fun markNotified(date: String)

    suspend fun upsertSession(row: SessionRow)
    suspend fun updateProgress(startEpochMs: Long, sessionSteps: Int, walkingMs: Long, ignoredSteps: Int)
    suspend fun getSession(startEpochMs: Long): SessionRow?
    suspend fun openSession(): SessionRow?
    suspend fun deleteSession(startEpochMs: Long)
    suspend fun sessionsOverlapping(fromEpoch: Long, toEpochExclusive: Long): List<SessionRow>
    suspend fun sessionsEndedSince(sinceEpoch: Long): List<SessionRow>
    suspend fun sessionsStartedBetween(fromEpoch: Long, toEpochExclusive: Long): List<SessionRow>
}

/** The ActivityLog ledger: source "walk_daily" (steps) and "walk_session" (steps + walking seconds). Idempotent. */
interface WalkLogSink {
    suspend fun upsertDaily(date: String, dayStartMs: Long, dayEndMs: Long, steps: Int)
    suspend fun upsertSession(date: String, startMs: Long, endMs: Long, steps: Int, walkingSeconds: Long)
    suspend fun deleteSession(startMs: Long)
}
