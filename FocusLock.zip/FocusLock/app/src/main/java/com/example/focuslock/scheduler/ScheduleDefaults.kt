package com.example.focuslock.scheduler

/** The single place for schedule/lock constants. Minutes are minutes after local midnight. */
object ScheduleDefaults {
    const val LEARNING_MINUTES: Int = 7 * 60      // 7:00 AM
    const val WALKING_MINUTES: Int = 21 * 60      // 9:00 PM

    const val EMERGENCY_WINDOW_MS: Long = 3 * 60 * 1000L
    const val WATCHDOG_INTERVAL_MS: Long = 2_000L
}
