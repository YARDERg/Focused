package com.example.focuslock.scheduler

/** The single place for schedule/lock constants. Minutes are minutes after local midnight. */
object ScheduleDefaults {
    const val LEARNING_MINUTES: Int = 7 * 60      // 7:00 AM
    const val WALKING_MINUTES: Int = 21 * 60      // 9:00 PM

    /** Allowed window (inclusive) for "Change tomorrow's time". Each default must lie inside its window. */
    const val LEARNING_WINDOW_START: Int = 7 * 60     // 7:00 AM
    const val LEARNING_WINDOW_END: Int = 12 * 60      // 12:00 PM
    const val WALKING_WINDOW_START: Int = 17 * 60     // 5:00 PM
    const val WALKING_WINDOW_END: Int = 23 * 60       // 11:00 PM

    const val EMERGENCY_WINDOW_MS: Long = 3 * 60 * 1000L
    const val WATCHDOG_INTERVAL_MS: Long = 500L
}
