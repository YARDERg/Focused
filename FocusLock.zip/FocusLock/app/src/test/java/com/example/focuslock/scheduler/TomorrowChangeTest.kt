package com.example.focuslock.scheduler

import com.example.focuslock.domain.TimeWindow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TomorrowChangeTest {
    private val learning = TimeWindow(ScheduleDefaults.LEARNING_WINDOW_START, ScheduleDefaults.LEARNING_WINDOW_END)
    private val walking = TimeWindow(ScheduleDefaults.WALKING_WINDOW_START, ScheduleDefaults.WALKING_WINDOW_END)

    // ---- window validation ----

    @Test
    fun learningWindowBoundsAreInclusive() {
        assertNull(TomorrowChange.validate(7 * 60, learning))          // 7:00 AM
        assertNull(TomorrowChange.validate(12 * 60, learning))         // 12:00 PM
        assertNull(TomorrowChange.validate(9 * 60 + 30, learning))
    }

    @Test
    fun learningOutsideWindowIsRejectedWithAClearMessage() {
        val early = TomorrowChange.validate(6 * 60 + 59, learning)
        val late = TomorrowChange.validate(12 * 60 + 1, learning)
        assertNotNull(early)
        assertNotNull(late)
        assertEquals("Pick a time between 7:00 AM and 12:00 PM.", early)
    }

    @Test
    fun walkingWindow() {
        assertNull(TomorrowChange.validate(17 * 60, walking))          // 5:00 PM
        assertNull(TomorrowChange.validate(23 * 60, walking))          // 11:00 PM
        assertNotNull(TomorrowChange.validate(16 * 60 + 59, walking))
        assertNotNull(TomorrowChange.validate(23 * 60 + 1, walking))
        assertEquals("Pick a time between 5:00 PM and 11:00 PM.", TomorrowChange.validate(8 * 60, walking))
    }

    @Test
    fun defaultsLieInsideTheirWindows() {
        assertTrue(ScheduleDefaults.LEARNING_MINUTES in learning)
        assertTrue(ScheduleDefaults.WALKING_MINUTES in walking)
    }

    @Test(expected = IllegalArgumentException::class)
    fun windowRejectsStartAfterEnd() {
        TimeWindow(600, 500)
    }

    // ---- completion gating (a) and once-only (b) ----

    @Test
    fun blockedUntilTodayIsCompleted() {
        val v = TomorrowChange.verdict(todayCompleted = false, tomorrowOverrideExists = false, bypassCompletion = false)
        assertEquals(ChangeVerdict.TODAY_NOT_COMPLETED, v)
        assertEquals("Finish today's session first.", TomorrowChange.disabledReason(v))
    }

    @Test
    fun allowedAfterCompletion() {
        val v = TomorrowChange.verdict(todayCompleted = true, tomorrowOverrideExists = false, bypassCompletion = false)
        assertEquals(ChangeVerdict.ALLOWED, v)
        assertNull(TomorrowChange.disabledReason(v))
    }

    @Test
    fun onlyOneChangeIsAllowed() {
        val v = TomorrowChange.verdict(todayCompleted = true, tomorrowOverrideExists = true, bypassCompletion = false)
        assertEquals(ChangeVerdict.ALREADY_CHANGED, v)
        assertEquals("Already changed for tomorrow.", TomorrowChange.disabledReason(v))
    }

    @Test
    fun bypassSkipsCompletionButNotTheOnceOnlyRule() {
        assertEquals(
            ChangeVerdict.ALLOWED,
            TomorrowChange.verdict(todayCompleted = false, tomorrowOverrideExists = false, bypassCompletion = true),
        )
        assertEquals(
            ChangeVerdict.ALREADY_CHANGED,
            TomorrowChange.verdict(todayCompleted = false, tomorrowOverrideExists = true, bypassCompletion = true),
        )
    }

    @Test
    fun alreadyChangedWinsOverNotCompleted() {
        assertEquals(
            ChangeVerdict.ALREADY_CHANGED,
            TomorrowChange.verdict(todayCompleted = false, tomorrowOverrideExists = true, bypassCompletion = false),
        )
        assertFalse(
            TomorrowChange.verdict(false, true, false) == ChangeVerdict.TODAY_NOT_COMPLETED
        )
    }
}
