package com.example.focuslock.walking

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CadenceCounterTest {

    @Test
    fun normalWalkCreditsTheBufferedWindowOnceThenEveryStep() {
        val c = CadenceCounter(thresholdPerMin = 60)
        val credits = ArrayList<Int>()
        for (i in 0 until 60) credits.add(c.onStep(i * 500L))       // 120 steps/min
        // 30 steps in the window = 60/min: the first 29 are only buffered, the 30th credits all 30 at once.
        assertTrue(credits.take(29).all { it == 0 })
        assertEquals(30, credits[29])
        assertTrue(credits.drop(30).all { it == 1 })
        val s = c.state()
        assertEquals(60, s.countedSteps)
        assertEquals(0, s.ignoredSteps)
        assertEquals(CadenceStatus.WALKING, s.status)
        assertEquals(120, s.cadencePerMin)
        assertEquals(15_000L, s.walkingMs)                          // 30 intervals of 500 ms after it qualified
    }

    @Test
    fun belowThresholdNothingCountsAndExpiredStepsAreIgnored() {
        val c = CadenceCounter(thresholdPerMin = 60)
        for (i in 0 until 40) c.onStep(i * 1500L)                   // 40 steps/min
        val s = c.state()
        assertEquals(0, s.countedSteps)
        assertEquals(CadenceStatus.NOT_WALKING, s.status)
        assertEquals(0L, s.walkingMs)
        assertEquals(40, s.ignoredSteps + s.pendingSteps)           // every step is ignored or about to be
        assertTrue(s.ignoredSteps > 0)
        assertTrue(s.lastSkipReason.contains("below"))
    }

    @Test
    fun aboveMaximumCadenceIsIgnoredAsShaking() {
        val c = CadenceCounter(thresholdPerMin = 60)
        var credited = 0
        for (i in 0 until 100) credited += c.onStep(i * 125L)       // 480 steps/min
        val s = c.state()
        assertEquals(0, credited)
        assertEquals(0, s.countedSteps)
        assertEquals(100, s.ignoredSteps)
        assertEquals(CadenceStatus.TOO_FAST, s.status)
        assertTrue(s.lastSkipReason.contains("above"))
    }

    @Test
    fun retroactiveWindowCreditsEarlySlowStepsOnceTheCadenceQualifies() {
        val c = CadenceCounter(thresholdPerMin = 60)
        for (i in 0 until 20) assertEquals(0, c.onStep(i * 1000L))  // 60/min: 20 steps buffered, not enough yet
        assertEquals(20, c.state().pendingSteps)
        var firstCredit = 0
        var j = 0
        while (firstCredit == 0) {
            firstCredit = c.onStep(19_500L + j * 500L)              // speed up to 120/min
            j++
        }
        assertEquals(30, firstCredit)                               // 20 buffered + 10 new, all credited once
        assertEquals(10, j)
        assertEquals(30, c.state().countedSteps)
        assertEquals(0, c.state().ignoredSteps)
    }

    @Test
    fun aSingleGapCreditsAtMostFiveSecondsOfWalkingTime() {
        val c = CadenceCounter(thresholdPerMin = 60)
        for (i in 0 until 60) c.onStep(i * 500L)
        assertEquals(15_000L, c.state().walkingMs)
        c.advance(29_500L + 60_000L)                                // one tick after a 60 s pause
        val s = c.state()
        assertEquals(20_000L, s.walkingMs)                          // +5 s, not +60 s
        assertEquals(CadenceStatus.NOT_WALKING, s.status)
        assertEquals(60, s.countedSteps)                            // counted steps are never taken back
        assertTrue(s.lastSkipReason.contains("gap"))
    }

    @Test
    fun walkingSecondsAreCreditedEverySecondWhileTheRuleHolds() {
        val c = CadenceCounter(thresholdPerMin = 60)
        for (i in 0 until 40) c.onStep(i * 500L)                    // qualified at step 30 (t = 14.5 s), last step at 19.5 s
        val before = c.state().walkingMs
        c.advance(20_500L)
        c.advance(21_500L)
        assertEquals(before + 2_000L, c.state().walkingMs)
    }

    @Test
    fun restoreKeepsTotalsAndRefillsTheWindow() {
        val c = CadenceCounter(thresholdPerMin = 60)
        c.restore(countedSteps = 1200, ignoredSteps = 30, walkingMs = 600_000L)
        var s = c.state()
        assertEquals(1200, s.countedSteps)
        assertEquals(30, s.ignoredSteps)
        assertEquals(600_000L, s.walkingMs)
        assertEquals(CadenceStatus.NOT_WALKING, s.status)
        for (i in 0 until 30) c.onStep(i * 500L)
        s = c.state()
        assertEquals(1230, s.countedSteps)
        assertEquals(CadenceStatus.WALKING, s.status)
    }

    @Test
    fun testThresholdsWorkForShortDebugWalks() {
        val c = CadenceCounter(thresholdPerMin = 10)                // 5 steps in the window qualify
        var credited = 0
        for (i in 0 until 5) credited += c.onStep(i * 1000L)
        assertEquals(5, credited)
    }
}
