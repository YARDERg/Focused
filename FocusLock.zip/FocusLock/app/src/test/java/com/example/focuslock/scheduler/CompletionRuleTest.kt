package com.example.focuslock.scheduler

import com.example.focuslock.domain.LogSource
import com.example.focuslock.domain.stats.LogEntry
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

class CompletionRuleTest {
    private val zone: ZoneId = ZoneOffset.UTC
    private val today = LocalDate.of(2026, 10, 2)

    private fun millis(day: Int, h: Int, m: Int = 0) =
        ZonedDateTime.of(2026, 10, day, h, m, 0, 0, zone).toInstant().toEpochMilli()

    private fun log(module: String, startedAt: Long, source: String) =
        LogEntry(module, today, startedAt, 600, null, source)

    @Test
    fun scheduledSessionStartedTodayCounts() {
        val logs = listOf(log("learning", millis(2, 7, 0), LogSource.SCHEDULED))
        assertTrue(CompletionRule.isCompletedOn(logs, "learning", today, zone))
    }

    @Test
    fun testSessionsNeverCount() {
        val logs = listOf(log("learning", millis(2, 7, 0), LogSource.TEST))
        assertFalse(CompletionRule.isCompletedOn(logs, "learning", today, zone))
    }

    @Test
    fun otherModulesDoNotCount() {
        val logs = listOf(log("walking", millis(2, 21, 0), LogSource.SCHEDULED))
        assertFalse(CompletionRule.isCompletedOn(logs, "learning", today, zone))
    }

    @Test
    fun yesterdaysSessionDoesNotCountToday() {
        val logs = listOf(log("learning", millis(1, 7, 0), LogSource.SCHEDULED))
        assertFalse(CompletionRule.isCompletedOn(logs, "learning", today, zone))
    }

    @Test
    fun sessionStartedBeforeMidnightCountsForTheDayItStarted() {
        // Walking started 11:30 PM on 1 Oct and was unlocked after midnight: it belongs to 1 Oct.
        val logs = listOf(log("walking", millis(1, 23, 30), LogSource.SCHEDULED))
        assertTrue(CompletionRule.isCompletedOn(logs, "walking", LocalDate.of(2026, 10, 1), zone))
        assertFalse(CompletionRule.isCompletedOn(logs, "walking", today, zone))
    }

    @Test
    fun aTestSessionDoesNotHideARealOne() {
        val logs = listOf(
            log("learning", millis(2, 6, 0), LogSource.TEST),
            log("learning", millis(2, 7, 0), LogSource.SCHEDULED),
        )
        assertTrue(CompletionRule.isCompletedOn(logs, "learning", today, zone))
    }
}
