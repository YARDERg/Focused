package com.example.focuslock.scheduler

import com.example.focuslock.modules.ModuleIds
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class AlarmCodesTest {
    @Test
    fun defaultModulesGetDistinctRequestCodes() {
        val codes = listOf(ModuleIds.LEARNING, ModuleIds.WALKING, ModuleIds.HABITS).map { AlarmCodes.requestCode(it) }
        assertEquals(codes.size, codes.toSet().size)
        assertNotEquals(AlarmCodes.requestCode(ModuleIds.LEARNING), AlarmCodes.requestCode(ModuleIds.WALKING))
    }

    @Test
    fun requestCodeIsStable() {
        assertEquals(AlarmCodes.requestCode("learning"), AlarmCodes.requestCode("learning"))
    }
}
