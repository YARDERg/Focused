package com.example.focuslock.learning

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

internal val UTC: ZoneOffset = ZoneOffset.UTC

internal fun epoch(date: String, hour: Int, minute: Int, second: Int = 0): Long =
    LocalDateTime.of(LocalDate.parse(date), java.time.LocalTime.of(hour, minute, second)).toInstant(UTC).toEpochMilli()

internal class FakeStore : StudyStore {
    val days = HashMap<String, DayRecord>()
    val lectures = HashMap<String, LinkedHashMap<String, LectureState>>()
    var saveDayCalls = 0

    override suspend fun loadDay(date: String): DayRecord? = days[date]
    override suspend fun loadLectures(date: String): List<LectureState> = lectures[date]?.values?.toList().orEmpty()
    override suspend fun saveDay(date: String, record: DayRecord) {
        saveDayCalls++
        days[date] = record
    }
    override suspend fun saveLectures(date: String, lectures: List<LectureState>) {
        val map = this.lectures.getOrPut(date) { LinkedHashMap() }
        lectures.forEach { map[it.key] = it }
    }
}

internal class FakeSink : StudyLogSink {
    data class Row(val date: String, val startedAt: Long, val endedAt: Long, val seconds: Long, val newlyWatched: Int)
    val rows = ArrayList<Row>()
    override suspend fun writeStudyRow(date: String, startedAt: Long, endedAt: Long, durationSeconds: Long, newlyWatched: Int) {
        rows.add(Row(date, startedAt, endedAt, durationSeconds, newlyWatched))
    }
}

internal class Clock(var now: Long)

internal fun ledgerOf(
    store: FakeStore,
    sink: FakeSink,
    clock: Clock,
    requiredMinutes: Int = 30,
    sharePercent: Int = 70,
    onMet: suspend (String) -> Unit = {},
): StudyLedger = StudyLedger(
    store = store,
    sink = sink,
    requiredMinutes = { requiredMinutes },
    minSharePercent = { sharePercent },
    clock = { clock.now },
    zone = { UTC },
    onRequirementMet = onMet,
)
