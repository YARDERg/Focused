package com.example.focuslock.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class TimeFormatTest {
    @Test
    fun twelveHourFormatting() {
        assertEquals("7:00 AM", TimeFormat.format12h(7 * 60))
        assertEquals("9:00 PM", TimeFormat.format12h(21 * 60))
        assertEquals("12:00 AM", TimeFormat.format12h(0))
        assertEquals("12:05 PM", TimeFormat.format12h(12 * 60 + 5))
        assertEquals("11:59 PM", TimeFormat.format12h(23 * 60 + 59))
    }
}
