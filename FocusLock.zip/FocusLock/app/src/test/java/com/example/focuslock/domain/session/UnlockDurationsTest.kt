package com.example.focuslock.domain.session

import org.junit.Assert.assertEquals
import org.junit.Test

class UnlockDurationsTest {
    @Test
    fun elapsedTimeIsSplitAmongNormalTasks() {
        assertEquals(listOf(50L, 50L), UnlockDurations.perTaskSeconds(100, listOf(false, false)))
    }

    @Test
    fun tasksReportingTheirOwnActivityGetZero() {
        assertEquals(listOf(0L, 100L), UnlockDurations.perTaskSeconds(100, listOf(true, false)))
        assertEquals(listOf(0L, 0L), UnlockDurations.perTaskSeconds(100, listOf(true, true)))
        assertEquals(listOf(0L), UnlockDurations.perTaskSeconds(3_600, listOf(true)))
    }

    @Test
    fun negativeElapsedNeverProducesNegativeDurations() {
        assertEquals(listOf(0L, 0L), UnlockDurations.perTaskSeconds(-5, listOf(false, false)))
    }
}
