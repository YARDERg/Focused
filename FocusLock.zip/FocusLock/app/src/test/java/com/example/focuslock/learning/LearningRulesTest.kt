package com.example.focuslock.learning

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneOffset

class LearningRulesTest {

    @Test
    fun requiredMinutesBelowDefaultNeedDebug() {
        assertEquals(30, LearningRules.effectiveRequiredMinutes(1, debug = false))
        assertEquals(30, LearningRules.effectiveRequiredMinutes(29, debug = false))
        assertEquals(30, LearningRules.effectiveRequiredMinutes(30, debug = false))
        assertEquals(45, LearningRules.effectiveRequiredMinutes(45, debug = false))
        assertEquals(1, LearningRules.effectiveRequiredMinutes(1, debug = true))
        assertEquals(5, LearningRules.effectiveRequiredMinutes(5, debug = true))
        assertEquals(1, LearningRules.effectiveRequiredMinutes(0, debug = true))
    }

    @Test
    fun shareIsClampedToFiftyToHundred() {
        assertEquals(50, LearningRules.clampShare(10))
        assertEquals(70, LearningRules.clampShare(70))
        assertEquals(100, LearningRules.clampShare(250))
    }

    @Test
    fun scheduledCompleteIsGatedByTheRequirement() {
        val required = 30
        val thirty = 30 * 60_000L
        assertFalse(LearningRules.canCompleteScheduled(thirty - 1, required, alreadyCompleted = false))
        assertTrue(LearningRules.canCompleteScheduled(thirty, required, alreadyCompleted = false))
        assertTrue(LearningRules.canCompleteScheduled(thirty * 3, required, alreadyCompleted = false))
        assertFalse(LearningRules.canCompleteScheduled(thirty, required, alreadyCompleted = true))
        assertTrue(LearningRules.isRequirementMet(60_000, 1))
        assertFalse(LearningRules.isRequirementMet(59_999, 1))
    }

    @Test
    fun optionalCompleteNeedsTheStudyViewOpenedOnce() {
        assertEquals(0L, OPTIONAL_MIN_CREDIT_SECONDS)
        assertFalse(LearningRules.canCompleteOptional(openedOnce = false, sessionCreditedSeconds = 9_999, alreadyCompleted = false))
        assertTrue(LearningRules.canCompleteOptional(openedOnce = true, sessionCreditedSeconds = 0, alreadyCompleted = false))
        assertFalse(LearningRules.canCompleteOptional(openedOnce = true, sessionCreditedSeconds = 0, alreadyCompleted = true))
    }

    @Test
    fun optionalMinimumCreditCanBeRaisedLater() {
        assertFalse(LearningRules.canCompleteOptional(true, 59, false, minCreditSeconds = 60))
        assertTrue(LearningRules.canCompleteOptional(true, 60, false, minCreditSeconds = 60))
    }

    @Test
    fun optionalStateRoundTripsAndRejectsGarbage() {
        val s = OptionalState(opened = true, baselineDate = "2026-10-02", baselineMs = 123_456L)
        assertEquals(s, OptionalState.decode(s.encode()))
        assertEquals(OptionalState(false, "", 0L), OptionalState.decode(OptionalState.NONE.encode()))
        assertNull(OptionalState.decode(null))
        assertNull(OptionalState.decode(""))
        assertNull(OptionalState.decode("1|2026-10-02"))
        assertNull(OptionalState.decode("x|2026-10-02|5"))
        assertNull(OptionalState.decode("1|2026-10-02|abc"))
    }

    @Test
    fun optionalSessionCreditIsMeasuredFromTheBaseline() {
        val s = OptionalState(true, "2026-10-02", 600_000L)
        assertEquals(0L, s.sessionCreditedMs("2026-10-02", 600_000L))
        assertEquals(90_000L, s.sessionCreditedMs("2026-10-02", 690_000L))
        assertEquals(0L, s.sessionCreditedMs("2026-10-02", 100L))                // never negative
        assertEquals(45_000L, s.sessionCreditedMs("2026-10-03", 45_000L))        // new day: all of today's credit
    }

    @Test
    fun dayKeyChangesAtLocalMidnightNotAtUtcMidnight() {
        val cairoSummer = ZoneOffset.ofHours(3)
        val before = epoch("2026-07-01", 20, 59, 59)         // 23:59:59 at +03:00
        val after = epoch("2026-07-01", 21, 0, 0)            // 00:00:00 next day at +03:00
        assertEquals("2026-07-01", DayKey.of(before, cairoSummer))
        assertEquals("2026-07-02", DayKey.of(after, cairoSummer))
        assertNotEquals(DayKey.of(before, cairoSummer), DayKey.of(after, cairoSummer))
        assertEquals(DayKey.of(before, ZoneOffset.UTC), DayKey.of(after, ZoneOffset.UTC))
    }
}
