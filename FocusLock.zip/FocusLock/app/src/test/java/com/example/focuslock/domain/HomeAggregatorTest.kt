package com.example.focuslock.domain

import com.example.focuslock.domain.LogSource
import com.example.focuslock.domain.stats.HomeAggregator
import com.example.focuslock.domain.stats.LogEntry
import com.example.focuslock.domain.stats.Metric
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class HomeAggregatorTest {
    private val today = LocalDate.of(2026, 10, 2)
    private val october = YearMonth.of(2026, 10)

    private fun log(module: String, date: LocalDate, started: Long, secs: Long, steps: Int? = null) =
        LogEntry(module, date, started, secs, steps)

    @Test
    fun emptyStateWhenNoLogs() {
        val s = HomeAggregator.aggregate(emptyList(), listOf("learning", "walking"), today, october, Metric.HOURS)
        assertTrue(s.isEmpty)
        assertEquals(2, s.cards.size)
    }

    @Test
    fun todayAndMonthTotalsAreSeparate() {
        val logs = listOf(
            log("learning", today, 1, 3600),
            log("learning", LocalDate.of(2026, 10, 1), 2, 1800),
            log("learning", LocalDate.of(2026, 9, 30), 3, 7200),   // other month
        )
        val s = HomeAggregator.aggregate(logs, listOf("learning"), today, october, Metric.HOURS)
        val c = s.cards.single()
        assertEquals(3600L, c.today.seconds)
        assertEquals(5400L, c.month.seconds)
        assertEquals(2, c.month.sessions)
        assertFalse(s.isEmpty)
    }

    @Test
    fun sessionsCountDistinctStartTimesNotTasks() {
        val logs = listOf(
            log("learning", today, 10, 100),
            log("learning", today, 10, 100),   // second task of the same session
            log("learning", today, 20, 100),
        )
        val c = HomeAggregator.aggregate(logs, listOf("learning"), today, october, Metric.SESSIONS).cards.single()
        assertEquals(2, c.today.sessions)
    }

    @Test
    fun sortedDescendingBySelectedMetric() {
        val logs = listOf(
            log("learning", today, 1, 3600, steps = null),
            log("walking", today, 2, 600, steps = 9000),
            log("walking", today, 3, 600, steps = 1000),
        )
        val ids = listOf("learning", "walking")
        assertEquals(listOf("learning", "walking"),
            HomeAggregator.aggregate(logs, ids, today, october, Metric.HOURS).cards.map { it.moduleId })
        assertEquals(listOf("walking", "learning"),
            HomeAggregator.aggregate(logs, ids, today, october, Metric.STEPS).cards.map { it.moduleId })
        assertEquals(listOf("walking", "learning"),
            HomeAggregator.aggregate(logs, ids, today, october, Metric.SESSIONS).cards.map { it.moduleId })
    }

    @Test
    fun stepsSumTreatsNullAsZero() {
        val logs = listOf(log("walking", today, 1, 60, null), log("walking", today, 2, 60, 500))
        val c = HomeAggregator.aggregate(logs, listOf("walking"), today, october, Metric.STEPS).cards.single()
        assertEquals(500L, c.month.steps)
    }

    @Test
    fun pastMonthStillShowsTodayTotals() {
        val logs = listOf(log("learning", today, 1, 600), log("learning", LocalDate.of(2026, 9, 5), 2, 1200))
        val c = HomeAggregator.aggregate(logs, listOf("learning"), today, YearMonth.of(2026, 9), Metric.HOURS).cards.single()
        assertEquals(600L, c.today.seconds)
        assertEquals(1200L, c.month.seconds)
    }

    @Test
    fun tiesKeepRegistryOrder() {
        val s = HomeAggregator.aggregate(emptyList(), listOf("b", "a", "c"), today, october, Metric.HOURS)
        assertEquals(listOf("b", "a", "c"), s.cards.map { it.moduleId })
    }

    @Test
    fun stepsMetricListsOnlyModulesThatRecordSteps() {
        val logs = listOf(log("learning", today, 1, 3600), log("walking", today, 2, 600, steps = 4000))
        val ids = listOf("learning", "walking")
        val steps = HomeAggregator.aggregate(logs, ids, today, october, Metric.STEPS, stepModuleIds = setOf("walking"))
        assertEquals(listOf("walking"), steps.cards.map { it.moduleId })
        val hours = HomeAggregator.aggregate(logs, ids, today, october, Metric.HOURS, stepModuleIds = setOf("walking"))
        assertEquals(listOf("learning", "walking"), hours.cards.map { it.moduleId })
        val sessions = HomeAggregator.aggregate(logs, ids, today, october, Metric.SESSIONS, stepModuleIds = setOf("walking"))
        assertEquals(2, sessions.cards.size)
    }

    @Test
    fun stepsListStaysSortedDescending() {
        val logs = listOf(log("walking", today, 1, 60, steps = 100), log("hike", today, 2, 60, steps = 900))
        val s = HomeAggregator.aggregate(
            logs, listOf("walking", "hike"), today, october, Metric.STEPS, stepModuleIds = setOf("walking", "hike"),
        )
        assertEquals(listOf("hike", "walking"), s.cards.map { it.moduleId })
    }

    @Test
    fun testSessionsAreExcludedUnlessDebugIsOn() {
        val logs = listOf(
            LogEntry("learning", today, 1, 3600, null, LogSource.TEST),
            LogEntry("learning", today, 2, 600, null, LogSource.SCHEDULED),
        )
        val off = HomeAggregator.aggregate(logs, listOf("learning"), today, october, Metric.HOURS).cards.single()
        assertEquals(600L, off.today.seconds)
        assertEquals(1, off.today.sessions)
        val on = HomeAggregator.aggregate(
            logs, listOf("learning"), today, october, Metric.HOURS, includeTestSessions = true,
        ).cards.single()
        assertEquals(4200L, on.today.seconds)
        assertEquals(2, on.today.sessions)
    }

    @Test
    fun onlyTestLogsWithDebugOffShowsTheEmptyState() {
        val logs = listOf(LogEntry("learning", today, 1, 3600, null, LogSource.TEST))
        assertTrue(HomeAggregator.aggregate(logs, listOf("learning"), today, october, Metric.HOURS).isEmpty)
    }
}
