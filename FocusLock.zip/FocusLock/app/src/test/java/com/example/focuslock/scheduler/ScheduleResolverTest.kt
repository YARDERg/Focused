package com.example.focuslock.scheduler

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

class ScheduleResolverTest {
    private val utc: ZoneId = ZoneOffset.UTC
    private val default7am = 7 * 60

    private fun at(h: Int, m: Int, s: Int = 0, day: Int = 2, zone: ZoneId = utc) =
        ZonedDateTime.of(2026, 10, day, h, m, s, 0, zone)

    @Test
    fun defaultTimeWhenNoOverride() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, null)
        assertEquals(at(7, 0), r.trigger)
        assertTrue(r.isToday)
        assertFalse(r.isOverride)
    }

    @Test
    fun futureOverrideWinsOverDefault() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, 8 * 60 + 30)
        assertEquals(at(8, 30), r.trigger)
        assertTrue(r.isOverride)
    }

    @Test
    fun pastOverrideFallsBackToFutureDefault() {
        val r = ScheduleResolver.resolve(at(8, 0), 9 * 60, 7 * 60 + 30)
        assertEquals(at(9, 0), r.trigger)
        assertFalse(r.isOverride)
    }

    @Test
    fun pastDefaultRollsToTomorrow() {
        val r = ScheduleResolver.resolve(at(8, 0), default7am, null)
        assertEquals(at(7, 0, day = 3), r.trigger)
        assertFalse(r.isToday)
    }

    @Test
    fun exactlyNowIsNotInTheFuture() {
        val r = ScheduleResolver.resolve(at(7, 0), default7am, null)
        assertEquals(at(7, 0, day = 3), r.trigger)
    }

    @Test
    fun firedTodaySkipsTodayEvenWithFutureOverrideOrDefault() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, 22 * 60, firedToday = true)
        assertEquals(at(7, 0, day = 3), r.trigger)
        assertFalse(r.isOverride)
    }

    @Test
    fun overrideThatAlreadyFiredReturnsToDefaultTomorrow() {
        // default 9 PM, override 7 PM fired at 7 PM; at 7:00:01 PM the next one is tomorrow 9 PM.
        val r = ScheduleResolver.resolve(at(19, 0, 1), 21 * 60, null, firedToday = true)
        assertEquals(at(21, 0, day = 3), r.trigger)
    }

    @Test
    fun midnightRolloverJustBeforeMidnight() {
        val r = ScheduleResolver.resolve(at(23, 59, 30), 0, null)
        assertEquals(LocalDate.of(2026, 10, 3), r.trigger.toLocalDate())
        assertEquals(0, r.trigger.hour)
        assertEquals(0, r.trigger.minute)
    }

    @Test
    fun lateDefaultAfterItHasPassedGoesToNextDay() {
        val r = ScheduleResolver.resolve(at(23, 59), 23 * 60 + 30, null)
        assertEquals(at(23, 30, day = 3), r.trigger)
    }

    @Test
    fun justAfterMidnightTodayIsTheNewDay() {
        val r = ScheduleResolver.resolve(at(0, 0, 5, day = 3), default7am, null)
        assertEquals(at(7, 0, day = 3), r.trigger)
        assertTrue(r.isToday)
    }

    @Test
    fun dstGapMovesForward() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 3, 8, 1, 0, 0, 0, ny)
        val t = ScheduleResolver.nextTrigger(now, 2 * 60 + 30, null)   // 2:30 does not exist on 8 Mar 2026
        assertEquals(LocalDate.of(2026, 3, 8), t.toLocalDate())
        assertEquals(3, t.hour)
        assertEquals(30, t.minute)
    }

    @Test
    fun dstOverlapPicksEarlierOffset() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 11, 1, 0, 0, 0, 0, ny)
        val t = ScheduleResolver.nextTrigger(now, 60 + 30, null)       // 1:30 happens twice on 1 Nov 2026
        assertEquals(ZoneOffset.ofHours(-4), t.offset)
        assertEquals(1, t.hour)
        assertEquals(30, t.minute)
    }

    @Test
    fun overrideAllowedOnlyBeforeTodaysSession() {
        assertTrue(ScheduleResolver.canOverrideToday(at(6, 0), default7am, null, false))
        assertFalse(ScheduleResolver.canOverrideToday(at(8, 0), default7am, null, false))
        assertFalse(ScheduleResolver.canOverrideToday(at(6, 0), default7am, 8 * 60, true))
    }

    @Test
    fun futureTodayCheck() {
        assertTrue(ScheduleResolver.isFutureToday(at(6, 0), 6 * 60 + 1))
        assertFalse(ScheduleResolver.isFutureToday(at(6, 0), 6 * 60))
        assertFalse(ScheduleResolver.isFutureToday(at(6, 0), 5 * 60))
    }
}
