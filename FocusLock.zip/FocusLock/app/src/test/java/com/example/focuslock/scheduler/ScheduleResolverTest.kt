package com.example.focuslock.scheduler

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

class ScheduleResolverTest {
    private val utc: ZoneId = ZoneOffset.UTC
    private val default7am = 7 * 60

    private fun at(h: Int, m: Int, s: Int = 0, day: Int = 2, zone: ZoneId = utc) =
        ZonedDateTime.of(2026, 10, day, h, m, s, 0, zone)

    // ---- default vs override (today) ----

    @Test
    fun defaultTimeWhenNoOverride() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, todayOverrideMinutes = null)
        assertEquals(at(7, 0), r.trigger)
        assertTrue(r.isToday)
        assertFalse(r.isOverride)
    }

    @Test
    fun futureTodayOverrideWinsOverDefault() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, todayOverrideMinutes = 8 * 60 + 30)
        assertEquals(at(8, 30), r.trigger)
        assertTrue(r.isOverride)
    }

    @Test
    fun pastTodayOverrideFallsBackToFutureDefault() {
        val r = ScheduleResolver.resolve(at(8, 0), 9 * 60, todayOverrideMinutes = 7 * 60 + 30)
        assertEquals(at(9, 0), r.trigger)
        assertFalse(r.isOverride)
    }

    @Test
    fun pastDefaultRollsToTomorrow() {
        val r = ScheduleResolver.resolve(at(8, 0), default7am, todayOverrideMinutes = null)
        assertEquals(at(7, 0, day = 3), r.trigger)
        assertFalse(r.isToday)
    }

    @Test
    fun exactlyNowIsNotInTheFuture() {
        val r = ScheduleResolver.resolve(at(7, 0), default7am, todayOverrideMinutes = null)
        assertEquals(at(7, 0, day = 3), r.trigger)
    }

    // ---- tomorrow's override ----

    @Test
    fun tomorrowOverrideIsUsedWhenTodayHasFired() {
        val r = ScheduleResolver.resolve(
            at(7, 30), default7am, todayOverrideMinutes = null, tomorrowOverrideMinutes = 10 * 60, firedToday = true,
        )
        assertEquals(at(10, 0, day = 3), r.trigger)
        assertFalse(r.isToday)
        assertTrue(r.isOverride)
    }

    @Test
    fun tomorrowOverrideIsUsedWhenTodaysDefaultHasPassed() {
        val r = ScheduleResolver.resolve(
            at(8, 0), default7am, todayOverrideMinutes = null, tomorrowOverrideMinutes = 11 * 60,
        )
        assertEquals(at(11, 0, day = 3), r.trigger)
        assertTrue(r.isOverride)
    }

    @Test
    fun tomorrowOverrideDoesNotAffectAFutureSessionToday() {
        val r = ScheduleResolver.resolve(
            at(6, 0), default7am, todayOverrideMinutes = null, tomorrowOverrideMinutes = 11 * 60,
        )
        assertEquals(at(7, 0), r.trigger)
        assertTrue(r.isToday)
        assertFalse(r.isOverride)
    }

    @Test
    fun noTomorrowOverrideMeansTomorrowsDefault() {
        val r = ScheduleResolver.resolve(
            at(7, 30), default7am, todayOverrideMinutes = null, tomorrowOverrideMinutes = null, firedToday = true,
        )
        assertEquals(at(7, 0, day = 3), r.trigger)
        assertFalse(r.isOverride)
    }

    @Test
    fun firedTodaySkipsTodayEvenWithFutureTodayOverride() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, todayOverrideMinutes = 22 * 60, firedToday = true)
        assertEquals(at(7, 0, day = 3), r.trigger)
        assertFalse(r.isOverride)
    }

    @Test
    fun overrideThatAlreadyFiredReturnsToDefaultTheNextDay() {
        // Walking: default 9 PM, changed to 7 PM; fired at 7 PM, so its row was deleted.
        val r = ScheduleResolver.resolve(at(19, 0, 1), 21 * 60, todayOverrideMinutes = null, firedToday = true)
        assertEquals(at(21, 0, day = 3), r.trigger)
        assertFalse(r.isOverride)
    }

    // ---- midnight rollover ----

    @Test
    fun midnightRolloverJustBeforeMidnight() {
        val r = ScheduleResolver.resolve(at(23, 59, 30), 0, todayOverrideMinutes = null)
        assertEquals(LocalDate.of(2026, 10, 3), r.trigger.toLocalDate())
        assertEquals(0, r.trigger.hour)
        assertEquals(0, r.trigger.minute)
    }

    @Test
    fun lateDefaultAfterItHasPassedGoesToNextDay() {
        val r = ScheduleResolver.resolve(at(23, 59), 23 * 60 + 30, todayOverrideMinutes = null)
        assertEquals(at(23, 30, day = 3), r.trigger)
    }

    @Test
    fun justAfterMidnightTodayIsTheNewDay() {
        val r = ScheduleResolver.resolve(at(0, 0, 5, day = 3), default7am, todayOverrideMinutes = null)
        assertEquals(at(7, 0, day = 3), r.trigger)
        assertTrue(r.isToday)
    }

    @Test
    fun overrideSetAsTomorrowBecomesTodaysOverrideAfterMidnight() {
        // Set on 2 Oct for 3 Oct (10:00); at 00:00:05 on 3 Oct the resolver is given it as today's override.
        val before = ScheduleResolver.resolve(
            at(23, 59, 50), default7am, todayOverrideMinutes = null, tomorrowOverrideMinutes = 10 * 60, firedToday = true,
        )
        val after = ScheduleResolver.resolve(
            at(0, 0, 5, day = 3), default7am, todayOverrideMinutes = 10 * 60, tomorrowOverrideMinutes = null, firedToday = false,
        )
        assertEquals(at(10, 0, day = 3), before.trigger)
        assertEquals(before.trigger, after.trigger)
        assertTrue(after.isToday)
        assertTrue(after.isOverride)
    }

    @Test
    fun tomorrowOverrideOnTheLastDayOfTheMonthRollsIntoNextMonth() {
        val now = ZonedDateTime.of(2026, 10, 31, 20, 0, 0, 0, utc)
        val r = ScheduleResolver.resolve(now, default7am, null, tomorrowOverrideMinutes = 9 * 60, firedToday = true)
        assertEquals(LocalDate.of(2026, 11, 1), r.trigger.toLocalDate())
        assertEquals(9, r.trigger.hour)
    }

    // ---- DST ----

    @Test
    fun dstGapMovesForward() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 3, 8, 1, 0, 0, 0, ny)
        val t = ScheduleResolver.nextTrigger(now, 2 * 60 + 30, null)   // 2:30 does not exist on 8 Mar 2026
        assertEquals(LocalDate.of(2026, 3, 8), t.toLocalDate())
        assertEquals(3, t.hour)
        assertEquals(30, t.minute)
    }

    @Test
    fun dstOverlapPicksEarlierOffset() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 11, 1, 0, 0, 0, 0, ny)
        val t = ScheduleResolver.nextTrigger(now, 60 + 30, null)       // 1:30 happens twice on 1 Nov 2026
        assertEquals(ZoneOffset.ofHours(-4), t.offset)
        assertEquals(1, t.hour)
        assertEquals(30, t.minute)
    }

    @Test
    fun tomorrowOverrideInsideDstGapMovesForward() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 3, 7, 21, 0, 0, 0, ny)       // evening before the spring-forward night
        val t = ScheduleResolver.nextTrigger(
            now, 7 * 60, todayOverrideMinutes = null, tomorrowOverrideMinutes = 2 * 60 + 30, firedToday = true,
        )
        assertEquals(LocalDate.of(2026, 3, 8), t.toLocalDate())
        assertEquals(3, t.hour)
        assertEquals(30, t.minute)
    }

    @Test
    fun tomorrowOverrideAcrossFallBackKeepsLocalWallClock() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 10, 31, 20, 0, 0, 0, ny)     // fall back happens on 1 Nov
        val t = ScheduleResolver.nextTrigger(
            now, 7 * 60, todayOverrideMinutes = null, tomorrowOverrideMinutes = 10 * 60, firedToday = true,
        )
        assertEquals(LocalDate.of(2026, 11, 1), t.toLocalDate())
        assertEquals(10, t.hour)
        assertEquals(ZoneOffset.ofHours(-5), t.offset)                // after the change: standard time
    }
}
