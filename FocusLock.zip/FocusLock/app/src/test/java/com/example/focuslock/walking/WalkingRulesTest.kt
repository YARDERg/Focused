package com.example.focuslock.walking

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WalkingRulesTest {

    @Test
    fun requiredStepsMinimumDependsOnTheDebugToggle() {
        assertEquals(1000, WalkingRules.effectiveRequiredSteps(500, debug = false))
        assertEquals(1000, WalkingRules.effectiveRequiredSteps(20, debug = false))
        assertEquals(3000, WalkingRules.effectiveRequiredSteps(3000, debug = false))
        assertEquals(20, WalkingRules.effectiveRequiredSteps(20, debug = true))
        assertEquals(20, WalkingRules.effectiveRequiredSteps(5, debug = true))
        assertEquals(500, WalkingRules.effectiveRequiredSteps(500, debug = true))
    }

    @Test
    fun cadenceThresholdMinimumDependsOnTheDebugToggleAndStaysBelowTheShakeLimit() {
        assertEquals(60, WalkingRules.effectiveCadence(30, debug = false))
        assertEquals(90, WalkingRules.effectiveCadence(90, debug = false))
        assertEquals(30, WalkingRules.effectiveCadence(30, debug = true))
        assertEquals(10, WalkingRules.effectiveCadence(1, debug = true))
        assertEquals(200, WalkingRules.effectiveCadence(900, debug = false))
        assertTrue(WalkingDefaults.MAX_CADENCE_SETTING < WalkingDefaults.MAX_CADENCE)
    }

    @Test
    fun completeIsEnabledOnlyWhenSessionStepsReachTheRequirement() {
        assertFalse(WalkingRules.canComplete(0, 3000, alreadyCompleted = false))
        assertFalse(WalkingRules.canComplete(2999, 3000, alreadyCompleted = false))
        assertTrue(WalkingRules.canComplete(3000, 3000, alreadyCompleted = false))
        assertTrue(WalkingRules.canComplete(4200, 3000, alreadyCompleted = false))
        assertFalse(WalkingRules.canComplete(4200, 3000, alreadyCompleted = true))
    }

    @Test
    fun daySteps_neverMeetTheSessionRequirement() {
        // The requirement function only receives SESSION steps: 9000 daily steps are irrelevant.
        val sessionSteps = 40
        val dailySteps = 9000
        assertFalse(WalkingRules.canComplete(sessionSteps, 3000, false))
        assertTrue(dailySteps + sessionSteps > 3000)
    }

    @Test
    fun notificationFiresOncePerDatePersistedAcrossRestarts() = runBlocking {
        val store = FakeStepsStore()
        var sent = 0
        val trigger = RequirementTrigger(store) { sent++ }
        assertFalse(trigger.check("2026-10-02", 2999, 3000, scheduledTaskActive = true))
        assertEquals(0, sent)
        assertTrue(trigger.check("2026-10-02", 3000, 3000, scheduledTaskActive = true))
        assertFalse(trigger.check("2026-10-02", 3500, 3000, scheduledTaskActive = true))   // keep walking: no second one
        assertEquals(1, sent)
        assertTrue(store.days["2026-10-02"]!!.requirementNotified)

        val afterRestart = RequirementTrigger(store) { sent++ }                            // new process, same Room data
        assertFalse(afterRestart.check("2026-10-02", 3600, 3000, scheduledTaskActive = true))
        assertEquals(1, sent)

        assertTrue(afterRestart.check("2026-10-03", 3000, 3000, scheduledTaskActive = true))   // next day: one more
        assertEquals(2, sent)
    }

    @Test
    fun notificationNeedsTheScheduledTask() = runBlocking {
        val store = FakeStepsStore()
        var sent = 0
        val trigger = RequirementTrigger(store) { sent++ }
        assertFalse(trigger.check("2026-10-02", 5000, 3000, scheduledTaskActive = false))
        assertEquals(0, sent)
        assertTrue(store.days.isEmpty())
    }

    @Test
    fun aFailingNotificationIsSwallowedButStillOnlyOncePerDay() = runBlocking {
        val store = FakeStepsStore()
        var calls = 0
        val trigger = RequirementTrigger(store) { calls++; throw IllegalStateException("boom") }
        assertTrue(trigger.check("2026-10-02", 3000, 3000, true))
        assertFalse(trigger.check("2026-10-02", 3100, 3000, true))
        assertEquals(1, calls)
    }
}
