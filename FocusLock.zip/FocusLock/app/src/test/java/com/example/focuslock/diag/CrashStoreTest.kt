package com.example.focuslock.diag

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class CrashStoreTest {
    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun keepsOnlyTheLastFiveNewestFirst() {
        val store = CrashStore(tmp.newFolder("crashes"), max = 5)
        for (i in 1..7) store.record(IllegalStateException("boom $i"), "main", 1_000L * i)
        val all = store.readAll()
        assertEquals(5, all.size)
        assertTrue(all.first().contains("boom 7"))
        assertTrue(all.last().contains("boom 3"))
    }

    @Test
    fun sameMillisecondDoesNotOverwrite() {
        val store = CrashStore(tmp.newFolder("same"), max = 5)
        store.record(RuntimeException("a"), "t1", 5_000L)
        store.record(RuntimeException("b"), "t2", 5_000L)
        assertEquals(2, store.readAll().size)
    }

    @Test
    fun recordsStackTraceAndThread() {
        val store = CrashStore(tmp.newFolder("trace"), max = 5)
        store.record(IllegalArgumentException("bad"), "worker-1", 1L)
        val text = store.readAll().single()
        assertTrue(text.contains("IllegalArgumentException"))
        assertTrue(text.contains("worker-1"))
        assertTrue(text.contains("CrashStoreTest"))
    }

    @Test
    fun emptyWhenNothingRecorded() {
        assertEquals(emptyList<String>(), CrashStore(tmp.newFolder("none")).readAll())
    }
}
