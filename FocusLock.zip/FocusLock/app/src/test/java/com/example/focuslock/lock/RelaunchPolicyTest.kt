package com.example.focuslock.lock

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RelaunchPolicyTest {
    private val now = 1_000_000L

    private fun immediate(
        sessionActive: Boolean = true,
        emergencyUntil: Long = 0L,
        overlay: Boolean = true,
        unlocking: Boolean = false,
        configChange: Boolean = false,
        interactive: Boolean = true,
        call: Boolean = false,
    ) = RelaunchPolicy.immediate(sessionActive, now, emergencyUntil, overlay, unlocking, configChange, interactive, call)

    @Test
    fun relaunchesWhenEveryConditionHolds() = assertTrue(immediate())

    @Test
    fun noSessionNoRelaunch() = assertFalse(immediate(sessionActive = false))

    @Test
    fun emergencyWindowBlocksUntilItEnds() {
        assertFalse(immediate(emergencyUntil = now + 1))
        assertTrue(immediate(emergencyUntil = now))          // now >= emergencyUntil
    }

    @Test
    fun missingOverlayPermissionBlocks() = assertFalse(immediate(overlay = false))

    @Test
    fun unlockBlocks() = assertFalse(immediate(unlocking = true))

    @Test
    fun configurationChangeBlocks() = assertFalse(immediate(configChange = true))

    @Test
    fun screenOffBlocksSoItNeverWakesThePhone() = assertFalse(immediate(interactive = false))

    @Test
    fun callInProgressBlocks() = assertFalse(immediate(call = true))

    private fun watchdog(
        sessionActive: Boolean = true,
        emergencyUntil: Long = 0L,
        overlay: Boolean = true,
        visible: Boolean = false,
        call: Boolean = false,
    ) = RelaunchPolicy.watchdog(sessionActive, now, emergencyUntil, overlay, visible, call)

    @Test
    fun watchdogRelaunchesRegardlessOfTaskCompletion() {
        // The rule has no "tasks incomplete" input: a fully completed session is still locked until Unlock.
        assertTrue(watchdog())
    }

    @Test
    fun watchdogStaysQuietWhenVisibleOrInCallOrEmergency() {
        assertFalse(watchdog(visible = true))
        assertFalse(watchdog(call = true))
        assertFalse(watchdog(emergencyUntil = now + 1))
        assertFalse(watchdog(overlay = false))
        assertFalse(watchdog(sessionActive = false))
    }
}
