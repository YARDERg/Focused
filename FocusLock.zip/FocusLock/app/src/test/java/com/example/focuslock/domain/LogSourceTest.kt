package com.example.focuslock.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogSourceTest {
    @Test
    fun kindsMapToTheirLogSources() {
        assertEquals("scheduled_session", LogSource.forKind(SessionKind.SCHEDULED))
        assertEquals("optional_session", LogSource.forKind(SessionKind.OPTIONAL))
    }

    @Test
    fun mergePrefersScheduledThenOptionalThenTest() {
        assertEquals(LogSource.SCHEDULED, LogSource.merge(null, LogSource.SCHEDULED))
        assertEquals(LogSource.SCHEDULED, LogSource.merge(LogSource.TEST, LogSource.SCHEDULED))
        assertEquals(LogSource.SCHEDULED, LogSource.merge(LogSource.SCHEDULED, LogSource.TEST))
        assertEquals(LogSource.SCHEDULED, LogSource.merge(LogSource.OPTIONAL, LogSource.SCHEDULED))
        assertEquals(LogSource.SCHEDULED, LogSource.merge(LogSource.SCHEDULED, LogSource.OPTIONAL))
        assertEquals(LogSource.OPTIONAL, LogSource.merge(LogSource.TEST, LogSource.OPTIONAL))
        assertEquals(LogSource.OPTIONAL, LogSource.merge(LogSource.OPTIONAL, LogSource.TEST))
        assertEquals(LogSource.TEST, LogSource.merge(LogSource.TEST, LogSource.TEST))
    }

    @Test
    fun studyRowsAreNotSessionRows() {
        assertTrue(LogSource.isSessionRow(LogSource.SCHEDULED))
        assertTrue(LogSource.isSessionRow(LogSource.OPTIONAL))
        assertTrue(LogSource.isSessionRow(LogSource.TEST))
        assertFalse(LogSource.isSessionRow(LogSource.STUDY))
    }

    @Test
    fun unknownKindNamesDecodeAsScheduled() {
        assertEquals(SessionKind.OPTIONAL, SessionKind.parse("OPTIONAL"))
        assertEquals(SessionKind.SCHEDULED, SessionKind.parse("SCHEDULED"))
        assertEquals(SessionKind.SCHEDULED, SessionKind.parse(null))
        assertEquals(SessionKind.SCHEDULED, SessionKind.parse("nonsense"))
    }
}
