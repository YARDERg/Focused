package com.example.focuslock.learning

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OptionalHeaderAndNotifyTest {
    private val day = DaySnapshot("2026-10-02", creditedMs = 12 * 60_000L, lecturesWatched = 2, requirementNotified = false)

    @Test
    fun optionalHeaderHasNoTarget() {
        val t = headerText(day, requiredMinutes = null, sessionMs = 5 * 60_000L)
        assertFalse(t.contains("/"))
        assertFalse(t.contains("30"))
        assertEquals("This session: 5 min. Today: 12 min, lectures 2", t)
    }

    @Test
    fun scheduledHeaderShowsTheTarget() {
        assertEquals("Today: 12 / 30 min, lectures 2", headerText(day, 30, null))
    }

    @Test
    fun noRequirementNotificationWhileOnlyAnOptionalSessionIsActive() = runBlocking {
        var scheduledActive = false
        var fired = 0
        val clock = Clock(epoch("2026-10-02", 12, 0))
        val ledger = StudyLedger(
            store = FakeStore(), sink = FakeSink(),
            requiredMinutes = { 1 }, minSharePercent = { 70 },
            clock = { clock.now }, zone = { UTC },
            onRequirementMet = { fired++ },
            notifyEnabled = { scheduledActive },
        )
        ledger.record("l1", 120_000, 1.0, 600.0)          // past the 1 min "requirement", optional only
        assertEquals(0, fired)
        assertFalse(ledger.snapshot.value.requirementNotified)
        scheduledActive = true                            // the scheduled session starts later that day
        ledger.record("l1", 250, 2.0, 600.0)
        assertEquals(1, fired)
    }

    @Test
    fun parserKeepsTheDiagnostics() {
        val s = VideoSampleParser.parse("\"1|1|0|0|0|1|0|0|0|0|1\"")!!
        assertEquals("readyState=0 network=0 error=0 hasSrc=0 videos=1", s.diag)
        assertEquals("videos=0", VideoSampleParser.parse("\"0|videos=0\"")!!.diag)
    }
}
