package com.example.focuslock.domain

import com.example.focuslock.domain.session.PersistedTask
import com.example.focuslock.domain.session.SessionCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SessionCodecTest {
    @Test
    fun roundTrip() {
        val starts = linkedMapOf("learning" to 1700000000000L, "walking" to 1700000100000L)
        val tasks = listOf(PersistedTask("learning", "learning.test_task"), PersistedTask("walking", "walking.test_task"))
        val done = setOf("learning.test_task")
        val s = SessionCodec.decode(
            SessionCodec.encodeModules(starts), SessionCodec.encodeTasks(tasks), SessionCodec.encodeCompleted(done),
        )!!
        assertEquals(starts, s.moduleStarts)
        assertEquals(tasks, s.tasks)
        assertEquals(done, s.completed)
    }

    @Test
    fun emptyOrMissingMeansNoSession() {
        assertNull(SessionCodec.decode(null, null, null))
        assertNull(SessionCodec.decode("", "", ""))
        assertNull(SessionCodec.decode("garbage", "x", ""))
    }

    @Test
    fun emptyCompletedSetDecodesToEmpty() {
        val s = SessionCodec.decode("learning@5", "learning|t1", "")!!
        assertEquals(emptySet<String>(), s.completed)
    }

    @Test
    fun sourcesRoundTrip() {
        val sources = linkedMapOf("learning" to "scheduled_session", "walking" to "test_session")
        val s = SessionCodec.decode(
            "learning@1,walking@2", "learning|a,walking|b", "", SessionCodec.encodeSources(sources),
        )!!
        assertEquals(sources, s.sources)
    }

    @Test
    fun missingSourcesDecodeToEmptyMap() {
        assertEquals(emptyMap<String, String>(), SessionCodec.decode("learning@5", "learning|t1", "")!!.sources)
    }

    @Test
    fun taskKindsRoundTripSoMergedSessionsRestoreBothKinds() {
        val tasks = listOf(
            PersistedTask("learning", "learning.optional", SessionKind.OPTIONAL),
            PersistedTask("learning", "learning.main", SessionKind.SCHEDULED),
        )
        val s = SessionCodec.decode("learning@5", SessionCodec.encodeTasks(tasks), "learning.optional")!!
        assertEquals(tasks, s.tasks)
        assertEquals(setOf("learning.optional"), s.completed)
    }

    @Test
    fun olderPersistedTasksWithoutAKindDecodeAsScheduled() {
        val s = SessionCodec.decode("learning@5", "learning|learning.test_task,walking|walking.test_task", "")!!
        assertEquals(
            listOf(
                PersistedTask("learning", "learning.test_task", SessionKind.SCHEDULED),
                PersistedTask("walking", "walking.test_task", SessionKind.SCHEDULED),
            ),
            s.tasks,
        )
    }

    @Test
    fun anUnknownKindDecodesAsScheduled() {
        val s = SessionCodec.decode("learning@5", "learning|learning.main|BOGUS", "")!!
        assertEquals(SessionKind.SCHEDULED, s.tasks.single().kind)
    }

    @Test
    fun optionalSourceSurvivesThePersistedSession() {
        val sources = linkedMapOf("learning" to "optional_session")
        val s = SessionCodec.decode("learning@1", "learning|learning.optional|OPTIONAL", "", SessionCodec.encodeSources(sources))!!
        assertEquals(sources, s.sources)
        assertEquals(SessionKind.OPTIONAL, s.tasks.single().kind)
    }
}
