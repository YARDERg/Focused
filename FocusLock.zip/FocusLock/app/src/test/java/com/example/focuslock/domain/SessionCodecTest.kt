package com.example.focuslock.domain

import com.example.focuslock.domain.session.PersistedTask
import com.example.focuslock.domain.session.SessionCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SessionCodecTest {
    @Test
    fun roundTrip() {
        val starts = linkedMapOf("learning" to 1700000000000L, "walking" to 1700000100000L)
        val tasks = listOf(PersistedTask("learning", "learning.test_task"), PersistedTask("walking", "walking.test_task"))
        val done = setOf("learning.test_task")
        val s = SessionCodec.decode(
            SessionCodec.encodeModules(starts), SessionCodec.encodeTasks(tasks), SessionCodec.encodeCompleted(done),
        )!!
        assertEquals(starts, s.moduleStarts)
        assertEquals(tasks, s.tasks)
        assertEquals(done, s.completed)
    }

    @Test
    fun emptyOrMissingMeansNoSession() {
        assertNull(SessionCodec.decode(null, null, null))
        assertNull(SessionCodec.decode("", "", ""))
        assertNull(SessionCodec.decode("garbage", "x", ""))
    }

    @Test
    fun emptyCompletedSetDecodesToEmpty() {
        val s = SessionCodec.decode("learning@5", "learning|t1", "")!!
        assertEquals(emptySet<String>(), s.completed)
    }
}
