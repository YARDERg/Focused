package com.example.focuslock.learning

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HostAllowlistTest {
    @Test
    fun allowsUdemyAndItsSubdomainsAndTheCdn() {
        assertTrue(HostAllowlist.isAllowedHost("udemy.com"))
        assertTrue(HostAllowlist.isAllowedHost("www.udemy.com"))
        assertTrue(HostAllowlist.isAllowedHost("WWW.UDEMY.COM"))
        assertTrue(HostAllowlist.isAllowedHost("a.b.udemy.com"))
        assertTrue(HostAllowlist.isAllowedHost("udemycdn.com"))
        assertTrue(HostAllowlist.isAllowedHost("www.udemy.com."))
    }

    @Test
    fun blocksLookAlikes() {
        assertFalse(HostAllowlist.isAllowedHost("evil-udemy.com"))
        assertFalse(HostAllowlist.isAllowedHost("udemy.com.evil.com"))
        assertFalse(HostAllowlist.isAllowedHost("notudemy.com"))
        assertFalse(HostAllowlist.isAllowedHost("google.com"))
        assertFalse(HostAllowlist.isAllowedHost("accounts.google.com"))
        assertFalse(HostAllowlist.isAllowedHost("udemycdn.com.evil.net"))
        assertFalse(HostAllowlist.isAllowedHost(""))
        assertFalse(HostAllowlist.isAllowedHost(null))
        // The spec lists exactly "udemycdn.com" (no wildcard), so its subdomains are not allowlisted.
        assertFalse(HostAllowlist.isAllowedHost("img-c.udemycdn.com"))
    }

    @Test
    fun urlChecks() {
        assertTrue(HostAllowlist.isAllowedUrl("https://www.udemy.com/course/x/learn/lecture/1"))
        assertTrue(HostAllowlist.isAllowedUrl("https://www.udemy.com:443/x"))
        assertTrue(HostAllowlist.isAllowedUrl("http://udemy.com"))
        assertFalse(HostAllowlist.isAllowedUrl("ftp://udemy.com"))
        assertFalse(HostAllowlist.isAllowedUrl("javascript:alert(1)"))
        assertFalse(HostAllowlist.isAllowedUrl("https://udemy.com@evil.com/"))
        assertFalse(HostAllowlist.isAllowedUrl("https://evil.com/?u=udemy.com"))
        assertFalse(HostAllowlist.isAllowedUrl("https://evil.com/#www.udemy.com"))
        assertFalse(HostAllowlist.isAllowedUrl(null))
        assertFalse(HostAllowlist.isAllowedUrl("about:blank"))
    }

    @Test
    fun hostOfStripsUserInfoAndPort() {
        assertEquals("www.udemy.com", HostAllowlist.hostOf("https://www.udemy.com:8443/x?y=1"))
        assertEquals("evil.com", HostAllowlist.hostOf("https://udemy.com@evil.com/"))
        assertNull(HostAllowlist.hostOf("mailto:a@b.c"))
    }

    @Test
    fun initialUrlPrefersLastThenStartThenDefault() {
        val last = "https://www.udemy.com/course/x/learn/lecture/9"
        assertEquals(last, HostAllowlist.initialUrl(last, "https://www.udemy.com/home"))
        assertEquals("https://www.udemy.com/home", HostAllowlist.initialUrl("https://evil.com/", "https://www.udemy.com/home"))
        assertEquals("https://www.udemy.com/home", HostAllowlist.initialUrl(null, "https://www.udemy.com/home"))
        assertEquals(LearningDefaults.START_URL, HostAllowlist.initialUrl(null, "https://evil.com"))
    }
}
