package com.example.focuslock.walking

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class StepsMathTest {

    @Test
    fun segmentsSplitAtLocalMidnight() {
        val segs = DayMath.segments(at("2026-10-01", 23, 30), at("2026-10-03", 0, 30), UTC_ZONE)
        assertEquals(3, segs.size)
        assertEquals(listOf("2026-10-01", "2026-10-02", "2026-10-03"), segs.map { it.date })
        assertEquals(at("2026-10-02", 0), segs[0].endMs)
        assertEquals(at("2026-10-02", 0), segs[1].startMs)
        assertEquals(at("2026-10-03", 0, 30), segs[2].endMs)
        assertTrue(DayMath.segments(10L, 10L, UTC_ZONE).isEmpty())
    }

    @Test
    fun aDayCanBe25HoursLong() {
        val berlin = ZoneId.of("Europe/Berlin")
        val d = LocalDate.of(2026, 10, 25)                         // DST ends
        assertEquals(25L * 3_600_000L, DayMath.dayEnd(d, berlin) - DayMath.dayStart(d, berlin))
    }

    @Test
    fun hourStartIsRightForHalfHourZones() {
        val kolkata = ZoneId.of("Asia/Kolkata")
        val t = ZonedDateTime.of(2026, 10, 2, 10, 20, 0, 0, kolkata)
        val expected = ZonedDateTime.of(2026, 10, 2, 10, 0, 0, 0, kolkata).toInstant().toEpochMilli()
        assertEquals(expected, HourMath.hourStart(t.toInstant().toEpochMilli(), kolkata))
        assertEquals(at("2026-10-02", 8), HourMath.hourStart(at("2026-10-02", 8, 59, 59), UTC_ZONE))
    }

    @Test
    fun rawByDayRoundTripsAndIgnoresGarbage() {
        val m = linkedMapOf("2026-10-01" to 400, "2026-10-02" to 300)
        assertEquals(m, RawByDay.decode(RawByDay.encode(m)))
        assertEquals(emptyMap<String, Int>(), RawByDay.decode(""))
        assertEquals(mapOf("2026-10-02" to 5), RawByDay.decode("junk,2026-10-02:5,x:y"))
    }

    @Test
    fun dailyIsNeverNegative() {
        assertEquals(1200, DailyMath.daily(2200, 1000))
        assertEquals(0, DailyMath.daily(900, 1000))           // boundary error of a data point or two
        assertEquals(100, DailyMath.mergeRaw(100, 0))
        assertEquals(0, DailyMath.mergeRaw(0, 0))
        assertEquals(150, DailyMath.mergeRaw(100, 150))
    }

    @Test
    fun hourlyRollupGroupsByLocalDate() {
        val hours = listOf(
            HourRow(at("2026-10-01", 22), 100),
            HourRow(at("2026-10-01", 23), 200),
            HourRow(at("2026-10-02", 0), 50),
        )
        assertEquals(mapOf("2026-10-01" to 300, "2026-10-02" to 50), HourlyRollup.stepsByDate(hours, UTC_ZONE))
        val chart = HourlyRollup.chartForDate(hours, "2026-10-01", UTC_ZONE)
        assertEquals(24, chart.size)
        assertEquals(100, chart[22])
        assertEquals(200, chart[23])
        assertEquals(0, chart[0])
    }
}
