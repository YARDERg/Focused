package com.example.focuslock.learning

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StudyLedgerTest {
    private val day1 = "2026-10-02"
    private val day2 = "2026-10-03"

    @Test
    fun creditAccumulatesAndPublishesTheSnapshot() = runBlocking {
        val clock = Clock(epoch(day1, 12, 0))
        val ledger = ledgerOf(FakeStore(), FakeSink(), clock)
        repeat(3) { ledger.record("l1", 250, 1.0, 600.0) }
        assertEquals(750L, ledger.snapshot.value.creditedMs)
        assertEquals(day1, ledger.snapshot.value.date)
    }

    @Test
    fun persistOnlyEveryFiveSecondsAndOnlyWhenDirty() = runBlocking {
        val store = FakeStore()
        val t0 = epoch(day1, 12, 0)
        val clock = Clock(t0)
        val ledger = ledgerOf(store, FakeSink(), clock)
        ledger.record("l1", 250, 1.0, 600.0)
        clock.now = t0 + 4_999
        ledger.persistIfDue()
        assertEquals(0, store.saveDayCalls)
        clock.now = t0 + 5_000
        ledger.persistIfDue()
        assertEquals(1, store.saveDayCalls)
        assertEquals(250L, store.days[day1]!!.creditedMs)
        assertEquals(250L, store.lectures[day1]!!["l1"]!!.creditedMs)
        clock.now = t0 + 20_000
        ledger.persistIfDue()
        assertEquals(1, store.saveDayCalls)          // nothing changed, nothing written
    }

    @Test
    fun flushWritesOneStudyRowPerEpisode() = runBlocking {
        val sink = FakeSink()
        val t0 = epoch(day1, 12, 0)
        val clock = Clock(t0)
        val ledger = ledgerOf(FakeStore(), sink, clock)
        ledger.record("l1", 1_500, 1.0, 600.0)
        clock.now = t0 + 1_500
        ledger.record("l1", 1_500, 2.0, 600.0)
        ledger.flush()
        assertEquals(1, sink.rows.size)
        assertEquals(3L, sink.rows[0].seconds)
        assertEquals(day1, sink.rows[0].date)
        assertEquals(t0, sink.rows[0].startedAt)
        ledger.flush()                                // same episode again: no second row
        assertEquals(1, sink.rows.size)
    }

    @Test
    fun flushWithNothingToReportWritesNothing() = runBlocking {
        val sink = FakeSink()
        val ledger = ledgerOf(FakeStore(), sink, Clock(epoch(day1, 12, 0)))
        ledger.flush()
        ledger.record("l1", 0, 5.0, 600.0)            // position only, no credit
        ledger.flush()
        assertTrue(sink.rows.isEmpty())
    }

    @Test
    fun subSecondRemaindersCarryOverSoNothingIsLost() = runBlocking {
        val sink = FakeSink()
        val clock = Clock(epoch(day1, 12, 0))
        val ledger = ledgerOf(FakeStore(), sink, clock)
        ledger.record("l1", 1_500, 1.0, 600.0)
        ledger.flush()                                // 1 s row, 500 ms carried
        ledger.flush()                                // nothing new: no row
        ledger.record("l1", 600, 2.0, 600.0)          // 500 + 600 = 1100 ms
        ledger.flush()
        assertEquals(listOf(1L, 1L), sink.rows.map { it.seconds })
        assertEquals(2_100L, ledger.snapshot.value.creditedMs)   // 2 s in rows + 100 ms still pending
    }

    @Test
    fun midnightRolloverStartsANewDayAndFlushesTheOldOne() = runBlocking {
        val store = FakeStore()
        val sink = FakeSink()
        val clock = Clock(epoch(day1, 23, 59, 58))
        val ledger = ledgerOf(store, sink, clock)
        ledger.record("l1", 3_000, 10.0, 600.0)
        assertEquals(3_000L, ledger.snapshot.value.creditedMs)

        clock.now = epoch(day2, 0, 0, 1)
        ledger.record("l1", 250, 11.0, 600.0)

        val snap = ledger.snapshot.value
        assertEquals(day2, snap.date)
        assertEquals(250L, snap.creditedMs)                       // progress reset by date key
        assertEquals(3_000L, store.days[day1]!!.creditedMs)       // yesterday stored in full
        assertEquals(1, sink.rows.size)                           // yesterday's episode closed on its own date
        assertEquals(day1, sink.rows[0].date)
        assertEquals(3L, sink.rows[0].seconds)
        assertEquals(0, snap.lecturesWatched)
    }

    @Test
    fun refreshDayRollsOverWithoutAnyCredit() = runBlocking {
        val clock = Clock(epoch(day1, 23, 59, 59))
        val ledger = ledgerOf(FakeStore(), FakeSink(), clock)
        ledger.record("l1", 2_000, 1.0, 600.0)
        clock.now = epoch(day2, 0, 0, 5)
        ledger.refreshDay()
        assertEquals(day2, ledger.snapshot.value.date)
        assertEquals(0L, ledger.snapshot.value.creditedMs)
    }

    @Test
    fun lectureBecomesWatchedOnceAndIsCountedInTheEpisodeRow() = runBlocking {
        val sink = FakeSink()
        val ledger = ledgerOf(FakeStore(), sink, Clock(epoch(day1, 12, 0)))
        ledger.record("l1", 69_999, 95.0, 100.0)
        assertEquals(0, ledger.snapshot.value.lecturesWatched)    // credit just short of 70%
        ledger.record("l1", 1, 96.0, 100.0)
        assertEquals(1, ledger.snapshot.value.lecturesWatched)
        ledger.record("l1", 1_000, 97.0, 100.0)                   // sticky, not counted twice
        assertEquals(1, ledger.snapshot.value.lecturesWatched)
        ledger.flush()
        assertEquals(1, sink.rows.size)
        assertEquals(1, sink.rows[0].newlyWatched)
    }

    @Test
    fun seekToTheEndAloneDoesNotMakeALectureWatched() = runBlocking {
        val ledger = ledgerOf(FakeStore(), FakeSink(), Clock(epoch(day1, 12, 0)))
        val st = ledger.record("l1", 0, 100.0, 100.0)
        assertEquals(100.0, st.maxPositionSec, 0.0)
        assertFalse(st.watched)
    }

    @Test
    fun maxPositionNeverGoesBackwardsAndIsClampedToTheDuration() = runBlocking {
        val ledger = ledgerOf(FakeStore(), FakeSink(), Clock(epoch(day1, 12, 0)))
        ledger.record("l1", 0, 80.0, 100.0)
        val back = ledger.record("l1", 0, 10.0, 100.0)
        assertEquals(80.0, back.maxPositionSec, 0.0)
        val over = ledger.record("l1", 0, 500.0, 100.0)
        assertEquals(100.0, over.maxPositionSec, 0.0)
    }

    @Test
    fun requirementNotificationFiresOncePerDayAndSurvivesARestart() = runBlocking {
        val store = FakeStore()
        val clock = Clock(epoch(day1, 12, 0))
        var fired = 0
        val ledger = ledgerOf(store, FakeSink(), clock, requiredMinutes = 1, onMet = { fired++ })
        ledger.record("l1", 30_000, 1.0, 600.0)
        assertEquals(0, fired)
        ledger.record("l1", 30_000, 2.0, 600.0)
        assertEquals(1, fired)
        ledger.record("l1", 30_000, 3.0, 600.0)
        assertEquals(1, fired)
        assertTrue(store.days[day1]!!.requirementNotified)        // persisted immediately
        ledger.flush()                                            // e.g. the app was paused

        // "Process restart": a new ledger over the same store must not notify again that day.
        var firedAgain = 0
        val restarted = ledgerOf(store, FakeSink(), clock, requiredMinutes = 1, onMet = { firedAgain++ })
        restarted.refreshDay()
        assertEquals(90_000L, restarted.snapshot.value.creditedMs)
        restarted.record("l1", 10_000, 4.0, 600.0)
        assertEquals(0, firedAgain)

        // A new day notifies again.
        clock.now = epoch(day2, 12, 0)
        restarted.record("l1", 60_000, 5.0, 600.0)
        assertEquals(1, firedAgain)
    }

    @Test
    fun studyBeforeTheScheduledTimeCountsForTheSameDay() = runBlocking {
        val store = FakeStore()
        val clock = Clock(epoch(day1, 6, 30))                    // before a 7:00 session
        val early = ledgerOf(store, FakeSink(), clock)
        early.record("l1", 20 * 60_000L, 100.0, 1_200.0)
        early.flush()
        clock.now = epoch(day1, 7, 5)
        val later = ledgerOf(store, FakeSink(), clock)
        later.refreshDay()
        assertEquals(20 * 60_000L, later.snapshot.value.creditedMs)
    }
}
