package com.example.focuslock.walking

import com.example.focuslock.domain.LogSource
import com.example.focuslock.domain.stats.HomeAggregator
import com.example.focuslock.domain.stats.LogEntry
import com.example.focuslock.domain.stats.Metric
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class WalkingReportAndHomeTest {
    private val today = LocalDate.of(2026, 10, 2)

    private fun day(date: String, daily: Int) = DayRow(date, false, daily, daily, 0L)
    private fun session(date: String, steps: Int) =
        SessionRow(at(date, 21), at(date, 21, 30), steps, 600_000L, steps, "", 0, 0L)

    @Test
    fun totalIsDailyPlusSessionForTodayMonthAndLastSevenDays() {
        val days = listOf(day("2026-10-02", 1200), day("2026-10-01", 3000), day("2026-09-30", 500))
        val sessions = listOf(session("2026-10-02", 900), session("2026-10-01", 2500))
        val r = WalkingReportBuilder.build(days, sessions, today, UTC_ZONE)

        assertEquals(StepTotals(1200, 900), r.today)
        assertEquals(2100, r.today.total)
        assertEquals(StepTotals(4200, 3400), r.month)           // September 30 is not in October
        assertEquals(7600, r.month.total)
        assertEquals(7, r.last7.size)
        assertEquals(today, r.last7.first().date)
        assertEquals(LocalDate.of(2026, 9, 26), r.last7.last().date)
        assertEquals(StepTotals(500, 0), r.last7[2].totals)    // 2026-09-30
        assertEquals(StepTotals(3000, 2500), r.last7[1].totals)
    }

    @Test
    fun anOpenSessionShowsItsLiveStepsAsSession() {
        val open = SessionRow(at("2026-10-02", 21), SessionRow.OPEN, 340, 60_000L, 0, "", 5, 0L)
        val r = WalkingReportBuilder.build(listOf(day("2026-10-02", 1200)), listOf(open), today, UTC_ZONE)
        assertEquals(StepTotals(1200, 340), r.today)
    }

    private fun entry(date: LocalDate, started: Long, secs: Long, steps: Int?, source: String) =
        LogEntry("walking", date, started, secs, steps, source)

    @Test
    fun homeStepsAreDailyPlusSessionWithoutDoubleCounting() {
        val logs = listOf(
            entry(today, 100L, 0L, 1200, LogSource.WALK_DAILY),         // steps outside the session
            entry(today, 200L, 600L, 900, LogSource.WALK_SESSION),      // steps inside it + walking seconds
            entry(today, 200L, 0L, null, LogSource.SCHEDULED),          // the Unlock row: 0 seconds, no steps
        )
        val card = HomeAggregator.aggregate(
            logs, listOf("walking"), today, YearMonth.of(2026, 10), Metric.STEPS, stepModuleIds = setOf("walking"),
        ).cards.single()
        assertEquals(2100L, card.today.steps)
        assertEquals(2100L, card.month.steps)
        assertEquals(600L, card.today.seconds)                          // Hours = walking time, not session length
        assertEquals(1, card.today.sessions)                            // only the scheduled row is a session
    }

    @Test
    fun ledgerRowsAreNeverSessionsAndHomeIsNotEmptyWithOnlyDailySteps() {
        assertFalse(LogSource.isSessionRow(LogSource.WALK_DAILY))
        assertFalse(LogSource.isSessionRow(LogSource.WALK_SESSION))
        assertTrue(LogSource.isSessionRow(LogSource.SCHEDULED))
        val stats = HomeAggregator.aggregate(
            listOf(entry(today, 1L, 0L, 5000, LogSource.WALK_DAILY)),
            listOf("walking"), today, YearMonth.of(2026, 10), Metric.STEPS, stepModuleIds = setOf("walking"),
        )
        assertFalse(stats.isEmpty)
        assertEquals(0, stats.cards.single().today.sessions)
        assertEquals(5000L, stats.cards.single().today.steps)
    }

    @Test
    fun testSessionRowsStayHiddenButLedgerRowsAreAlwaysShown() {
        val logs = listOf(
            entry(today, 200L, 0L, null, LogSource.TEST),
            entry(today, 200L, 300L, 700, LogSource.WALK_SESSION),
        )
        val hidden = HomeAggregator.aggregate(logs, listOf("walking"), today, YearMonth.of(2026, 10), Metric.SESSIONS)
        assertEquals(0, hidden.cards.single().today.sessions)
        assertEquals(700L, hidden.cards.single().today.steps)
        val shown = HomeAggregator.aggregate(
            logs, listOf("walking"), today, YearMonth.of(2026, 10), Metric.SESSIONS, includeTestSessions = true,
        )
        assertEquals(1, shown.cards.single().today.sessions)
    }
}
