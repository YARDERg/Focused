package com.example.focuslock.walking

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

internal val UTC_ZONE: ZoneOffset = ZoneOffset.UTC

internal fun at(date: String, hour: Int, minute: Int = 0, second: Int = 0): Long =
    LocalDateTime.of(LocalDate.parse(date), java.time.LocalTime.of(hour, minute, second)).toInstant(UTC_ZONE).toEpochMilli()

internal class MutableClock(var now: Long)

/** Recording API stand-in: a list of (timestamp, steps) points; ranges are [start, end). */
internal class FakeSource : StepsSource {
    val points = ArrayList<Pair<Long, Int>>()
    var availability = SourceAvailability.OK
    var failReads = false
    var subscribeCalls = 0

    fun add(t: Long, steps: Int) { points.add(t to steps) }

    override suspend fun status(): SourceStatus = SourceStatus(availability)
    override suspend fun ensureSubscribed(): SubscribeInfo {
        subscribeCalls++
        return SubscribeInfo(availability == SourceAvailability.OK, 0L, "fake")
    }

    override suspend fun readSteps(startMs: Long, endMs: Long): Int? =
        if (failReads) null else points.filter { it.first >= startMs && it.first < endMs }.sumOf { it.second }

    override suspend fun readHourly(startMs: Long, endMs: Long): List<HourRow>? {
        if (failReads) return null
        return points.filter { it.first >= startMs && it.first < endMs }
            .groupBy { HourMath.hourStart(it.first, UTC_ZONE) }
            .map { (h, ps) -> HourRow(h, ps.sumOf { it.second }) }
            .sortedBy { it.hourStartEpoch }
    }

    override suspend fun newestPointMs(): Long? = points.maxOfOrNull { it.first }
}

internal class FakeStepsStore : StepsStore {
    val hours = HashMap<Long, HourRow>()
    val days = HashMap<String, DayRow>()
    val sessions = HashMap<Long, SessionRow>()

    override suspend fun upsertHours(rows: List<HourRow>) { rows.forEach { hours[it.hourStartEpoch] = it } }
    override suspend fun hoursBetween(fromEpoch: Long, toEpochExclusive: Long) =
        hours.values.filter { it.hourStartEpoch >= fromEpoch && it.hourStartEpoch < toEpochExclusive }.sortedBy { it.hourStartEpoch }

    override suspend fun getDay(date: String): DayRow? = days[date]
    override suspend fun upsertDay(row: DayRow) { days[row.date] = row }
    override suspend fun daysBetween(fromDate: String, toDate: String) =
        days.values.filter { it.date >= fromDate && it.date <= toDate }.sortedBy { it.date }

    override suspend fun markNotified(date: String) {
        val e = days[date]
        days[date] = e?.copy(requirementNotified = true) ?: DayRow(date, true, 0, 0, 0L)
    }

    override suspend fun upsertSession(row: SessionRow) { sessions[row.startEpochMs] = row }
    override suspend fun updateProgress(startEpochMs: Long, sessionSteps: Int, walkingMs: Long, ignoredSteps: Int) {
        val s = sessions[startEpochMs] ?: return
        if (s.isOpen) sessions[startEpochMs] = s.copy(sessionSteps = sessionSteps, sessionWalkingMs = walkingMs, ignoredSteps = ignoredSteps)
    }
    override suspend fun getSession(startEpochMs: Long) = sessions[startEpochMs]
    override suspend fun openSession() = sessions.values.filter { it.isOpen }.maxByOrNull { it.startEpochMs }
    override suspend fun deleteSession(startEpochMs: Long) { sessions.remove(startEpochMs) }
    override suspend fun sessionsOverlapping(fromEpoch: Long, toEpochExclusive: Long) =
        sessions.values.filter { it.startEpochMs < toEpochExclusive && (it.isOpen || it.endEpochMs > fromEpoch) }.sortedBy { it.startEpochMs }
    override suspend fun sessionsEndedSince(sinceEpoch: Long) =
        sessions.values.filter { !it.isOpen && it.endEpochMs >= sinceEpoch }.sortedBy { it.startEpochMs }
    override suspend fun sessionsStartedBetween(fromEpoch: Long, toEpochExclusive: Long) =
        sessions.values.filter { it.startEpochMs >= fromEpoch && it.startEpochMs < toEpochExclusive }.sortedBy { it.startEpochMs }
}

internal class FakeWalkSink : WalkLogSink {
    data class Daily(val date: String, val steps: Int)
    data class Sess(val date: String, val start: Long, val end: Long, val steps: Int, val walkingSeconds: Long)

    val daily = HashMap<String, Daily>()
    val sessions = HashMap<Long, Sess>()

    override suspend fun upsertDaily(date: String, dayStartMs: Long, dayEndMs: Long, steps: Int) { daily[date] = Daily(date, steps) }
    override suspend fun upsertSession(date: String, startMs: Long, endMs: Long, steps: Int, walkingSeconds: Long) {
        sessions[startMs] = Sess(date, startMs, endMs, steps, walkingSeconds)
    }
    override suspend fun deleteSession(startMs: Long) { sessions.remove(startMs) }
}

internal fun mirrorOf(src: FakeSource, store: FakeStepsStore, sink: FakeWalkSink, clock: MutableClock) =
    StepsMirror(src, store, sink, clock = { clock.now }, zone = { UTC_ZONE })
