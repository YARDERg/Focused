package com.example.focuslock.walking

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SensorAndTrackerTest {

    @Test
    fun firstReadingIsTheBaselineSoEarlierStepsNeverCount() {
        val b = SensorBaseline()
        assertEquals(0, b.delta(5000f))      // steps taken before the session
        assertEquals(10, b.delta(5010f))
        assertEquals(5, b.delta(5015f))
        assertEquals(0, b.rebases)
    }

    @Test
    fun counterGoingDownIsARebaseAfterReboot() {
        val b = SensorBaseline()
        b.delta(5000f)
        b.delta(5010f)
        assertEquals(7, b.delta(7f))         // rebooted: 7 steps since the restart
        assertEquals(1, b.rebases)
        assertEquals(5, b.delta(12f))        // and the next delta is relative to the new baseline
        assertEquals(0, b.delta(Float.NaN))
    }

    @Test
    fun spreaderPlacesTheLastStepAtTheEventTimeAndCapsTheSpan() {
        assertEquals(listOf(1000L), StepSpreader.spread(0L, 1000L, 1))
        assertEquals(listOf(1000L, 1000L, 1000L), StepSpreader.spread(-1L, 1000L, 3))
        assertEquals(listOf(250L, 500L, 750L, 1000L), StepSpreader.spread(0L, 1000L, 4))
        assertEquals(listOf(57_500L, 60_000L), StepSpreader.spread(0L, 60_000L, 2, capMs = 5_000L))
        assertTrue(StepSpreader.spread(0L, 1000L, 0).isEmpty())
    }

    @Test
    fun trackerCountsOnlyAfterBeginAndOnlyWhileWalking() {
        val t = WalkSessionTracker()
        assertEquals(0, t.onCounterValue(100f, 0L))          // no session: ignored, nothing is stored
        assertFalse(t.isActive)

        t.begin(startMs = 0L, thresholdPerMin = 60)
        t.onCounterValue(1000f, 0L)                          // baseline
        for (i in 1..60) t.onCounterValue(1000f + i, i * 500L)
        val live = t.live.value
        assertTrue(live.active)
        assertEquals(60, live.sessionSteps)
        assertEquals(CadenceStatus.WALKING, live.status)
        assertEquals(15_000L, live.walkingMs)
        assertEquals(0, live.walkingMinutes)
        assertEquals(1060f, live.rawCounter, 0.0001f)
    }

    @Test
    fun trackerStandingStillCountsNothing() {
        val t = WalkSessionTracker()
        t.begin(0L, 60)
        t.onCounterValue(1000f, 0L)
        for (s in 1..120) t.tick(s * 1000L)                  // two minutes without a step
        assertEquals(0, t.live.value.sessionSteps)
        assertEquals(CadenceStatus.NOT_WALKING, t.live.value.status)
    }

    @Test
    fun trackerRebasesAfterRebootAndSaysSo() {
        val t = WalkSessionTracker()
        t.begin(0L, 60)
        t.onCounterValue(5000f, 0L)
        assertEquals(3, t.onCounterValue(3f, 1000L))         // counter restarted
        assertEquals("step counter went down (reboot): baseline rebased", t.live.value.lastSkipReason)
        assertEquals(5, t.onCounterValue(8f, 2000L))
    }

    @Test
    fun trackerRestoreKeepsTotalsAndEndReturnsThem() {
        val t = WalkSessionTracker()
        t.restore(startMs = 1234L, steps = 800, walkingMs = 400_000L, ignored = 9, thresholdPerMin = 60)
        assertEquals(800, t.live.value.sessionSteps)
        assertEquals(6, t.live.value.walkingMinutes)
        val end = t.end()!!
        assertEquals(TrackerSnapshot(1234L, 800, 400_000L, 9), end)
        assertFalse(t.live.value.active)
        assertNull(t.end())
        assertNull(t.snapshot())
    }

    @Test
    fun detectorStepsFeedTheSameRule() {
        val t = WalkSessionTracker()
        t.begin(0L, 60)
        for (i in 0 until 30) t.onDetectorStep(i * 500L)
        assertEquals(30, t.live.value.sessionSteps)
    }
}
