package com.example.focuslock.learning

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LectureKeysTest {
    private val base = "https://www.udemy.com/course/python-bootcamp/learn/lecture/12345678"

    @Test
    fun extractsIdFromVerifiedUrlFormat() {
        assertEquals("12345678", LectureId.fromUrl(base))
    }

    @Test
    fun ignoresQueryFragmentAndTrailingSlash() {
        assertEquals("12345678", LectureId.fromUrl("$base?start=120"))
        assertEquals("12345678", LectureId.fromUrl("$base#overview"))
        assertEquals("12345678", LectureId.fromUrl("$base/"))
    }

    @Test
    fun noIdWhenThereIsNoLectureSegment() {
        assertNull(LectureId.fromUrl(null))
        assertNull(LectureId.fromUrl(""))
        assertNull(LectureId.fromUrl("https://www.udemy.com/course/python-bootcamp/learn/"))
        assertNull(LectureId.fromUrl("https://www.udemy.com/course/x/learn/lecture/abc"))
    }

    @Test
    fun onlyThePathIsSearched() {
        assertNull(LectureId.fromUrl("https://www.udemy.com/course/x/learn/?next=/lecture/55"))
        assertNull(LectureId.fromUrl("https://www.udemy.com/course/x/learn/#/lecture/55"))
    }

    @Test
    fun coursePath() {
        assertEquals("/course/python-bootcamp", LectureKeys.coursePath(base))
        assertEquals("/home/my-courses", LectureKeys.coursePath("https://www.udemy.com/home/my-courses/"))
        assertEquals("/", LectureKeys.coursePath(null))
    }

    @Test
    fun fingerprintMatchesIndependentFnv1aReference() {
        // Reference values computed with a separate FNV-1a 64 implementation (Python).
        assertEquals("fp-13585bc2f859334c", LectureKeys.fingerprint("/course/x", 600.0, "Intro"))
        assertEquals("fp-e977fb48d1516b7f", LectureKeys.fingerprint("/course/x", 601.0, "Intro"))
    }

    @Test
    fun fingerprintRoundsDurationAndTrimsTitle() {
        assertEquals(
            LectureKeys.fingerprint("/course/x", 600.0, "Intro"),
            LectureKeys.fingerprint("/course/x", 600.4, "  Intro "),
        )
        assertNotEquals(
            LectureKeys.fingerprint("/course/x", 600.0, "Intro"),
            LectureKeys.fingerprint("/course/x", 601.0, "Intro"),
        )
        assertNotEquals(
            LectureKeys.fingerprint("/course/x", 600.0, "Intro"),
            LectureKeys.fingerprint("/course/y", 600.0, "Intro"),
        )
        assertNotEquals(
            LectureKeys.fingerprint("/course/x", 600.0, "Intro"),
            LectureKeys.fingerprint("/course/x", 600.0, "Outro"),
        )
    }

    @Test
    fun resolveUsesTheIdWhenPresent() {
        val k = LectureKeys.resolve(base, 600.0, "Intro")
        assertEquals("12345678", k.key)
        assertEquals(LectureKey.SOURCE_URL, k.source)
        assertEquals("12345678", k.lectureId)
    }

    @Test
    fun resolveNeverReturnsNullAndFallsBackToFingerprint() {
        val k = LectureKeys.resolve("https://www.udemy.com/course/x/learn/", 0.0, null)
        assertTrue(k.key.startsWith("fp-"))
        assertEquals(LectureKey.SOURCE_FINGERPRINT, k.source)
        assertNull(k.lectureId)
        val none = LectureKeys.resolve(null, Double.NaN, null)
        assertTrue(none.key.startsWith("fp-"))
    }
}
