package com.example.focuslock.walking

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StepsMirrorTest {
    private val d1 = "2026-10-01"
    private val d2 = "2026-10-02"

    @Test
    fun dailyIsDayAggregateMinusSessionRaw() = runBlocking {
        val src = FakeSource()
        src.add(at(d2, 8, 0), 1000)                // outside the session
        src.add(at(d2, 21, 10), 700)               // inside the session [21:00, 21:30)
        src.add(at(d2, 21, 20), 300)
        src.add(at(d2, 21, 45), 200)               // after the session
        val store = FakeStepsStore()
        val sink = FakeWalkSink()
        val clock = MutableClock(at(d2, 21, 50))
        val m = mirrorOf(src, store, sink, clock)

        val start = at(d2, 21, 0)
        val end = at(d2, 21, 30)
        m.openSession(start)
        m.closeSession(start, end, steps = 900, walkingMs = 600_000L, ignored = 50)

        val day = store.days[d2]!!
        val session = store.sessions[start]!!
        assertEquals(2200, day.dayRawSteps)
        assertEquals(1000, session.sessionRawSteps)
        assertEquals(1200, day.dailySteps)
        // Day raw = Daily + session raw by construction.
        assertEquals(day.dayRawSteps, day.dailySteps + session.sessionRawSteps)
        // Ledger: daily steps outside, session steps counted + walking seconds.
        assertEquals(1200, sink.daily[d2]!!.steps)
        assertEquals(900, sink.sessions[start]!!.steps)
        assertEquals(600L, sink.sessions[start]!!.walkingSeconds)
        // Total = Daily + Session counted; the difference from raw (100) is the ignored steps.
        assertEquals(2100, sink.daily[d2]!!.steps + sink.sessions[start]!!.steps)
    }

    @Test
    fun sessionCrossingMidnightIsSplitByDate() = runBlocking {
        val src = FakeSource()
        src.add(at(d1, 10, 0), 1000)
        src.add(at(d1, 23, 40), 400)               // session part on day 1
        src.add(at(d2, 0, 10), 300)                // session part on day 2
        src.add(at(d2, 9, 0), 500)
        val store = FakeStepsStore()
        val sink = FakeWalkSink()
        val clock = MutableClock(at(d2, 10, 0))
        val m = mirrorOf(src, store, sink, clock)

        val start = at(d1, 23, 30)
        val end = at(d2, 0, 30)
        m.openSession(start)
        m.closeSession(start, end, steps = 650, walkingMs = 1_200_000L, ignored = 0)

        val s = store.sessions[start]!!
        assertEquals(700, s.sessionRawSteps)
        assertEquals(mapOf(d1 to 400, d2 to 300), RawByDay.decode(s.rawByDay))
        assertEquals(1400, store.days[d1]!!.dayRawSteps)
        assertEquals(1000, store.days[d1]!!.dailySteps)
        assertEquals(800, store.days[d2]!!.dayRawSteps)
        assertEquals(500, store.days[d2]!!.dailySteps)
        // The ledger session row sits on the start date.
        assertEquals(d1, sink.sessions[start]!!.date)
    }

    @Test
    fun hourlyBucketsAreMirroredForChartsOnly() = runBlocking {
        val src = FakeSource()
        src.add(at(d2, 8, 10), 100)
        src.add(at(d2, 8, 50), 50)
        src.add(at(d2, 9, 5), 30)
        val store = FakeStepsStore()
        val clock = MutableClock(at(d2, 12, 0))
        val m = mirrorOf(src, store, FakeWalkSink(), clock)

        val r = m.run()
        assertTrue(r.ok)
        assertEquals(150, store.hours[at(d2, 8, 0)]!!.rawSteps)
        assertEquals(30, store.hours[at(d2, 9, 0)]!!.rawSteps)
        assertEquals(2, store.hours.size)
        // Daily comes from the day aggregate, not from summing hours; here they agree.
        assertEquals(180, store.days[d2]!!.dayRawSteps)
        val chart = HourlyRollup.chartForDate(store.hours.values.toList(), d2, UTC_ZONE)
        assertEquals(150, chart[8])
        assertEquals(30, chart[9])
        assertEquals(180, chart.sum())
    }

    @Test
    fun reReadingLateDataIsIdempotent() = runBlocking {
        val src = FakeSource()
        src.add(at(d2, 8, 10), 100)
        src.add(at(d2, 9, 5), 30)
        val store = FakeStepsStore()
        val sink = FakeWalkSink()
        val clock = MutableClock(at(d2, 12, 0))
        val m = mirrorOf(src, store, sink, clock)

        m.run()
        val hoursAfterFirst = store.hours.toMap()
        m.run()                                                // same data again: nothing changes, nothing duplicates
        assertEquals(hoursAfterFirst, store.hours.toMap())
        assertEquals(130, store.days[d2]!!.dayRawSteps)
        val ledgerRows = sink.daily.size

        src.add(at(d2, 8, 20), 25)                             // late data for an hour that was already mirrored
        m.run()
        assertEquals(125, store.hours[at(d2, 8, 0)]!!.rawSteps)   // replaced, not added
        assertEquals(155, store.days[d2]!!.dayRawSteps)
        assertEquals(155, store.days[d2]!!.dailySteps)
        assertEquals(ledgerRows, sink.daily.size)              // keyed by date: still one row per day
    }

    @Test
    fun failedOrEmptyReadsNeverLowerStoredHistory() = runBlocking {
        val src = FakeSource()
        src.add(at(d2, 8, 10), 100)
        val store = FakeStepsStore()
        val clock = MutableClock(at(d2, 12, 0))
        val m = mirrorOf(src, store, FakeWalkSink(), clock)
        m.run()
        assertEquals(100, store.days[d2]!!.dayRawSteps)

        src.failReads = true                                   // a failed read changes nothing
        val failed = m.run()
        assertFalse(failed.ok)
        assertEquals(100, store.days[d2]!!.dayRawSteps)

        src.failReads = false
        src.points.clear()                                     // the API forgot the data (10-day retention)
        m.run()
        assertEquals(100, store.days[d2]!!.dayRawSteps)
        assertEquals(100, store.hours[at(d2, 8, 0)]!!.rawSteps)
    }

    @Test
    fun sessionRawIsRefreshedByLaterMirrorRunsForTwentyFourHours() = runBlocking {
        val src = FakeSource()
        src.add(at(d2, 21, 10), 700)
        val store = FakeStepsStore()
        val clock = MutableClock(at(d2, 21, 30))
        val m = mirrorOf(src, store, FakeWalkSink(), clock)
        val start = at(d2, 21, 0)
        m.openSession(start)
        m.closeSession(start, at(d2, 21, 30), 600, 500_000L, 0)
        assertEquals(700, store.sessions[start]!!.sessionRawSteps)

        src.add(at(d2, 21, 25), 40)                            // arrives late
        clock.now = at(d2, 23, 0)
        m.run()
        assertEquals(740, store.sessions[start]!!.sessionRawSteps)
        assertEquals(740, RawByDay.decode(store.sessions[start]!!.rawByDay)[d2])
        // Still no double counting after the refresh.
        val day = store.days[d2]!!
        assertEquals(day.dayRawSteps, day.dailySteps + 740)
    }

    @Test
    fun runningSessionIsExcludedFromDaily() = runBlocking {
        val src = FakeSource()
        src.add(at(d2, 8, 0), 1000)
        src.add(at(d2, 21, 5), 150)                            // already inside the open session
        val store = FakeStepsStore()
        val clock = MutableClock(at(d2, 21, 10))
        val m = mirrorOf(src, store, FakeWalkSink(), clock)
        m.openSession(at(d2, 21, 0))
        assertTrue(m.refreshDay(d2))
        assertEquals(1150, store.days[d2]!!.dayRawSteps)
        assertEquals(1000, store.days[d2]!!.dailySteps)        // session steps never count as Daily
    }

    @Test
    fun unavailableSourceSkipsMirrorButTheSessionStillCloses() = runBlocking {
        val src = FakeSource()
        src.availability = SourceAvailability.NO_PERMISSION
        src.failReads = true
        val store = FakeStepsStore()
        val sink = FakeWalkSink()
        val clock = MutableClock(at(d2, 21, 30))
        val m = mirrorOf(src, store, sink, clock)

        val r = m.run()
        assertFalse(r.ok)
        assertTrue(r.message.contains("skipped"))
        assertTrue(store.days.isEmpty())

        val start = at(d2, 21, 0)
        m.openSession(start)
        m.closeSession(start, at(d2, 21, 30), 3000, 900_000L, 12)
        assertEquals(3000, store.sessions[start]!!.sessionSteps)   // session tracking keeps working
        assertEquals(0, store.sessions[start]!!.sessionRawSteps)
        assertEquals(3000, sink.sessions[start]!!.steps)
    }

    @Test
    fun discardedSessionForgetsItsRowsSoItsStepsCountAsDailyAgain() = runBlocking {
        val src = FakeSource()
        src.add(at(d2, 21, 10), 500)
        val store = FakeStepsStore()
        val sink = FakeWalkSink()
        val clock = MutableClock(at(d2, 21, 20))
        val m = mirrorOf(src, store, sink, clock)
        val start = at(d2, 21, 0)
        m.openSession(start)
        m.discardSession(start)
        assertNull(store.sessions[start])
        assertNull(sink.sessions[start])
        assertEquals(500, store.days[d2]!!.dailySteps)
    }
}
