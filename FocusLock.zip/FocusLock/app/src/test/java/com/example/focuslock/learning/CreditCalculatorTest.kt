package com.example.focuslock.learning

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CreditCalculatorTest {

    private fun credit(
        media: Long,
        wall: Long,
        rate: Double = 1.0,
        interactive: Boolean = true,
        resumed: Boolean = true,
        playing: Boolean = true,
    ) = CreditCalculator.credit(media, wall, rate, interactive, resumed, playing)

    @Test
    fun normalPlaybackCreditsTheSample() {
        val d = credit(250, 250)
        assertEquals(250L, d.creditedMs)
        assertNull(d.skipReason)
    }

    @Test
    fun seekForwardEarnsNothing() {
        val d = credit(media = 60_000, wall = 250)
        assertEquals(0L, d.creditedMs)
        assertNotNull(d.skipReason)
    }

    @Test
    fun seekBackwardEarnsNothing() {
        assertEquals(0L, credit(media = -30_000, wall = 250).creditedMs)
        assertEquals(0L, credit(media = 0, wall = 250).creditedMs)
    }

    @Test
    fun oneAndAHalfSpeedCreditsRealTimeNotMediaTime() {
        // 1.5x: the video advances 375 ms per 250 ms of wall time; credit is the real time.
        assertEquals(250L, credit(media = 375, wall = 250, rate = 1.5).creditedMs)
        // 2x within the jitter allowance (250 * 2 * 1.3 = 650).
        assertEquals(250L, credit(media = 500, wall = 250, rate = 2.0).creditedMs)
    }

    @Test
    fun jitterWithinThirtyPercentIsTolerated() {
        assertEquals(250L, credit(media = 320, wall = 250).creditedMs)     // 320 <= 325
        assertEquals(0L, credit(media = 340, wall = 250).creditedMs)       // 340 > 325
    }

    @Test
    fun slowPlaybackCreditsMediaTime() {
        // 0.5x: media advances 125 ms per 250 ms wall; credit = media delta.
        assertEquals(125L, credit(media = 125, wall = 250, rate = 0.5).creditedMs)
    }

    @Test
    fun gapIsCappedAtFiveSeconds() {
        assertEquals(5_000L, credit(media = 8_000, wall = 8_000).creditedMs)
        assertEquals(3_000L, credit(media = 3_000, wall = 3_000).creditedMs)
    }

    @Test
    fun gatesNeedPlayingResumedAndInteractive() {
        assertEquals(0L, credit(250, 250, playing = false).creditedMs)
        assertEquals(0L, credit(250, 250, resumed = false).creditedMs)
        assertEquals(0L, credit(250, 250, interactive = false).creditedMs)
        assertEquals(0L, credit(250, 0).creditedMs)
    }

    @Test
    fun skipReasonNamesTheFirstFailedGate() {
        assertTrue(credit(250, 250, playing = false).skipReason!!.contains("not playing"))
        assertTrue(credit(250, 250, resumed = false).skipReason!!.contains("resumed"))
        assertTrue(credit(250, 250, interactive = false).skipReason!!.contains("interactive"))
        assertTrue(credit(60_000, 250).skipReason!!.contains("jump"))
    }
}

class VideoSampleParserTest {
    @Test
    fun parsesAPlayingSample() {
        val s = VideoSampleParser.parse("\"1|0|0|12.5|600.25|1.5\"")!!
        assertTrue(s.found)
        assertTrue(s.playing)
        assertEquals(12.5, s.currentSec, 1e-9)
        assertEquals(600.25, s.durationSec, 1e-9)
        assertEquals(1.5, s.playbackRate, 1e-9)
    }

    @Test
    fun pausedAndEndedAreNotPlaying() {
        assertTrue(!VideoSampleParser.parse("\"1|1|0|1|10|1\"")!!.playing)
        assertTrue(!VideoSampleParser.parse("\"1|0|1|10|10|1\"")!!.playing)
    }

    @Test
    fun noVideoAndFailures() {
        assertEquals(VideoSample.NONE, VideoSampleParser.parse("\"0\""))
        assertNull(VideoSampleParser.parse("null"))
        assertNull(VideoSampleParser.parse(null))
        assertNull(VideoSampleParser.parse("\"1|0|0\""))
        assertNull(VideoSampleParser.parse("garbage"))
    }

    @Test
    fun nonFiniteDurationBecomesZero() {
        val s = VideoSampleParser.parse("\"1|0|0|3|NaN|1\"")!!
        assertEquals(0.0, s.durationSec, 0.0)
        val inf = VideoSampleParser.parse("\"1|0|0|3|Infinity|1\"")!!
        assertEquals(0.0, inf.durationSec, 0.0)
    }
}

class WatchedRuleTest {
    @Test
    fun needsBothPositionAndCredit() {
        // duration 100 s: 90% position and 70% credit are the thresholds.
        assertTrue(WatchedRule.evaluate(90.0, 100.0, 70_000, 70).watched)
        assertTrue(!WatchedRule.evaluate(89.9, 100.0, 70_000, 70).watched)
        assertTrue(!WatchedRule.evaluate(90.0, 100.0, 69_999, 70).watched)
    }

    @Test
    fun seekingToTheEndWithoutWatchingIsNotWatched() {
        val v = WatchedRule.evaluate(maxPositionSec = 100.0, durationSec = 100.0, creditedMs = 2_000, minSharePercent = 70)
        assertTrue(!v.watched)
        assertTrue(v.reason.contains("credited"))
    }

    @Test
    fun shareIsConfigurable() {
        assertTrue(WatchedRule.evaluate(100.0, 100.0, 50_000, 50).watched)
        assertTrue(!WatchedRule.evaluate(100.0, 100.0, 99_999, 100).watched)
        assertTrue(WatchedRule.evaluate(100.0, 100.0, 100_000, 100).watched)
    }

    @Test
    fun unknownDurationIsNeverWatched() {
        assertTrue(!WatchedRule.evaluate(50.0, 0.0, 50_000, 70).watched)
    }
}
