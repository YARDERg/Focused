package com.example.focuslock.learning

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StudyTrackerTest {
    private val lectureUrl = "https://www.udemy.com/course/x/learn/lecture/111"

    private class Rig(share: Int = 70) {
        val store = FakeStore()
        val sink = FakeSink()
        val clock = Clock(epoch("2026-10-02", 12, 0))
        val ledger = ledgerOf(store, sink, clock, sharePercent = share)
        val tracker = StudyTracker(ledger) { share }
        var wall = 1_000L

        fun sample(
            cur: Double,
            dur: Double = 600.0,
            rate: Double = 1.0,
            playing: Boolean = true,
            url: String? = "https://www.udemy.com/course/x/learn/lecture/111",
            stepMs: Long = 250,
            interactive: Boolean = true,
            resumed: Boolean = true,
        ) = runBlocking {
            wall += stepMs
            tracker.onSample(
                VideoSample(true, !playing, false, cur, dur, rate), url, "Title", wall, interactive, resumed,
            )
        }
    }

    @Test
    fun playingAtNormalSpeedCreditsRealTime() {
        val r = Rig()
        r.sample(10.0)                               // first sample: nothing to compare with
        repeat(8) { i -> r.sample(10.25 + i * 0.25) }
        assertEquals(2_000L, r.ledger.snapshot.value.creditedMs)
        assertEquals(2_000L, r.tracker.debug.value.lectureCreditedMs)
        assertEquals("111", r.tracker.debug.value.lectureId)
    }

    @Test
    fun oneAndAHalfSpeedStillCreditsRealTime() {
        val r = Rig()
        r.sample(0.0, rate = 1.5)
        repeat(4) { i -> r.sample(0.375 * (i + 1), rate = 1.5) }
        assertEquals(1_000L, r.ledger.snapshot.value.creditedMs)
    }

    @Test
    fun seekingToTheEndIsNotCreditedAndDoesNotCountAsWatched() {
        val r = Rig()
        r.sample(10.0)
        r.sample(10.25)                              // 250 ms credited
        r.sample(599.0)                              // seek to (almost) the end
        r.sample(599.25)                             // playing normally again, 250 ms
        assertEquals(500L, r.ledger.snapshot.value.creditedMs)
        val d = r.tracker.debug.value
        assertEquals(599.25, d.maxPositionSec, 1e-9)
        assertFalse(d.countsAsWatched)
        assertTrue(d.watchedReason.contains("credited"))
    }

    @Test
    fun watchingMostOfALectureCountsAsWatched() {
        val r = Rig(share = 70)
        val duration = 100.0
        r.sample(0.0, dur = duration)
        // 100 s of media in 250 ms steps = 400 samples
        for (i in 1..400) r.sample(i * 0.25, dur = duration)
        val d = r.tracker.debug.value
        assertTrue(d.countsAsWatched)
        assertEquals(1, r.ledger.snapshot.value.lecturesWatched)
        assertEquals(100_000L, r.ledger.snapshot.value.creditedMs)
    }

    @Test
    fun pausedVideoStaysAtZeroAndRecordsTheSkipReason() {
        val r = Rig()
        r.sample(10.0, playing = false)
        r.sample(10.0, playing = false)
        assertEquals(0L, r.ledger.snapshot.value.creditedMs)
        assertEquals("video not playing", r.tracker.debug.value.lastSkipReason)
    }

    @Test
    fun noCreditWhileStudyViewIsPausedOrScreenOff() {
        val r = Rig()
        r.sample(1.0)
        r.sample(1.25, resumed = false)
        r.sample(1.5, interactive = false)
        assertEquals(0L, r.ledger.snapshot.value.creditedMs)
        r.sample(1.75)
        assertEquals(250L, r.ledger.snapshot.value.creditedMs)
    }

    @Test
    fun longGapIsCappedAtFiveSeconds() {
        val r = Rig()
        r.sample(1.0)
        r.sample(9.0, stepMs = 8_000)                // 8 s of media in 8 s of wall time
        assertEquals(5_000L, r.ledger.snapshot.value.creditedMs)
    }

    @Test
    fun creditingNeverSkipsBecauseTheLectureIdIsNull() {
        val r = Rig()
        val url = "https://www.udemy.com/course/x/learn/"
        r.sample(1.0, url = url)
        r.sample(1.25, url = url)
        assertEquals(250L, r.ledger.snapshot.value.creditedMs)
        assertNull(r.tracker.debug.value.lectureId)
        assertEquals(LectureKey.SOURCE_FINGERPRINT, r.tracker.debug.value.lectureSource)
    }

    @Test
    fun switchingLectureStartsFreshAndKeepsBothLecturesSeparate() {
        val r = Rig()
        r.sample(1.0)
        r.sample(1.25)
        val other = "https://www.udemy.com/course/x/learn/lecture/222"
        r.sample(50.0, url = other)                  // first sample of the new lecture: no credit
        r.sample(50.25, url = other)
        assertEquals(500L, r.ledger.snapshot.value.creditedMs)
        assertEquals(250L, r.tracker.debug.value.lectureCreditedMs)
        assertEquals("222", r.tracker.debug.value.lectureId)
    }

    @Test
    fun everySampleIsCreditedExactlyOnce() {
        // The tracker is the only writer: the ledger total equals the sum of the per-sample credits.
        val r = Rig()
        r.sample(0.0)
        var expected = 0L
        for (i in 1..40) {
            r.sample(i * 0.25)
            expected += 250
        }
        assertEquals(expected, r.ledger.snapshot.value.creditedMs)
        runBlocking { r.ledger.flush() }
        assertEquals(expected / 1000, r.sink.rows.sumOf { it.seconds })
    }

    @Test
    fun resetForgetsThePreviousSample() {
        val r = Rig()
        r.sample(1.0)
        r.tracker.reset()
        r.sample(1.25)                               // first sample again after reset
        assertEquals(0L, r.ledger.snapshot.value.creditedMs)
    }

    @Test
    fun missingVideoOrFailedScriptCreditsNothing() = runBlocking {
        val r = Rig()
        r.tracker.onSample(VideoSample.NONE, lectureUrl, "T", 1_000, true, true)
        assertFalse(r.tracker.debug.value.videoFound)
        r.tracker.onSample(null, lectureUrl, "T", 1_250, true, true)
        assertEquals(0L, r.ledger.snapshot.value.creditedMs)
    }
}
