# Focus Lock - Stage 1 foundation

Package `com.example.focuslock` - Samsung Galaxy A16, Android 16. App shell, Room database, schedule, session-aware lock engine, statistics. Learning/Walking tasks are placeholders (a "Complete test task" button).

## Toolchain (as pinned in `gradle/libs.versions.toml`)
| Item | Value | Status |
|---|---|---|
| AGP | 9.4.0 (built-in Kotlin, no `kotlin.android` plugin) | 9.4.0 confirmed on developer.android.com |
| Gradle wrapper | 9.6.0 (AGP 9.4's minimum) | confirmed as AGP's minimum |
| JDK | 17 | AGP requirement |
| Kotlin / Compose compiler plugin | 2.4.0 | 2.4.0 confirmed released June 2026 |
| KSP | 2.3.11 | 2.3.9 confirmed to exist; 2.3.11 is the minimum you specified, **not verified** |
| Compose BOM | 2026.09.00 | confirmed in Android docs |
| activity-compose | 1.13.0 | confirmed in Android docs |
| Room | **3.0.3** (`androidx.room3`, KSP only) | confirmed latest stable (9 Sep 2026) |
| sqlite-bundled | 2.7.1 | version taken from the Room KMP doc, may be newer |
| lifecycle 2.10.0, datastore 1.2.0, core-ktx 1.17.0, coroutines 1.10.2 | | **not verified as latest**; they exist but newer ones may too |

compileSdk 37, targetSdk 36, minSdk 26. No Hilt; manual DI via `AppContainer`.

**Room 3 note:** "latest stable Room" is now Room 3, a breaking rewrite (new package `androidx.room3`, a SQLiteDriver is required, coroutine-only DAOs). I used it as asked (`BundledSQLiteDriver`). If KSP complains that `@ConstructedBy` is required on `AppDatabase`, follow the Room KMP doc ("Define database classes"). If you prefer zero risk, swap to Room 2.8.x: only the `data/` package and 3 catalog lines change.

## Build
1. Open the `FocusLock` folder in Android Studio (latest stable, JDK 17 as Gradle JDK). The wrapper properties pin Gradle 9.6.0; the IDE downloads it.
2. Command line (no `gradlew` is included on purpose): run `gradle wrapper --gradle-version 9.6.0` once with any local Gradle, then `./gradlew :app:testDebugUnitTest :app:assembleDebug`.
3. Install on the phone (USB debugging on): `./gradlew :app:installDebug`.

## First-run permission setup (Settings tab)
1. **Exact alarms** -> Allow (Android 14+ denies it by default). Without it the app falls back to inexact alarms.
2. **Display over other apps** -> Allow (required for the watchdog to relaunch the lock screen).
3. **Notifications** -> Allow.
4. **Battery optimization** -> Allow, then do the Samsung steps in the card (Never sleeping apps, Unrestricted).

## Test checklist
Turn the **debug toggle on** (Settings) first: it shows the crash diagnostics and the test-only switches.
1. Learning tab -> "Test session now": lock screen appears showing "0 / 1 completed".
2. Walking tab -> "Test session now": same, "0 / 1".
3. **Press Home repeatedly and fast** (20+ times; also the Home gesture and Recents): the lock screen comes straight back each time (immediate relaunch from `onUserLeaveHint`/`onStop`, the watchdog is only the backup at 500 ms). Back does nothing. Check Settings > Crash diagnostics afterwards: no crash recorded.
4. Emergency: tap "Emergency Call": the dialer opens; the lock stays away ~3 minutes, then returns. Calls are never blocked (no relaunch while ringing/in a call).
5. **Press Complete, then try to leave without Unlock**: the counter turns "1 / 1" and "Goals complete" + Unlock appear. Press Home, Recents, Back: the lock screen keeps returning. Nothing is logged yet (Home shows no new totals). Only Unlock (or the developer exit, which logs nothing) releases it.
6. Unlock logs: tap Unlock; with debug **on** Home shows today's Hours/Sessions for that module (test session). Turn debug **off**: the test-session totals disappear from Home (empty state on a fresh install). Month selector works; chips re-sort cards. Steps chip lists only Walking; Hours and Sessions list Learning and Walking.
7. Merge: start Learning test session, then (without unlocking) start Walking: counter becomes "x / 2".
8. **Test session does not enable the change**: after a Learning test session + Unlock, open the Learning tab: today's state is still "pending" and "Change tomorrow's time" is disabled with "Finish today's session first."
9. **Schedule in 2 minutes** (an override can no longer be set for today): temporarily edit `ScheduleDefaults.kt`: set `LEARNING_MINUTES` to the current time + 2 min and widen `LEARNING_WINDOW_START/END` so the default lies inside, then `installDebug`. The lock screen starts by itself at that minute (try with the screen off too). Complete the task and tap Unlock: the Learning tab shows "State: completed". Restore the constants afterwards.
10. **Change tomorrow's time, before and after completing**: before completing (step 9 before the alarm) the button is disabled with "Finish today's session first." After completing it is enabled.
11. **A time outside the window**: Learning, pick 6:00 AM or 12:30 PM -> the dialog stays open with "Pick a time between 7:00 AM and 12:00 PM." (Walking: outside 5:00 PM to 11:00 PM). 7:00 AM, 12:00 PM, 5:00 PM and 11:00 PM are accepted. Pick e.g. 9:30 AM: the dialog closes, the Tomorrow card shows "Tomorrow, 9:30 AM" and "Changed time".
12. **A second change attempt**: the button is now disabled with "Already changed for tomorrow." There is no undo and no "Use default" button.
13. Debug bypass: in Settings enable "Allow changing tomorrow without completing today": the button works without completing today (still only once per day). Turn debug off: the bypass stops working.
14. Override then default return: after step 12, move the phone date forward one day (Settings > Date and time; TIME_SET re-registers the alarm) or wait a day. The session fires at 9:30 AM; after it fires the Tomorrow card shows the default 7:00 AM again.
15. Reboot while locked: start a test session, reboot, unlock the phone: the lock screen returns with the same completed state.
16. Settings: revoke a permission in system settings, return: its card refreshes to "not granted".
17. Crash diagnostics (debug on): the card lists up to 5 stack traces and the last 10 process exits (reason, description, time, importance). "Copy all" puts everything on the clipboard; paste it into a note to check.

## Escape plan
`adb uninstall com.example.focuslock` (or the in-app Developer exit, password in `lock/DeveloperPassword.kt`: `Stage1Exit`). Keep USB debugging enabled and the PC authorised before testing.

## Changes in this revision
- **Lock enforcement:** `LockActivity` relaunches itself immediately from `onUserLeaveHint`/`onStop`/`onDestroy` (rules in `lock/RelaunchPolicy.kt`: session active, `now >= emergencyUntil`, overlay granted, not finishing because of Unlock, not a configuration change, screen interactive, no call). The watchdog runs every 500 ms and no longer checks task completion: the lock returns until Unlock/developer exit. Every relaunch call and every watchdog iteration is wrapped so it cannot throw.
- **Crash diagnostics:** `FocusLockApp` installs an uncaught-exception handler (`diag/`) that keeps the last 5 traces in `filesDir/crashes`. Settings (debug on only) shows them plus the last 10 `getHistoricalProcessExitReasons` entries, with "Copy all".
- **Change tomorrow's time** replaces "Change for today" (see rules below). Logs now carry `source = scheduled_session` or `test_session` (a session remembers the source per module; a scheduled trigger upgrades a test-started module, never the reverse). The Room schema did not change (`source` already existed), so no migration is needed.
- **Home:** `FeatureModule.recordsSteps` (Walking = true); the Steps metric lists only such modules. Test sessions count in Home only when debug is on.

### Tomorrow's-time rules
1. Allowed only when today's scheduled session of that module was completed with Unlock (a `scheduled_session` log whose session started today). Test sessions never count.
2. Only once: if an override already exists for tomorrow the button is disabled (no undo).
3. The time must lie inside the module's window (`ScheduleDefaults`: Learning 7:00 AM-12:00 PM, Walking 5:00 PM-11:00 PM, both ends inclusive; defaults lie inside).
4. The override is stored for tomorrow's date, used when the trigger falls on that date, deleted when that session fires, and the schedule returns to the default.
5. Debug only: the Settings switch "Allow changing tomorrow without completing today" skips rule 1 (not rule 2).

## Design notes / small additions to the spec
- Habits is a `FeatureModule` with `locksPhoneOnSchedule=false` (no alarm); tabs and alarms are built from `ModuleRegistry`, not hard-wired to two modules.
- `fired-today` guard: after a session fires, no second session fires the same date (otherwise an override earlier than the default would double-fire). Keyed on the trigger's own date, so late delivery after midnight cannot swallow tomorrow.
- `LockActivity` also shows over the keyguard and turns the screen on (`showWhenLocked`, `turnScreenOn`).
- Relaunches (immediate and watchdog) skip while the audio mode is ringtone/in-call (fail-safe for emergency calls).
- Consequence of the 500 ms watchdog without a screen-state check (as specified): while a session is active the watchdog can wake the screen after you press the power button. The immediate relaunch does check `isInteractive`. If that is unwanted, add `PowerManager.isInteractive` to `RelaunchPolicy.watchdog`.
- The "today" time on a module screen shows the time the session really fired at once the override row was deleted (`last_fired_at_<module>` in DataStore).
- "Change tomorrow" is serialised with a mutex and re-checks every rule against the database, so a double tap cannot create two changes.
- Per-task log duration = (unlock time - module start) / number of that module's tasks, so hours aren't double counted.
- A session whose alarm time passed while the phone was off is skipped (no catch-up).
- Debug toggle shows a debug panel and the crash diagnostics in Settings. Bottom-bar icons are emoji (avoids an icons dependency).

## Files
- `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts`, `gradle/libs.versions.toml`, `gradle/wrapper/gradle-wrapper.properties`
- `diag/`: `CrashStore` (pure JVM), `Diagnostics` (handler install, exit reasons, report)
- `data/`: `AppDatabase`, `Entities`, `Daos`, `ActivityLogRepository`, `ScheduleRepository`, `SettingsRepository` (DataStore + persisted session)
- `domain/`: `Task`, `FeatureModule`, `TimeWindow`, `LogSource`, `ModuleRegistry`, `TimeFormat`, `stats/HomeAggregator`, `session/SessionCodec`
- `scheduler/`: `ScheduleDefaults` (all constants), `ScheduleResolver`, `TomorrowChange` (+`CompletionRule`), `AlarmCodes`, `AlarmScheduler`, `AlarmReceiver`, `RescheduleReceiver`
- `lock/`: `SessionManager`, `LockActivity`, `LockScreen`, `LockForegroundService`, `LockLauncher`, `RelaunchPolicy`, `CallGuard`, `DeveloperPassword`
- `modules/`: `ModuleIds`, `PlaceholderTask`, `ScheduledModule`, `LearningModule`, `WalkingModule`, `HabitsModule`
- `ui/`: `AppRoot`, `home/`, `module/`, `settings/`, `common/`
- tests (`app/src/test`): `ScheduleResolverTest`, `TomorrowChangeTest`, `CompletionRuleTest`, `RelaunchPolicyTest`, `CrashStoreTest`, `AlarmCodesTest`, `HomeAggregatorTest`, `SessionCodecTest`, `TimeFormatTest`

## What I could NOT verify (honest list)
- **No Gradle/Android build was run** (sandbox has no access to Google/Maven repositories). I do not claim the project compiles. Nothing was run on a device.
- **This revision was not compiled or run at all**: this sandbox has no Kotlin compiler, no JUnit and no network, so even the pure-logic tests (`ScheduleResolverTest`, `TomorrowChangeTest`, `CompletionRuleTest`, `RelaunchPolicyTest`, `CrashStoreTest`, the updated `HomeAggregatorTest`/`SessionCodecTest`) were only checked by reading. Run `:app:testDebugUnitTest` first. (The previous revision's pure logic had been run with kotlinc and a JUnit shim; that does not cover these changes.)
- Android 16 may refuse `startActivity` from the background even with the overlay permission (background-activity-launch rules were tightened in recent releases). The relaunch from `onUserLeaveHint` happens while the activity is still foreground and is the most likely to succeed; `onStop`/`onDestroy`/watchdog launches depend on the exemptions. Test step 3 on the real device.
- `ActivityManager.getHistoricalProcessExitReasons` output (and whether One UI keeps entries) is untested.
- Highest compile risks: Room 3 API details (no `@ConstructedBy`, `setDriver`/`setQueryCoroutineContext`, `@Upsert`), KSP 2.3.11 + AGP 9.4 built-in Kotlin + `androidx.room3` Gradle plugin together, `compileSdk = 37` DSL form, Material3 `TimePicker` opt-in.
- Runtime behaviour on One UI 8 / Android 16 (background activity launch from the service, FGS start from alarm/boot receivers, exact-alarm default denial) is untested; behaviour follows the documented exemptions (overlay permission, exact alarms).
- Room schema JSON is generated on first build into `app/schemas`; commit it.
