# Focus Lock - Stage 2: Learning module (Udemy study view)

Package `com.example.focuslock` - Samsung Galaxy A16, Android 16. App shell, Room database, schedule, session-aware lock engine, statistics. Walking is still a placeholder task ("Complete test task"); Learning is now real (below).


## Stage 2 - Learning (what is new)

### Session kinds
- `SessionKind { SCHEDULED, OPTIONAL }` (`domain/SessionKind.kt`). `SessionManager.startSession(moduleId, kind, source = LogSource.forKind(kind))` and `FeatureModule.createTasks(kind)`. Each session task persists its kind (`moduleId|taskId|KIND` in the DataStore task string; older data without a kind decodes as SCHEDULED), so both kinds survive process death and reboot.
- Task ids per kind: `learning.main` (scheduled), `learning.optional`. A scheduled trigger during an optional session adds `learning.main` to the active session (existing merge logic); the module source upgrades to `scheduled_session`.
- Log sources: `scheduled_session`, `optional_session`, `test_session` (session rows, all count as Sessions in Home), `study` (hours rows, never a session). Only `scheduled_session` unlocks "Change tomorrow's time". Test rows stay hidden unless debug is on.
- Walking and Habits return no tasks for OPTIONAL.

### Scheduled learning task (`learning.main`)
Requirement: today's credited study time >= required minutes (default 30). The card shows progress, **Start/Continue** (opens the study view) and **Complete** (enabled only when the requirement is met; it re-checks against stored progress, marks only this task done and never ends the lock). **Unlock** appears via the existing "Goals complete" card once ALL tasks are complete. Studying after the requirement is met, or before the scheduled time that day, keeps being recorded. One local notification per day ("Learning requirement complete", channel "Learning"); the per-date flag is stored in Room (`learning_day.requirementNotified`).

### Optional learning task (`learning.optional`)
Learning page > **Start learning session** (disabled with an explanation while any session is active). Starts an OPTIONAL session and opens the study view immediately. Complete needs only that the study view was opened at least once in this session (`OPTIONAL_MIN_CREDIT_SECONDS = 0` in `learning/LearningDefaults.kt`; raise it to require credited seconds). The opened flag and the credit baseline are persisted. Then Complete, then Unlock.

### Data
- Room version 2 with a hand-written `MIGRATION_1_2` (`data/Migrations.kt`): `learning_day(date PK, creditedMs, requirementNotified)` and `learning_lecture(date, lectureKey, creditedMs, maxPositionSec, durationSec, watched; PK date+lectureKey)`. Existing tables are untouched. `exportSchema` stays on.
- DataStore: start URL (default https://www.udemy.com), required minutes (default 30; values under 30 apply only while the global debug toggle is on, minimum 1), min watched share % (default 70, clamped 50-100), last visited URL, optional-session state. Settings tab > "Learning" card edits them.

### Study view (`learning/StudyView.kt`)
One composable for both kinds, hosted inside `LockActivity`'s composition (no extra Activity), so the immediate relaunch and watchdog keep working. Header: **Page back** (WebView history only), **Back to lock**, live "Today: X / Y min, lectures N", and an empty zero-size slot reserved for a future AI assistant icon (nothing built). Allowlist: `udemy.com`, `*.udemy.com`, `udemycdn.com` (`HostAllowlist`); other hosts and `window.open`/`target=_blank` are blocked. JavaScript, DOM storage and cookies on. After a relaunch the view reloads the last visited URL; progress comes from Room. The screen stays on while a video plays.

**Login:** log in manually with email and password. Google (and other social) sign-in is blocked by Google inside WebViews, and those hosts are outside the allowlist anyway.

### Crediting (no double counting)
- URL changes (including single-page navigation) arrive via `doUpdateVisitedHistory`. Lecture id = regex `/lecture/(\d+)` on the URL path; otherwise a fingerprint (FNV-1a of course path + rounded duration + document.title). Crediting never depends on the id.
- Every 250 ms the main `<video>` (including same-origin iframes) is sampled with `evaluateJavascript` (paused, ended, currentTime, duration, playbackRate). `CreditCalculator.credit` credits min(mediaDelta, wallDelta) only when playing, the screen is interactive, the study view is resumed, mediaDelta > 0 and mediaDelta <= wallDelta * max(rate, 1) * 1.3; a single sample is capped at 5 s; everything is in milliseconds.
- Watched = max playhead >= 90% of duration AND credited >= min share % of duration. Udemy's completion checkbox is never read.
- `StudyLedger` is the only accumulator. It persists to Room about every 5 s and writes ONE `study` ActivityLog row per episode (durationSeconds = credited delta, items = newly watched lectures) when the study view closes, on app pause/stop, on date change, and before Unlock. At Unlock, tasks with `reportsOwnActivity = true` produce only a session row with durationSeconds = 0, so Hours come from study rows.
- Debug panel (debug toggle on): URL, lecture id and source, video found, currentTime/duration, credited ms and %, max position, "counts as watched" with the reason, total today, playbackRate, last mediaDelta/wallDelta, last skip reason. `WebView.setWebContentsDebuggingEnabled(true)` in debuggable builds (open `chrome://inspect`).

### Stage 2 test checklist (device)
1. Settings > Learning: turn Debug info on, set required minutes to 2 for a quick run; keep the start URL. Log in on the Learning study view with email and password (Google sign-in will not work).
2. Learning tab > "Test session now": the Learning card shows progress and **Start**; Complete is disabled.
3. Start, open a short lecture, play at 1x for 60 s: "Today" rises by about 1 min (debug: credited ms ~ real time).
4. Seek to the end: credit does not jump ("jump" appears as the last skip reason); the lecture is not "watched".
5. Change speed to 1.5x: credit still follows real time, not media time.
6. Reach the requirement: ONE notification "Learning requirement complete" (not a second one when you keep studying or reopen the app that day); the card says the requirement is met and **Complete** enables.
7. Keep studying a few more minutes: the time keeps counting. Press Complete: only the task is marked done; the lock stays; "Goals complete / Unlock" appears. Unlock.
8. Home: Learning shows study hours (rows with source "study") and one more session; Hours are not doubled by the session row.
9. Learning page > **Start learning session** (disabled while a session is active): the lock appears and the study view opens directly. Complete is disabled until the study view was opened (it is, immediately), then Complete, then Unlock. Home counts it as a Session.
10. Press Home during a session (also inside the study view): the lock comes back; progress is kept; "Continue" reloads the last URL.
11. Midnight: study at ~23:58 and continue after 00:00 (or change the date): Today resets to 0 and a new day record starts.
12. Debug off: the debug panel disappears, and the effective required minutes return to at least 30.

## Stage 2 - files changed
- New `domain/SessionKind.kt`; `domain/LogSource.kt` (new sources, `forKind`, `merge`, `isSessionRow`); `domain/Task.kt` (`reportsOwnActivity`, `onStarted/onRestored`, `FullScreenContent`, `LocalOpenFullScreen`); `domain/FeatureModule.kt` (`createTasks(kind)`); `domain/session/SessionCodec.kt` (task kind), new `domain/session/UnlockDurations.kt`; `domain/stats/HomeAggregator.kt` (sessions = session rows only; study hours count).
- `lock/SessionManager.kt` (kinds, hooks, unlock rule, restore per kind); `lock/LockScreen.kt` (task card hosts `Content()`, full-screen host calls `FullScreenContent`, saveable open state).
- `data/Entities.kt`, `Daos.kt`, `AppDatabase.kt` (v2), new `Migrations.kt`, `SettingsRepository.kt` (learning keys).
- New package `learning/`: `LearningDefaults`, `LectureKeys`, `CreditMath`, `LearningRules`, `HostAllowlist`, `StudyLedger`, `StudyTracker`, `RoomStudyStore`, `StudyNotifier`, `LearningHub`, `StudyView`, `LearningMainTask`, `LearningOptionalTask`, `LearningPageCard`.
- `modules/LearningModule.kt`, `ScheduledModule.kt` (`Extras()` slot), `WalkingModule.kt`, `HabitsModule.kt`, `PlaceholderTask.kt`; `ui/module/ModuleScreen.kt`, `ModuleViewModel.kt`; `ui/settings/SettingsScreen.kt` + new `LearningSettingsCard.kt`; `scheduler/AlarmReceiver.kt`; `AppContainer.kt`, `FocusLockApp.kt`; `AndroidManifest.xml` (INTERNET); `libs.versions.toml` + `app/build.gradle.kts` (coroutines-core for tests).
- Tests added: `LectureKeysTest`, `CreditCalculatorTest` (+ parser, watched rule), `StudyLedgerTest`, `StudyTrackerTest`, `LearningRulesTest`, `HostAllowlistTest`, `LogSourceTest`, `UnlockDurationsTest`; extended `SessionCodecTest`, `HomeAggregatorTest`.

## What I could NOT verify (Stage 2, honest list)
- **Nothing was compiled or run.** This sandbox has no Kotlin compiler, Gradle, Android SDK or network. Not even the JVM tests were executed; I traced the test expectations by hand. Run `:app:testDebugUnitTest` first and expect to fix a few compile errors.
- Highest compile risks: the Room 3 migration API (confirmed by a CI build: `Migration.migrate` is a `suspend fun`; the rest of `Migrations.kt` was not yet confirmed); `LocalLifecycleOwner` import path; the `@Composable protected open fun Extras()` override.
- The migration DDL is hand-written and must match the generated schema; if Room reports a schema mismatch, compare with `app/schemas/.../2.json` after the first build.
- Udemy specifics are untested: whether the main video is a plain `<video>` reachable from the top document or a same-origin iframe, whether login works in the WebView, and the lecture URL format beyond the one you verified. Cross-origin iframes cannot be sampled.
- `udemycdn.com` is allowlisted literally (no `*.udemycdn.com`). Main-frame and iframe navigations to CDN subdomains would be blocked; subresource loading is not affected by this check. Widen `HostAllowlist` if a page breaks.
- WebView lifecycle on Android 16/One UI (render-process death, `onPause` timing while the lock relaunches), cookie persistence across process death, and whether the keep-screen-on flag behaves with the lock activity are untested.
- If `LockActivity` is destroyed (not just stopped) the open study view is not restored automatically; you land on the task list and "Continue" reloads the last URL. Progress is never lost either way.
- The study row is flushed on pause/stop/close/Unlock; a hard process kill can lose up to ~5 s of credit and the unflushed episode row (the day totals in Room are kept, but the `study` ActivityLog row for that episode would be missing, so Home hours could under-count it).
- No `SessionManager` integration test exists (it needs Android-bound `SettingsRepository`); kind persistence is covered at codec level only.

## Toolchain (as pinned in `gradle/libs.versions.toml`)
| Item | Value | Status |
|---|---|---|
| AGP | 9.4.0 (built-in Kotlin, no `kotlin.android` plugin) | 9.4.0 confirmed on developer.android.com |
| Gradle wrapper | 9.6.0 (AGP 9.4's minimum) | confirmed as AGP's minimum |
| JDK | 17 | AGP requirement |
| Kotlin / Compose compiler plugin | 2.4.0 | 2.4.0 confirmed released June 2026 |
| KSP | 2.3.11 | 2.3.9 confirmed to exist; 2.3.11 is the minimum you specified, **not verified** |
| Compose BOM | 2026.09.00 | confirmed in Android docs |
| activity-compose | 1.13.0 | confirmed in Android docs |
| Room | **3.0.3** (`androidx.room3`, KSP only) | confirmed latest stable (9 Sep 2026) |
| sqlite-bundled | 2.7.1 | version taken from the Room KMP doc, may be newer |
| lifecycle 2.10.0, datastore 1.2.0, core-ktx 1.17.0, coroutines 1.10.2 | | **not verified as latest**; they exist but newer ones may too |

compileSdk 37, targetSdk 36, minSdk 26. No Hilt; manual DI via `AppContainer`.

**Room 3 note:** "latest stable Room" is now Room 3, a breaking rewrite (new package `androidx.room3`, a SQLiteDriver is required, coroutine-only DAOs). I used it as asked (`BundledSQLiteDriver`). If KSP complains that `@ConstructedBy` is required on `AppDatabase`, follow the Room KMP doc ("Define database classes"). If you prefer zero risk, swap to Room 2.8.x: only the `data/` package and 3 catalog lines change.

## Build
1. Open the `FocusLock` folder in Android Studio (latest stable, JDK 17 as Gradle JDK). The wrapper properties pin Gradle 9.6.0; the IDE downloads it.
2. Command line (no `gradlew` is included on purpose): run `gradle wrapper --gradle-version 9.6.0` once with any local Gradle, then `./gradlew :app:testDebugUnitTest :app:assembleDebug`.
3. Install on the phone (USB debugging on): `./gradlew :app:installDebug`.

## First-run permission setup (Settings tab)
1. **Exact alarms** -> Allow (Android 14+ denies it by default). Without it the app falls back to inexact alarms.
2. **Display over other apps** -> Allow (required for the watchdog to relaunch the lock screen).
3. **Notifications** -> Allow.
4. **Battery optimization** -> Allow, then do the Samsung steps in the card (Never sleeping apps, Unrestricted).

## Test checklist
Turn the **debug toggle on** (Settings) first: it shows the crash diagnostics and the test-only switches.
1. Learning tab -> "Test session now": lock screen appears showing "0 / 1 completed" (Learning's card now has Start/Complete, see the Stage 2 checklist; Walking keeps the placeholder button).
2. Walking tab -> "Test session now": same, "0 / 1".
3. **Press Home repeatedly and fast** (20+ times; also the Home gesture and Recents): the lock screen comes straight back each time (immediate relaunch from `onUserLeaveHint`/`onStop`, the watchdog is only the backup at 500 ms). Back does nothing. Check Settings > Crash diagnostics afterwards: no crash recorded.
4. Emergency: tap "Emergency Call": the dialer opens; the lock stays away ~3 minutes, then returns. Calls are never blocked (no relaunch while ringing/in a call).
5. **Press Complete, then try to leave without Unlock**: the counter turns "1 / 1" and "Goals complete" + Unlock appear. Press Home, Recents, Back: the lock screen keeps returning. Nothing is logged yet (Home shows no new totals). Only Unlock (or the developer exit, which logs nothing) releases it.
6. Unlock logs: tap Unlock; with debug **on** Home shows today's Hours/Sessions for that module (test session). Turn debug **off**: the test-session totals disappear from Home (empty state on a fresh install). Month selector works; chips re-sort cards. Steps chip lists only Walking; Hours and Sessions list Learning and Walking.
7. Merge: start Learning test session, then (without unlocking) start Walking: counter becomes "x / 2".
8. **Test session does not enable the change**: after a Learning test session + Unlock, open the Learning tab: today's state is still "pending" and "Change tomorrow's time" is disabled with "Finish today's session first."
9. **Schedule in 2 minutes** (an override can no longer be set for today): temporarily edit `ScheduleDefaults.kt`: set `LEARNING_MINUTES` to the current time + 2 min and widen `LEARNING_WINDOW_START/END` so the default lies inside, then `installDebug`. The lock screen starts by itself at that minute (try with the screen off too). Complete the task and tap Unlock: the Learning tab shows "State: completed". Restore the constants afterwards.
10. **Change tomorrow's time, before and after completing**: before completing (step 9 before the alarm) the button is disabled with "Finish today's session first." After completing it is enabled.
11. **A time outside the window**: Learning, pick 6:00 AM or 12:30 PM -> the dialog stays open with "Pick a time between 7:00 AM and 12:00 PM." (Walking: outside 5:00 PM to 11:00 PM). 7:00 AM, 12:00 PM, 5:00 PM and 11:00 PM are accepted. Pick e.g. 9:30 AM: the dialog closes, the Tomorrow card shows "Tomorrow, 9:30 AM" and "Changed time".
12. **A second change attempt**: the button is now disabled with "Already changed for tomorrow." There is no undo and no "Use default" button.
13. Debug bypass: in Settings enable "Allow changing tomorrow without completing today": the button works without completing today (still only once per day). Turn debug off: the bypass stops working.
14. Override then default return: after step 12, move the phone date forward one day (Settings > Date and time; TIME_SET re-registers the alarm) or wait a day. The session fires at 9:30 AM; after it fires the Tomorrow card shows the default 7:00 AM again.
15. Reboot while locked: start a test session, reboot, unlock the phone: the lock screen returns with the same completed state.
16. Settings: revoke a permission in system settings, return: its card refreshes to "not granted".
17. Crash diagnostics (debug on): the card lists up to 5 stack traces and the last 10 process exits (reason, description, time, importance). "Copy all" puts everything on the clipboard; paste it into a note to check.

## Escape plan
`adb uninstall com.example.focuslock` (or the in-app Developer exit, password in `lock/DeveloperPassword.kt`: `Stage1Exit`). Keep USB debugging enabled and the PC authorised before testing.

## Changes in this revision
- **Lock enforcement:** `LockActivity` relaunches itself immediately from `onUserLeaveHint`/`onStop`/`onDestroy` (rules in `lock/RelaunchPolicy.kt`: session active, `now >= emergencyUntil`, overlay granted, not finishing because of Unlock, not a configuration change, screen interactive, no call). The watchdog runs every 500 ms and no longer checks task completion: the lock returns until Unlock/developer exit. Every relaunch call and every watchdog iteration is wrapped so it cannot throw.
- **Crash diagnostics:** `FocusLockApp` installs an uncaught-exception handler (`diag/`) that keeps the last 5 traces in `filesDir/crashes`. Settings (debug on only) shows them plus the last 10 `getHistoricalProcessExitReasons` entries, with "Copy all".
- **Change tomorrow's time** replaces "Change for today" (see rules below). Logs now carry `source = scheduled_session` or `test_session` (a session remembers the source per module; a scheduled trigger upgrades a test-started module, never the reverse). The Room schema did not change (`source` already existed), so no migration is needed.
- **Home:** `FeatureModule.recordsSteps` (Walking = true); the Steps metric lists only such modules. Test sessions count in Home only when debug is on.

### Tomorrow's-time rules
1. Allowed only when today's scheduled session of that module was completed with Unlock (a `scheduled_session` log whose session started today). Test sessions never count.
2. Only once: if an override already exists for tomorrow the button is disabled (no undo).
3. The time must lie inside the module's window (`ScheduleDefaults`: Learning 7:00 AM-12:00 PM, Walking 5:00 PM-11:00 PM, both ends inclusive; defaults lie inside).
4. The override is stored for tomorrow's date, used when the trigger falls on that date, deleted when that session fires, and the schedule returns to the default.
5. Debug only: the Settings switch "Allow changing tomorrow without completing today" skips rule 1 (not rule 2).

## Design notes / small additions to the spec
- Habits is a `FeatureModule` with `locksPhoneOnSchedule=false` (no alarm); tabs and alarms are built from `ModuleRegistry`, not hard-wired to two modules.
- `fired-today` guard: after a session fires, no second session fires the same date (otherwise an override earlier than the default would double-fire). Keyed on the trigger's own date, so late delivery after midnight cannot swallow tomorrow.
- `LockActivity` also shows over the keyguard and turns the screen on (`showWhenLocked`, `turnScreenOn`).
- Relaunches (immediate and watchdog) skip while the audio mode is ringtone/in-call (fail-safe for emergency calls).
- Consequence of the 500 ms watchdog without a screen-state check (as specified): while a session is active the watchdog can wake the screen after you press the power button. The immediate relaunch does check `isInteractive`. If that is unwanted, add `PowerManager.isInteractive` to `RelaunchPolicy.watchdog`.
- The "today" time on a module screen shows the time the session really fired at once the override row was deleted (`last_fired_at_<module>` in DataStore).
- "Change tomorrow" is serialised with a mutex and re-checks every rule against the database, so a double tap cannot create two changes.
- Per-task log duration = (unlock time - module start) / number of that module's tasks, so hours aren't double counted.
- A session whose alarm time passed while the phone was off is skipped (no catch-up).
- Debug toggle shows a debug panel and the crash diagnostics in Settings. Bottom-bar icons are emoji (avoids an icons dependency).

## Files
- `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts`, `gradle/libs.versions.toml`, `gradle/wrapper/gradle-wrapper.properties`
- `diag/`: `CrashStore` (pure JVM), `Diagnostics` (handler install, exit reasons, report)
- `data/`: `AppDatabase`, `Entities`, `Daos`, `ActivityLogRepository`, `ScheduleRepository`, `SettingsRepository` (DataStore + persisted session)
- `domain/`: `Task`, `FeatureModule`, `TimeWindow`, `LogSource`, `ModuleRegistry`, `TimeFormat`, `stats/HomeAggregator`, `session/SessionCodec`
- `scheduler/`: `ScheduleDefaults` (all constants), `ScheduleResolver`, `TomorrowChange` (+`CompletionRule`), `AlarmCodes`, `AlarmScheduler`, `AlarmReceiver`, `RescheduleReceiver`
- `lock/`: `SessionManager`, `LockActivity`, `LockScreen`, `LockForegroundService`, `LockLauncher`, `RelaunchPolicy`, `CallGuard`, `DeveloperPassword`
- `modules/`: `ModuleIds`, `PlaceholderTask`, `ScheduledModule`, `LearningModule`, `WalkingModule`, `HabitsModule`
- `ui/`: `AppRoot`, `home/`, `module/`, `settings/`, `common/`
- tests (`app/src/test`): `ScheduleResolverTest`, `TomorrowChangeTest`, `CompletionRuleTest`, `RelaunchPolicyTest`, `CrashStoreTest`, `AlarmCodesTest`, `HomeAggregatorTest`, `SessionCodecTest`, `TimeFormatTest`

## What I could NOT verify (honest list)
- **No Gradle/Android build was run** (sandbox has no access to Google/Maven repositories). I do not claim the project compiles. Nothing was run on a device.
- **This revision was not compiled or run at all**: this sandbox has no Kotlin compiler, no JUnit and no network, so even the pure-logic tests (`ScheduleResolverTest`, `TomorrowChangeTest`, `CompletionRuleTest`, `RelaunchPolicyTest`, `CrashStoreTest`, the updated `HomeAggregatorTest`/`SessionCodecTest`) were only checked by reading. Run `:app:testDebugUnitTest` first. (The previous revision's pure logic had been run with kotlinc and a JUnit shim; that does not cover these changes.)
- Android 16 may refuse `startActivity` from the background even with the overlay permission (background-activity-launch rules were tightened in recent releases). The relaunch from `onUserLeaveHint` happens while the activity is still foreground and is the most likely to succeed; `onStop`/`onDestroy`/watchdog launches depend on the exemptions. Test step 3 on the real device.
- `ActivityManager.getHistoricalProcessExitReasons` output (and whether One UI keeps entries) is untested.
- Highest compile risks: Room 3 API details (no `@ConstructedBy`, `setDriver`/`setQueryCoroutineContext`, `@Upsert`), KSP 2.3.11 + AGP 9.4 built-in Kotlin + `androidx.room3` Gradle plugin together, `compileSdk = 37` DSL form, Material3 `TimePicker` opt-in.
- Runtime behaviour on One UI 8 / Android 16 (background activity launch from the service, FGS start from alarm/boot receivers, exact-alarm default denial) is untested; behaviour follows the documented exemptions (overlay permission, exact alarms).
- Room schema JSON is generated on first build into `app/schemas`; commit it.
