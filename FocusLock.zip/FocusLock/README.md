# Focus Lock - Stage 1 foundation

Package `com.example.focuslock` - Samsung Galaxy A16, Android 16. App shell, Room database, schedule, session-aware lock engine, statistics. Learning/Walking tasks are placeholders (a "Complete test task" button).

## Toolchain (as pinned in `gradle/libs.versions.toml`)
| Item | Value | Status |
|---|---|---|
| AGP | 9.4.0 (built-in Kotlin, no `kotlin.android` plugin) | 9.4.0 confirmed on developer.android.com |
| Gradle wrapper | 9.6.0 (AGP 9.4's minimum) | confirmed as AGP's minimum |
| JDK | 17 | AGP requirement |
| Kotlin / Compose compiler plugin | 2.4.0 | 2.4.0 confirmed released June 2026 |
| KSP | 2.3.11 | 2.3.9 confirmed to exist; 2.3.11 is the minimum you specified, **not verified** |
| Compose BOM | 2026.09.00 | confirmed in Android docs |
| activity-compose | 1.13.0 | confirmed in Android docs |
| Room | **3.0.3** (`androidx.room3`, KSP only) | confirmed latest stable (9 Sep 2026) |
| sqlite-bundled | 2.7.1 | version taken from the Room KMP doc, may be newer |
| lifecycle 2.10.0, datastore 1.2.0, core-ktx 1.17.0, coroutines 1.10.2 | | **not verified as latest**; they exist but newer ones may too |

compileSdk 37, targetSdk 36, minSdk 26. No Hilt; manual DI via `AppContainer`.

**Room 3 note:** "latest stable Room" is now Room 3, a breaking rewrite (new package `androidx.room3`, a SQLiteDriver is required, coroutine-only DAOs). I used it as asked (`BundledSQLiteDriver`). If KSP complains that `@ConstructedBy` is required on `AppDatabase`, follow the Room KMP doc ("Define database classes"). If you prefer zero risk, swap to Room 2.8.x: only the `data/` package and 3 catalog lines change.

## Build
1. Open the `FocusLock` folder in Android Studio (latest stable, JDK 17 as Gradle JDK). The wrapper properties pin Gradle 9.6.0; the IDE downloads it.
2. Command line (no `gradlew` is included on purpose): run `gradle wrapper --gradle-version 9.6.0` once with any local Gradle, then `./gradlew :app:testDebugUnitTest :app:assembleDebug`.
3. Install on the phone (USB debugging on): `./gradlew :app:installDebug`.

## First-run permission setup (Settings tab)
1. **Exact alarms** -> Allow (Android 14+ denies it by default). Without it the app falls back to inexact alarms.
2. **Display over other apps** -> Allow (required for the watchdog to relaunch the lock screen).
3. **Notifications** -> Allow.
4. **Battery optimization** -> Allow, then do the Samsung steps in the card (Never sleeping apps, Unrestricted).

## Test checklist
1. Learning tab -> "Test session now": lock screen appears showing "0 / 1 completed".
2. Walking tab -> "Test session now": same, "0 / 1".
3. Home-relaunch: during a lock, press Home. Within ~2 s the lock screen returns. Back button does nothing.
4. Emergency: tap "Emergency Call": dialer opens; lock screen stays away ~3 minutes, then returns. Calls are never blocked (also no relaunch while ringing/in call).
5. Complete the test task: counter turns "1 / 1", "Goals complete" + Unlock appear; no auto-release. Tap Unlock.
6. Unlock logs: Home tab shows today's Hours/Sessions for that module; month selector (Prev/Next) works; chips re-sort cards; empty state shows on a fresh install.
7. Merge: start Learning test session, then (without unlocking) start Walking: counter becomes "x / 2".
8. Override then default return: Learning -> "Change for today" -> pick a time 2-3 min ahead -> screen shows the override. When it fires and you Unlock, the screen shows "Tomorrow, 7:00 AM" (default). A time in the past is rejected.
9. Schedule in 2 minutes: set today's override ~2 min ahead for Walking; lock screen starts by itself at that minute (screen off too).
10. Reboot while locked: start a test session, reboot, unlock the phone: the lock screen returns with the same completed state (if you completed the task it still shows complete).
11. Settings: revoke a permission in system settings, return: its card refreshes to "not granted".

## Escape plan
`adb uninstall com.example.focuslock` (or the in-app Developer exit, password in `lock/DeveloperPassword.kt`: `Stage1Exit`). Keep USB debugging enabled and the PC authorised before testing.

## Design notes / small additions to the spec
- Habits is a `FeatureModule` with `locksPhoneOnSchedule=false` (no alarm); tabs and alarms are built from `ModuleRegistry`, not hard-wired to two modules.
- `fired-today` guard: after a session fires, no second session fires the same date (otherwise an override earlier than the default would double-fire). Keyed on the trigger's own date, so late delivery after midnight cannot swallow tomorrow.
- `LockActivity` also shows over the keyguard and turns the screen on (`showWhenLocked`, `turnScreenOn`).
- Watchdog skips relaunch while the audio mode is ringtone/in-call (fail-safe for emergency calls).
- Per-task log duration = (unlock time - module start) / number of that module's tasks, so hours aren't double counted.
- A session whose alarm time passed while the phone was off is skipped (no catch-up).
- Debug toggle shows a debug panel in Settings. Bottom-bar icons are emoji (avoids an icons dependency).

## Files
- `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts`, `gradle/libs.versions.toml`, `gradle/wrapper/gradle-wrapper.properties`
- `data/`: `AppDatabase`, `Entities`, `Daos`, `ActivityLogRepository`, `ScheduleRepository`, `SettingsRepository` (DataStore + persisted session)
- `domain/`: `Task`, `FeatureModule`, `ModuleRegistry`, `TimeFormat`, `stats/HomeAggregator`, `session/SessionCodec`
- `scheduler/`: `ScheduleDefaults` (all constants), `ScheduleResolver`, `AlarmCodes`, `AlarmScheduler`, `AlarmReceiver`, `RescheduleReceiver`
- `lock/`: `SessionManager`, `LockActivity`, `LockScreen`, `LockForegroundService`, `LockLauncher`, `DeveloperPassword`
- `modules/`: `ModuleIds`, `PlaceholderTask`, `ScheduledModule`, `LearningModule`, `WalkingModule`, `HabitsModule`
- `ui/`: `AppRoot`, `home/`, `module/`, `settings/`, `common/`
- tests (`app/src/test`): `ScheduleResolverTest`, `AlarmCodesTest`, `HomeAggregatorTest`, `SessionCodecTest`, `TimeFormatTest`

## What I could NOT verify (honest list)
- **No Gradle/Android build was run** (sandbox has no access to Google/Maven repositories). I do not claim the project compiles. Nothing was run on a device.
- What I did run: the pure-Kotlin logic (`ScheduleResolver`, `HomeAggregator`, `SessionCodec`, `TimeFormat`, `AlarmCodes`) compiled with kotlinc 2.4.0 and all 27 unit tests passed, using a small JUnit shim instead of real JUnit 4. The Android/Compose/Room code was only reviewed by reading.
- Highest compile risks: Room 3 API details (no `@ConstructedBy`, `setDriver`/`setQueryCoroutineContext`, `@Upsert`), KSP 2.3.11 + AGP 9.4 built-in Kotlin + `androidx.room3` Gradle plugin together, `compileSdk = 37` DSL form, Material3 `TimePicker` opt-in.
- Runtime behaviour on One UI 8 / Android 16 (background activity launch from the service, FGS start from alarm/boot receivers, exact-alarm default denial) is untested; behaviour follows the documented exemptions (overlay permission, exact alarms).
- Room schema JSON is generated on first build into `app/schemas`; commit it.
