# Focus Lock - Stage 1 foundation

Package `com.example.focuslock` - Samsung Galaxy A16, Android 16. App shell, Room database, schedule, session-aware lock engine, statistics. Learning/Walking tasks are placeholders (a "Complete test task" button).

## Toolchain (as pinned in `gradle/libs.versions.toml`)
| Item | Value | Status |
|---|---|---|
| AGP | 9.4.0 (built-in Kotlin, no `kotlin.android` plugin) | 9.4.0 confirmed on developer.android.com |
| Gradle wrapper | 9.6.0 (AGP 9.4's minimum) | confirmed as AGP's minimum |
| JDK | 17 | AGP requirement |
| Kotlin / Compose compiler plugin | 2.4.0 | 2.4.0 confirmed released June 2026 |
| KSP | 2.3.11 | 2.3.9 confirmed to exist; 2.3.11 is the minimum you specified, **not verified** |
| Compose BOM | 2026.09.00 | confirmed in Android docs |
| activity-compose | 1.13.0 | confirmed in Android docs |
| Room | **3.0.3** (`androidx.room3`, KSP only) | confirmed latest stable (9 Sep 2026) |
| sqlite-bundled | 2.7.1 | version taken from the Room KMP doc, may be newer |
| lifecycle 2.10.0, datastore 1.2.0, core-ktx 1.17.0, coroutines 1.10.2 | | **not verified as latest**; they exist but newer ones may too |

compileSdk 37, targetSdk 36, minSdk 26. No Hilt; manual DI via `AppContainer`.

**Room 3 note:** "latest stable Room" is now Room 3, a breaking rewrite (new package `androidx.room3`, a SQLiteDriver is required, coroutine-only DAOs). I used it as asked (`BundledSQLiteDriver`). If KSP complains that `@ConstructedBy` is required on `AppDatabase`, follow the Room KMP doc ("Define database classes"). If you prefer zero risk, swap to Room 2.8.x: only the `data/` package and 3 catalog lines change.

## Build
1. Open the `FocusLock` folder in Android Studio (latest stable, JDK 17 as Gradle JDK). The wrapper properties pin Gradle 9.6.0; the IDE downloads it.
2. Command line (no `gradlew` is included on purpose): run `gradle wrapper --gradle-version 9.6.0` once with any local Gradle, then `./gradlew :app:testDebugUnitTest :app:assembleDebug`.
3. Install on the phone (USB debugging on): `./gradlew :app:installDebug`.

## First-run permission setup (Settings tab)
1. **Exact alarms** -> Allow (Android 14+ denies it by default). Without it the app falls back to inexact alarms.
2. **Display over other apps** -> Allow (required for the watchdog to relaunch the lock screen).
3. **Notifications** -> Allow.
4. **Battery optimization** -> Allow, then do the Samsung steps in the card (Never sleeping apps, Unrestricted).

## Test checklist
1. Learning tab -> "Test session now": lock screen appears showing "0 / 1 completed".
2. Walking tab -> "Test session now": same, "0 / 1"; unlock it and verify the Home record is visible only while Debug info is enabled.
3. Home-relaunch: during a lock, press Home repeatedly and fast. The lock screen should return immediately when the screen is interactive and overlay permission is granted.
4. Complete a task, press Complete, then try to leave without Unlock. The lock must remain active; Complete never releases it.
5. Emergency: tap "Emergency Call": the dialer opens; no relaunch occurs during the emergency window or while ringing/in a call.
6. Finish a scheduled session and tap Unlock. On that module, "Today's session" becomes completed and "Change tomorrow's time" becomes enabled.
7. Try "Change tomorrow's time" before today's scheduled session is completed: it must be disabled with "Finish today's session first".
8. Pick a time outside the module's allowed window: the picker must reject it with a clear window error.
9. Change tomorrow once, then try a second change: the button must stay disabled with "Already changed for tomorrow" and there must be no "Use default"/undo action.
10. Let the changed tomorrow alarm fire. The override is deleted after that trigger and the following schedule returns to the default.
11. Start a test session and Unlock it without completing today's scheduled session. It must not enable tomorrow's change.
12. Debug Settings -> enable "Allow changing tomorrow without completing today" and verify the testing-only bypass works; turn Debug off and verify the bypass is unavailable.
13. Home: Hours and Sessions show all modules; Steps shows only modules whose FeatureModule has `recordsSteps = true`; sorting remains descending.
14. Settings -> Debug info: verify the crash diagnostics panel shows up to 5 stored traces and up to 10 historical process-exit entries, and "Copy all" copies both sections.
15. Midnight rollover: verify an override dated tomorrow becomes today's effective schedule after midnight.
16. DST test cases: run the JVM tests covering a spring-forward gap and fall-back overlap.
17. Reboot/process death while locked: restore the session and verify completion state remains; the foreground watchdog restarts.
18. Press Home repeatedly and fast, revoke permissions in system settings, return, and verify the permission cards refresh.

## Automated tests
The JVM suite now covers tomorrow-override resolution, allowed-window validation, the once-only rule, midnight rollover, DST gap/overlap, completion gating, and exclusion of test-session logs from Home unless Debug is enabled.

## Escape plan
`adb uninstall com.example.focuslock` (or the in-app Developer exit, password in `lock/DeveloperPassword.kt`: `Stage1Exit`). Keep USB debugging enabled and the PC authorised before testing.

## Design notes / small additions to the spec
- Habits is a `FeatureModule` with `locksPhoneOnSchedule=false` (no alarm); tabs and alarms are built from `ModuleRegistry`, not hard-wired to two modules.
- One-day overrides are keyed by their trigger date. After the alarm fires, AlarmReceiver deletes that date's override and the scheduler resolves the next date independently, including after midnight rollover.
- `LockActivity` also shows over the keyguard and turns the screen on (`showWhenLocked`, `turnScreenOn`).
- Watchdog skips relaunch while the audio mode is ringtone/in-call (fail-safe for emergency calls).
- Per-task log duration = (unlock time - module start) / number of that module's tasks, so hours aren't double counted.
- A session whose alarm time passed while the phone was off is skipped (no catch-up).
- Debug toggle shows diagnostics plus a testing-only tomorrow-change bypass. Bottom-bar icons are emoji (avoids an icons dependency).

## Files
- `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts`, `gradle/libs.versions.toml`, `gradle/wrapper/gradle-wrapper.properties`
- `data/`: `AppDatabase`, `Entities`, `Daos`, `ActivityLogRepository`, `ScheduleRepository`, `SettingsRepository` (DataStore + persisted session)
- `domain/`: `Task`, `FeatureModule`, `ModuleRegistry`, `TimeFormat`, `stats/HomeAggregator`, `session/SessionCodec`
- `scheduler/`: `ScheduleDefaults` (all constants), `ScheduleResolver`, `AlarmCodes`, `AlarmScheduler`, `AlarmReceiver`, `RescheduleReceiver`
- `lock/`: `SessionManager`, `LockActivity`, `LockScreen`, `LockForegroundService`, `LockLauncher`, `DeveloperPassword`
- `modules/`: `ModuleIds`, `PlaceholderTask`, `ScheduledModule`, `LearningModule`, `WalkingModule`, `HabitsModule`
- `ui/`: `AppRoot`, `home/`, `module/`, `settings/`, `common/`
- tests (`app/src/test`): `ScheduleResolverTest`, `AlarmCodesTest`, `HomeAggregatorTest`, `SessionCodecTest`, `TimeFormatTest`

## What I could NOT verify (honest list)
- **No Gradle/Android build was run:** this environment does not provide a Gradle executable or a populated Android/Maven dependency cache, so I cannot honestly claim `assembleDebug` or the Android/Compose/Room compiler passed.
- **No device/emulator run was performed.** In particular, Android 16 / One UI background-activity restrictions, overlay behaviour, foreground-service starts, exact alarms, screen-off behaviour, calls, reboot/process-death restoration, and the new immediate lifecycle relaunch path were not exercised on hardware.
- **The JVM tests were inspected/updated but not executed with the project's real Gradle/JUnit toolchain** because the required build tooling/dependencies are unavailable here.
- I did perform source-level consistency checks and kept the deliverable free of `gradlew` and any `gradle-wrapper.jar`; those are packaging checks, not a substitute for an Android build.
