package com.example.focuslock.scheduler

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

class ScheduleResolverTest {
    private val utc = ZoneOffset.UTC
    private val default7am = 7 * 60

    private fun at(h: Int, m: Int, s: Int = 0, day: Int = 2, zone: ZoneId = utc) =
        ZonedDateTime.of(2026, 10, day, h, m, s, 0, zone)

    @Test fun defaultTimeWhenNoOverride() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, null)
        assertEquals(at(7, 0), r.trigger); assertTrue(r.isToday); assertFalse(r.isOverride)
    }

    @Test fun tomorrowOverrideWinsAfterTodayPasses() {
        val r = ScheduleResolver.resolve(at(13, 0), default7am, null, 8 * 60 + 30)
        assertEquals(at(8, 30, day = 3), r.trigger); assertFalse(r.isToday); assertTrue(r.isOverride)
    }

    @Test fun tomorrowOverrideIsUsedAfterTodayWasFired() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, null, 8 * 60, firedToday = true)
        assertEquals(at(8, 0, day = 3), r.trigger); assertTrue(r.isOverride)
    }

    @Test fun todayOverrideStillResolvesByTriggerDate() {
        val r = ScheduleResolver.resolve(at(6, 0), default7am, 8 * 60 + 30, 9 * 60)
        assertEquals(at(8, 30), r.trigger); assertTrue(r.isOverride)
    }

    @Test fun pastTodayOverrideFallsBackToDefaultToday() {
        val r = ScheduleResolver.resolve(at(8, 0), 9 * 60, 7 * 60 + 30, 10 * 60)
        assertEquals(at(9, 0), r.trigger); assertTrue(r.isToday); assertFalse(r.isOverride)
    }

    @Test fun pastDefaultUsesTomorrowOverride() {
        val r = ScheduleResolver.resolve(at(23, 59), 23 * 60 + 30, null, 8 * 60)
        assertEquals(at(8, 0, day = 3), r.trigger)
    }

    @Test fun exactlyNowRollsToTomorrow() {
        val r = ScheduleResolver.resolve(at(7, 0), default7am, null)
        assertEquals(at(7, 0, day = 3), r.trigger)
    }

    @Test fun midnightRollover() {
        val r = ScheduleResolver.resolve(at(23, 59, 30), 0, null, 23 * 60)
        assertEquals(LocalDate.of(2026, 10, 3), r.trigger.toLocalDate())
        assertEquals(23, r.trigger.hour)
    }

    @Test fun dstGapMovesForward() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 3, 8, 1, 0, 0, 0, ny)
        val t = ScheduleResolver.nextTrigger(now, 2 * 60 + 30, null)
        assertEquals(3, t.hour); assertEquals(30, t.minute)
    }

    @Test fun dstOverlapPicksEarlierOffset() {
        val ny = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 11, 1, 0, 0, 0, 0, ny)
        val t = ScheduleResolver.nextTrigger(now, 90, null)
        assertEquals(ZoneOffset.ofHours(-4), t.offset)
    }

    @Test fun completionGateAndOnceOnlyRule() {
        assertFalse(ScheduleResolver.canChangeTomorrow(false, false, false))
        assertTrue(ScheduleResolver.canChangeTomorrow(true, false, false))
        assertFalse(ScheduleResolver.canChangeTomorrow(true, true, false))
        assertTrue(ScheduleResolver.canChangeTomorrow(false, false, true))
    }

    @Test fun windowValidationIsInclusiveAndRejectsOutside() {
        assertNull(ScheduleResolver.validateTomorrowTime(7 * 60, 7 * 60, 12 * 60))
        assertNull(ScheduleResolver.validateTomorrowTime(12 * 60, 7 * 60, 12 * 60))
        assertTrue(ScheduleResolver.validateTomorrowTime(6 * 60 + 59, 7 * 60, 12 * 60)!!.contains("7:00 AM"))
        assertTrue(ScheduleResolver.validateTomorrowTime(12 * 60 + 1, 7 * 60, 12 * 60)!!.contains("12:00 PM"))
    }
}
