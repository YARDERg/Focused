package com.example.focuslock.data

import androidx.room3.Dao
import androidx.room3.Insert
import androidx.room3.Query
import androidx.room3.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Insert
    suspend fun insertAll(logs: List<ActivityLogEntity>)

    @Query("SELECT * FROM activity_log WHERE date >= :from AND date <= :to ORDER BY startedAt DESC")
    fun observeBetween(from: String, to: String): Flow<List<ActivityLogEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM activity_log WHERE moduleId = :moduleId AND date = :date AND source = :source)")
    suspend fun hasSourceForDate(moduleId: String, date: String, source: String): Boolean
}

@Dao
interface ScheduleOverrideDao {
    @Upsert
    suspend fun upsert(override: ScheduleOverrideEntity)

    @Query("SELECT * FROM schedule_override WHERE moduleId = :moduleId AND date = :date")
    suspend fun get(moduleId: String, date: String): ScheduleOverrideEntity?

    @Query("SELECT * FROM schedule_override WHERE moduleId = :moduleId")
    fun observeForModule(moduleId: String): Flow<List<ScheduleOverrideEntity>>

    @Query("DELETE FROM schedule_override WHERE moduleId = :moduleId AND date = :date")
    suspend fun deleteFor(moduleId: String, date: String)

    @Query("DELETE FROM schedule_override WHERE date < :before")
    suspend fun deleteOlderThan(before: String)
}
