package com.example.focuslock.modules

import com.example.focuslock.AppContainer
import com.example.focuslock.domain.Task
import com.example.focuslock.scheduler.ScheduleDefaults

class LearningModule(container: AppContainer) : ScheduledModule(
    container = container,
    id = ModuleIds.LEARNING,
    title = "Learning",
    defaultScheduleMinutes = ScheduleDefaults.LEARNING_MINUTES,
    iconEmoji = "📚",
    allowedWindowStartMinutes = ScheduleDefaults.LEARNING_WINDOW_START_MINUTES,
    allowedWindowEndMinutes = ScheduleDefaults.LEARNING_WINDOW_END_MINUTES,
) {
    // Placeholder: the Udemy WebView task replaces this in a later stage.
    override fun createTasks(): List<Task> =
        listOf(PlaceholderTask("learning.test_task", "Learning: complete test task"))
}
