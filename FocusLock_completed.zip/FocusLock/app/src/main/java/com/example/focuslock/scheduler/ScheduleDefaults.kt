package com.example.focuslock.scheduler

/** All schedule/lock constants. Minutes are minutes after local midnight. */
object ScheduleDefaults {
    const val LEARNING_WINDOW_START_MINUTES: Int = 7 * 60
    const val LEARNING_WINDOW_END_MINUTES: Int = 12 * 60
    const val LEARNING_MINUTES: Int = 7 * 60

    const val WALKING_WINDOW_START_MINUTES: Int = 17 * 60
    const val WALKING_WINDOW_END_MINUTES: Int = 23 * 60
    const val WALKING_MINUTES: Int = 21 * 60

    const val EMERGENCY_WINDOW_MS: Long = 3 * 60 * 1000L
    const val WATCHDOG_INTERVAL_MS: Long = 500L
}
