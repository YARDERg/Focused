package com.example.focuslock.ui.module

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.focuslock.AppContainer
import com.example.focuslock.domain.FeatureModule
import com.example.focuslock.domain.TimeFormat
import com.example.focuslock.ui.common.SimpleFactory
import com.example.focuslock.ui.common.TimePickerDialog

@Composable
fun ModuleScreen(module: FeatureModule, container: AppContainer) {
    val appContext = LocalContext.current.applicationContext
    val vm: ModuleViewModel = viewModel(
        key = "module_${module.id}",
        factory = SimpleFactory {
            ModuleViewModel(
                appContext = appContext,
                module = module,
                settings = container.settings,
                schedules = container.schedules,
                logs = container.activityLogs,
                scheduler = container.scheduler,
                sessions = container.sessions,
            )
        },
    )
    val ui by vm.state.collectAsState()
    val sessionActive by vm.sessionActive.collectAsState()

    var showPicker by remember { mutableStateOf(false) }
    var pickerError by remember { mutableStateOf<String?>(null) }
    var testMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(module.title, style = MaterialTheme.typography.headlineMedium)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Today's session", style = MaterialTheme.typography.titleMedium)
                Text(TimeFormat.format12h(ui.todayMinutes), style = MaterialTheme.typography.headlineSmall)
                Text(
                    if (ui.todayCompleted) "State: completed" else "State: pending",
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (!ui.enabled) {
                    Text("Scheduling is off for this module.", color = MaterialTheme.colorScheme.error)
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Tomorrow's session", style = MaterialTheme.typography.titleMedium)
                Text(TimeFormat.format12h(ui.tomorrowMinutes), style = MaterialTheme.typography.headlineSmall)
                Text(
                    if (ui.tomorrowChanged) "Changed for tomorrow" else "Default time",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        Text(
            "Allowed window: ${TimeFormat.format12h(ui.allowedWindowStartMinutes)} – ${TimeFormat.format12h(ui.allowedWindowEndMinutes)}",
            style = MaterialTheme.typography.bodyMedium,
        )

        Button(
            onClick = { pickerError = null; showPicker = true },
            enabled = ui.canChangeTomorrow,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Change tomorrow's time") }

        ui.changeDisabledReason?.let {
            Text(it, style = MaterialTheme.typography.bodySmall)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Enabled", style = MaterialTheme.typography.titleMedium)
            Switch(checked = ui.enabled, onCheckedChange = vm::setEnabled)
        }

        OutlinedButton(
            onClick = {
                testMessage = null
                vm.testSession { started ->
                    testMessage = if (started) null else "Nothing to start: this module has no enabled tasks."
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Test session now") }
        testMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (sessionActive) {
            Text("A lock session is active. Open the lock screen from Home.", style = MaterialTheme.typography.bodySmall)
        }
    }

    if (showPicker) {
        TimePickerDialog(
            title = "Change tomorrow's time",
            initialMinutes = ui.tomorrowMinutes,
            errorText = pickerError,
            onConfirm = { minutes ->
                vm.setTomorrowOverride(minutes) { error ->
                    if (error == null) {
                        showPicker = false
                        pickerError = null
                    } else {
                        pickerError = error
                    }
                }
            },
            onDismiss = { showPicker = false; pickerError = null },
        )
    }
}
