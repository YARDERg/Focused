package com.example.focuslock.lock

import android.content.Context
import android.content.Intent

/** Best-effort launch wrapper: relaunch attempts must never crash the process. */
object LockLauncher {
    fun launch(context: Context) {
        val intent = Intent(context, LockActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        )
        try {
            context.startActivity(intent)
        } catch (_: Throwable) {
            // Background activity starts can be refused; the watchdog/lifecycle callbacks retry.
        }
    }
}
