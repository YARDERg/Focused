package com.example.focuslock

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CrashDiagnostics {
    private const val PREFIX = "crash_trace_"
    private const val MAX_TRACES = 5

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                store(app, thread, throwable)
            } catch (_: Throwable) {
                // Diagnostics must never interfere with process death.
            }
            try {
                previous?.uncaughtException(thread, throwable)
            } catch (_: Throwable) {
                // Never replace the crash with a diagnostics failure.
            }
        }
    }

    private fun store(context: Context, thread: Thread, throwable: Throwable) {
        val dir = context.filesDir
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        File(dir, "${PREFIX}${stamp}_${thread.id}.txt").writeText(
            "Thread: ${thread.name} (${thread.id})\n" +
                "${throwable.stackTraceToString()}",
        )
        dir.listFiles { file -> file.name.startsWith(PREFIX) && file.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.drop(MAX_TRACES)
            ?.forEach { runCatching { it.delete() } }
    }

    fun readCrashTraces(context: Context): List<String> =
        context.filesDir.listFiles { file -> file.name.startsWith(PREFIX) && file.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.take(MAX_TRACES)
            ?.map { file -> "${file.name}\n${runCatching { file.readText() }.getOrDefault("<unreadable>")}" }
            .orEmpty()

    fun historicalProcessExitReasons(context: Context): List<String> {
        if (Build.VERSION.SDK_INT < 30) return listOf("Historical process-exit reasons require Android 11 (API 30)+.")
        return runCatching {
            val manager = context.getSystemService(ActivityManager::class.java)
            manager.getHistoricalProcessExitReasons(context.packageName, 0, 10).map { info ->
                "reason=${info.reason}, description=${info.description ?: ""}, " +
                    "timestamp=${info.timestamp}, importance=${info.importance}"
            }
        }.getOrElse { listOf("Could not read historical process-exit reasons: ${it.message}") }
    }

    fun copyText(context: Context): String = buildString {
        appendLine("Focus Lock crash traces")
        val traces = readCrashTraces(context)
        if (traces.isEmpty()) appendLine("<none>") else traces.forEach { appendLine(it) }
        appendLine()
        appendLine("Historical process-exit reasons")
        historicalProcessExitReasons(context).forEach { appendLine(it) }
    }
}
