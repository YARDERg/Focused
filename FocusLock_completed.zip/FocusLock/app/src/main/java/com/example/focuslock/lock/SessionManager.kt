package com.example.focuslock.lock

import com.example.focuslock.data.ActivityLogEntity
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.domain.ModuleRegistry
import com.example.focuslock.domain.Task
import com.example.focuslock.domain.session.PersistedSession
import com.example.focuslock.domain.session.PersistedTask
import com.example.focuslock.scheduler.ScheduleDefaults
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import java.time.ZoneId

data class SessionTask(val moduleId: String, val task: Task)

const val SOURCE_SCHEDULED_SESSION = "scheduled_session"
const val SOURCE_TEST_SESSION = "test_session"

/** A live lock session: the union of the tasks of every module that triggered while it was active. */
class ActiveSession(
    val moduleStarts: Map<String, Long>,
    val entries: List<SessionTask>,
    val moduleSources: Map<String, String>,
) {
    val moduleIds: List<String> get() = moduleStarts.keys.toList()
}

data class Progress(val done: Int, val total: Int) {
    val isComplete: Boolean get() = total > 0 && done == total
}

/**
 * Owns the active lock session. State is persisted so it survives process death and reboot.
 * All mutations go through [mutex] and wait for [ready] (the restore step) first.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class SessionManager(
    private val settings: SettingsRepository,
    private val registry: ModuleRegistry,
    private val logs: ActivityLogRepository,
    private val scope: CoroutineScope,
    private val now: () -> Long = { System.currentTimeMillis() },
) {
    private val mutex = Mutex()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _session = MutableStateFlow<ActiveSession?>(null)
    val session: StateFlow<ActiveSession?> = _session.asStateFlow()

    private val _emergencyUntil = MutableStateFlow(0L)
    val emergencyUntil: StateFlow<Long> = _emergencyUntil.asStateFlow()

    val progress: StateFlow<Progress> = _session
        .flatMapLatest { s ->
            if (s == null || s.entries.isEmpty()) {
                flowOf(Progress(0, 0))
            } else {
                combine(s.entries.map { it.task.completed }) { flags ->
                    Progress(flags.count { it }, flags.size)
                }
            }
        }
        .stateIn(scope, SharingStarted.Eagerly, Progress(0, 0))

    private val completedIds: Flow<Set<String>> = _session.flatMapLatest { s ->
        if (s == null || s.entries.isEmpty()) {
            flowOf(emptySet<String>())
        } else {
            combine(s.entries.map { e -> e.task.completed.map { done -> e.task.id to done } }) { pairs ->
                pairs.filter { it.second }.map { it.first }.toSet()
            }
        }
    }

    suspend fun awaitReady() {
        _ready.first { it }
    }

    /** Starts a session for [moduleId], or merges its tasks into the active one. Returns false if there is nothing to do. */
    suspend fun startSession(moduleId: String, source: String = SOURCE_SCHEDULED_SESSION): Boolean {
        awaitReady()
        return mutex.withLock {
            val module = registry.byId(moduleId) ?: return@withLock false
            val fresh = module.createTasks().filter { it.isEnabled() }
            val current = _session.value
            val updated: ActiveSession
            if (current == null) {
                if (fresh.isEmpty()) return@withLock false
                fresh.forEach { it.reset() }
                _emergencyUntil.value = 0L
                settings.setEmergencyUntil(0L)
                updated = ActiveSession(
                    moduleStarts = mapOf(moduleId to now()),
                    entries = fresh.map { SessionTask(moduleId, it) },
                    moduleSources = mapOf(moduleId to source),
                )
            } else {
                val existing = current.entries.map { it.task.id }.toSet()
                val added = fresh.filter { it.id !in existing }
                added.forEach { it.reset() }
                updated = ActiveSession(
                    moduleStarts = current.moduleStarts + (moduleId to (current.moduleStarts[moduleId] ?: now())),
                    entries = current.entries + added.map { SessionTask(moduleId, it) },
                    moduleSources = current.moduleSources + (moduleId to (current.moduleSources[moduleId] ?: source)),
                )
            }
            _session.value = updated
            settings.saveSession(toPersisted(updated))
            true
        }
    }

    /** Unlock after "Goals complete": writes one ActivityLog per completed task, then ends the session. */
    suspend fun unlock(): Boolean {
        awaitReady()
        return mutex.withLock {
            val s = _session.value ?: return@withLock true
            if (s.entries.any { !it.task.completed.value }) return@withLock false
            val end = now()
            val date = Instant.ofEpochMilli(end).atZone(ZoneId.systemDefault()).toLocalDate().toString()
            val rows = s.entries
                .groupBy { it.moduleId }
                .flatMap { (moduleId, entries) ->
                    val start = s.moduleStarts[moduleId] ?: end
                    val perTask = (((end - start) / 1000L) / entries.size).coerceAtLeast(0L)
                    entries.map {
                        ActivityLogEntity(
                            moduleId = moduleId,
                            date = date,
                            startedAt = start,
                            endedAt = end,
                            durationSeconds = perTask,
                            steps = null,
                            items = null,
                            source = s.moduleSources[moduleId] ?: SOURCE_SCHEDULED_SESSION,
                        )
                    }
                }
            logs.insertAll(rows)
            clear()
            true
        }
    }

    /** Developer exit: ends the session without writing any log. */
    suspend fun forceEnd() {
        awaitReady()
        mutex.withLock { clear() }
    }

    /** Emergency Call: the watchdog stays quiet for [ScheduleDefaults.EMERGENCY_WINDOW_MS]. Not suspending on purpose. */
    fun startEmergency() {
        val until = now() + ScheduleDefaults.EMERGENCY_WINDOW_MS
        _emergencyUntil.value = until
        scope.launch { settings.setEmergencyUntil(until) }
    }

    private suspend fun clear() {
        _session.value = null
        _emergencyUntil.value = 0L
        settings.clearSession()
    }

    private fun toPersisted(s: ActiveSession): PersistedSession = PersistedSession(
        moduleStarts = s.moduleStarts,
        tasks = s.entries.map { PersistedTask(it.moduleId, it.task.id) },
        completed = s.entries.filter { it.task.completed.value }.map { it.task.id }.toSet(),
        moduleSources = s.moduleSources,
    )

    private suspend fun restore() {
        try {
            _emergencyUntil.value = settings.loadEmergencyUntil()
            val p = settings.loadSession() ?: return
            val entries = ArrayList<SessionTask>()
            for ((moduleId, _) in p.moduleStarts) {
                val module = registry.byId(moduleId) ?: continue
                val wanted = p.tasks.filter { it.moduleId == moduleId }.map { it.taskId }.toSet()
                for (task in module.createTasks()) {
                    if (task.id in wanted) {
                        task.restore(task.id in p.completed)
                        entries.add(SessionTask(moduleId, task))
                    }
                }
            }
            if (entries.isEmpty()) {
                settings.clearSession()
                return
            }
            val starts = p.moduleStarts.filterKeys { k -> entries.any { it.moduleId == k } }
            val sources = p.moduleSources.filterKeys { k -> entries.any { it.moduleId == k } }
                .mapValues { it.value.ifBlank { SOURCE_SCHEDULED_SESSION } }
            _session.value = ActiveSession(starts, entries, sources)
        } finally {
            _ready.value = true
        }
    }

    init {
        scope.launch { restore() }
        scope.launch {
            _ready.first { it }
            completedIds.distinctUntilChanged().collect { ids ->
                if (_session.value != null) settings.saveCompleted(ids)
            }
        }
    }
}
