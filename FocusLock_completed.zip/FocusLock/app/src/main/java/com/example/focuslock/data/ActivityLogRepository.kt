package com.example.focuslock.data

import com.example.focuslock.domain.stats.LogEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

class ActivityLogRepository(private val dao: ActivityLogDao) {

    suspend fun insertAll(entities: List<ActivityLogEntity>) {
        if (entities.isNotEmpty()) dao.insertAll(entities)
    }

    suspend fun hasSourceForDate(moduleId: String, date: LocalDate, source: String): Boolean =
        dao.hasSourceForDate(moduleId, date.toString(), source)

    fun observeBetween(from: LocalDate, to: LocalDate): Flow<List<LogEntry>> =
        dao.observeBetween(from.toString(), to.toString()).map { rows ->
            rows.map {
                LogEntry(
                    moduleId = it.moduleId,
                    date = LocalDate.parse(it.date),
                    startedAt = it.startedAt,
                    durationSeconds = it.durationSeconds,
                    steps = it.steps,
                    source = it.source,
                )
            }
        }
}
