package com.example.focuslock.scheduler

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Result of resolving the next session instant for a module. */
data class ResolvedSchedule(
    val trigger: ZonedDateTime,
    val isToday: Boolean,
    val isOverride: Boolean,
)

/** Pure schedule logic; deliberately independent of Android so it can be JVM-tested. */
object ScheduleResolver {

    fun triggerAt(date: LocalDate, minutesOfDay: Int, zone: ZoneId): ZonedDateTime {
        val m = minutesOfDay.coerceIn(0, 24 * 60 - 1)
        return ZonedDateTime.of(date, LocalTime.of(m / 60, m % 60), zone)
    }

    /**
     * Resolves today's one-day override first, then today's default. If today's session has
     * already fired, or today's time has passed, resolves tomorrow using tomorrow's override
     * when present, otherwise the default.
     */
    fun resolve(
        now: ZonedDateTime,
        defaultMinutes: Int,
        todayOverrideMinutes: Int?,
        tomorrowOverrideMinutes: Int? = null,
        firedToday: Boolean = false,
    ): ResolvedSchedule {
        val zone = now.zone
        val today = now.toLocalDate()
        if (!firedToday) {
            todayOverrideMinutes?.let {
                val trigger = triggerAt(today, it, zone)
                if (trigger.isAfter(now)) return ResolvedSchedule(trigger, true, true)
            }
            val defaultTrigger = triggerAt(today, defaultMinutes, zone)
            if (defaultTrigger.isAfter(now)) return ResolvedSchedule(defaultTrigger, true, false)
        }
        val tomorrow = today.plusDays(1)
        val tomorrowMinutes = tomorrowOverrideMinutes ?: defaultMinutes
        return ResolvedSchedule(
            triggerAt(tomorrow, tomorrowMinutes, zone),
            isToday = false,
            isOverride = tomorrowOverrideMinutes != null,
        )
    }

    fun nextTrigger(
        now: ZonedDateTime,
        defaultMinutes: Int,
        todayOverrideMinutes: Int?,
        tomorrowOverrideMinutes: Int? = null,
        firedToday: Boolean = false,
    ): ZonedDateTime = resolve(
        now, defaultMinutes, todayOverrideMinutes, tomorrowOverrideMinutes, firedToday
    ).trigger

    fun isWithinWindow(minutesOfDay: Int, startMinutes: Int, endMinutes: Int): Boolean =
        minutesOfDay in startMinutes..endMinutes

    /** The only policy gate for the tomorrow-change action. */
    fun canChangeTomorrow(
        todayCompletedWithUnlock: Boolean,
        tomorrowOverrideExists: Boolean,
        allowWithoutCompletion: Boolean,
    ): Boolean = !tomorrowOverrideExists && (todayCompletedWithUnlock || allowWithoutCompletion)

    fun validateTomorrowTime(
        minutesOfDay: Int,
        startMinutes: Int,
        endMinutes: Int,
    ): String? = if (isWithinWindow(minutesOfDay, startMinutes, endMinutes)) {
        null
    } else {
        "Pick a time between ${formatWindow(startMinutes)} and ${formatWindow(endMinutes)}."
    }

    private fun formatWindow(minutes: Int): String {
        val hour24 = minutes / 60
        val minute = minutes % 60
        val suffix = if (hour24 < 12) "AM" else "PM"
        val hour12 = when (val h = hour24 % 12) { 0 -> 12; else -> h }
        return if (minute == 0) "$hour12:00 $suffix" else "$hour12:${minute.toString().padStart(2, '0')} $suffix"
    }
}
