package com.example.focuslock.domain

import androidx.compose.runtime.Composable

/** A pluggable feature (Learning, Walking, Habits, ...). */
interface FeatureModule {
    val id: String
    val title: String
    val defaultScheduleMinutes: Int
    val locksPhoneOnSchedule: Boolean
    val allowedWindowStartMinutes: Int get() = 0
    val allowedWindowEndMinutes: Int get() = 24 * 60 - 1
    val recordsSteps: Boolean get() = false

    val iconEmoji: String get() = "•"

    fun createTasks(): List<Task>

    @Composable
    fun Screen()
}
