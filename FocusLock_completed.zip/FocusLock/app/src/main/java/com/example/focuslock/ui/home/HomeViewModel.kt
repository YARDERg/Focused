package com.example.focuslock.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.domain.stats.HomeAggregator
import com.example.focuslock.domain.stats.HomeStats
import com.example.focuslock.domain.stats.Metric
import com.example.focuslock.lock.SessionManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.Clock
import java.time.LocalDate
import java.time.YearMonth

data class HomeUiState(
    val month: YearMonth,
    val metric: Metric,
    val today: LocalDate,
    val stats: HomeStats,
    val canGoNext: Boolean,
)

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(
    private val logs: ActivityLogRepository,
    private val allModuleIds: List<String>,
    private val stepModuleIds: List<String>,
    private val settings: SettingsRepository,
    sessions: SessionManager,
    private val clock: Clock = Clock.systemDefaultZone(),
) : ViewModel() {

    private val month = MutableStateFlow(YearMonth.now(clock))
    private val metric = MutableStateFlow(Metric.HOURS)

    private val today: Flow<LocalDate> = flow {
        while (true) {
            emit(LocalDate.now(clock))
            delay(30_000)
        }
    }.distinctUntilChanged()

    val state: StateFlow<HomeUiState> = combine(month, metric, today, settings.debugEnabled) { m, mt, td, debug ->
        Quad(m, mt, td, debug)
    }.flatMapLatest { input ->
        val monthStart = input.month.atDay(1)
        val monthEnd = input.month.atEndOfMonth()
        val from = if (monthStart.isBefore(input.today)) monthStart else input.today
        val to = if (monthEnd.isAfter(input.today)) monthEnd else input.today
        logs.observeBetween(from, to).map { entries ->
            val ids = if (input.metric == Metric.STEPS) stepModuleIds else allModuleIds
            HomeUiState(
                month = input.month,
                metric = input.metric,
                today = input.today,
                stats = HomeAggregator.aggregate(
                    entries = entries,
                    moduleIds = ids,
                    today = input.today,
                    month = input.month,
                    metric = input.metric,
                    includeTestSessions = input.debug,
                ),
                canGoNext = input.month.isBefore(YearMonth.from(input.today)),
            )
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        HomeUiState(
            month = month.value,
            metric = metric.value,
            today = LocalDate.now(clock),
            stats = HomeAggregator.aggregate(
                emptyList(), allModuleIds, LocalDate.now(clock), month.value, metric.value,
            ),
            canGoNext = false,
        ),
    )

    val sessionActive: StateFlow<Boolean> = sessions.session
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun previousMonth() { month.value = month.value.minusMonths(1) }

    fun nextMonth() {
        val next = month.value.plusMonths(1)
        if (!next.isAfter(YearMonth.now(clock))) month.value = next
    }

    fun setMetric(value: Metric) { metric.value = value }

    private data class Quad(val month: YearMonth, val metric: Metric, val today: LocalDate, val debug: Boolean)
}
