package com.example.focuslock.lock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.focuslock.FocusLockApp
import com.example.focuslock.scheduler.ScheduleDefaults
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground service (type specialUse) with a 500 ms watchdog. While a session is active, the
 * emergency window has passed and overlay permission is granted, it
 * relaunches [LockActivity]. It stays quiet during an incoming/active call (fail-safe).
 */
class LockForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var watchdog: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (watchdog?.isActive != true) watchdog = scope.launch { runWatchdog() }
        return START_STICKY
    }

    private suspend fun runWatchdog() {
        val container = (application as FocusLockApp).container
        val sessions = container.sessions
        sessions.awaitReady()
        while (scope.isActive) {
            if (sessions.session.value == null) {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }
            val emergencyOver = System.currentTimeMillis() >= sessions.emergencyUntil.value
            val interactive = getSystemService(PowerManager::class.java)?.isInteractive == true
            if (emergencyOver && interactive && Settings.canDrawOverlays(this) &&
                !LockActivity.visible && !callInProgress()
            ) {
                LockLauncher.launch(this)
            }
            delay(ScheduleDefaults.WATCHDOG_INTERVAL_MS)
        }
    }

    /** Never fight the dialer: no relaunch while the phone is ringing or in a call. */
    private fun callInProgress(): Boolean {
        val mode = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode
        return mode == AudioManager.MODE_RINGTONE ||
            mode == AudioManager.MODE_IN_CALL ||
            mode == AudioManager.MODE_IN_COMMUNICATION
    }

    private fun buildNotification(): android.app.Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Focus Lock session", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, LockActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Focus Lock")
            .setContentText("A lock session is in progress")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "focus_lock_session"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, LockForegroundService::class.java))
            } catch (_: Exception) {
                // Not allowed from this background state; callers also try LockLauncher.
            }
        }
    }
}
