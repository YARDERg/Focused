package com.example.focuslock.lock

import android.content.Context
import android.content.Intent
import android.content.ActivityNotFoundException
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.focuslock.FocusLockApp
import com.example.focuslock.ui.common.FocusLockTheme

class LockActivity : ComponentActivity() {
    @Volatile private var finishingForUnlock = false
    private var relaunchAttempted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as FocusLockApp).container

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT < 27) {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* blocked */ }
        })

        setContent {
            FocusLockTheme {
                LockScreen(
                    container = container,
                    onEmergencyCall = ::startEmergencyCall,
                    onFinished = {
                        finishingForUnlock = true
                        finish()
                    },
                )
            }
        }
        hideSystemBars()
    }

    private fun startEmergencyCall() {
        (application as FocusLockApp).container.sessions.startEmergency()
        try {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
            // No dialer available.
        }
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun maybeRelaunchImmediately() {
        if (relaunchAttempted || finishingForUnlock || isChangingConfigurations) return
        val app = application as FocusLockApp
        val sessions = app.container.sessions
        if (!sessions.ready.value || sessions.session.value == null) return
        if (System.currentTimeMillis() < sessions.emergencyUntil.value) return
        if (!Settings.canDrawOverlays(this)) return
        if (!(getSystemService(PowerManager::class.java)?.isInteractive ?: false)) return
        if (callInProgress()) return
        relaunchAttempted = true
        LockLauncher.launch(applicationContext)
    }

    private fun callInProgress(): Boolean {
        val mode = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode
        return mode == AudioManager.MODE_RINGTONE ||
            mode == AudioManager.MODE_IN_CALL ||
            mode == AudioManager.MODE_IN_COMMUNICATION
    }

    override fun onResume() {
        super.onResume()
        visible = true
        relaunchAttempted = false
        hideSystemBars()
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onUserLeaveHint() {
        maybeRelaunchImmediately()
        super.onUserLeaveHint()
    }

    override fun onStop() {
        maybeRelaunchImmediately()
        super.onStop()
    }

    override fun onDestroy() {
        maybeRelaunchImmediately()
        visible = false
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    companion object {
        @Volatile
        var visible: Boolean = false
    }
}
