package com.example.focuslock.ui.settings

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.focuslock.AppContainer
import com.example.focuslock.CrashDiagnostics
import com.example.focuslock.lock.DeveloperPassword
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first

private fun pkgUri(context: Context) = Uri.parse("package:${context.packageName}")

private fun safeStart(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        // Settings screen not available on this device.
    }
}

private fun batteryIgnored(context: Context): Boolean =
    context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)

@Composable
fun SettingsScreen(container: AppContainer) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var exactAlarm by remember { mutableStateOf(container.scheduler.canScheduleExact()) }
    var overlay by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var notifications by remember { mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled()) }
    var battery by remember { mutableStateOf(batteryIgnored(context)) }

    // Refresh every time the user comes back from system settings.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        exactAlarm = container.scheduler.canScheduleExact()
        overlay = Settings.canDrawOverlays(context)
        notifications = NotificationManagerCompat.from(context).areNotificationsEnabled()
        battery = batteryIgnored(context)
    }

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notifications = NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    val debug by container.settings.debugEnabled.collectAsState(initial = false)
    val session by container.sessions.session.collectAsState()
    val progress by container.sessions.progress.collectAsState()
    var allowTomorrowWithoutCompletion by remember { mutableStateOf(false) }
    var crashTraces by remember { mutableStateOf<List<String>>(emptyList()) }
    var exitReasons by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(debug) {
        if (debug) {
            val data = withContext(Dispatchers.IO) {
                Triple(
                    container.settings.allowTomorrowWithoutCompletion.first(),
                    CrashDiagnostics.readCrashTraces(context),
                    CrashDiagnostics.historicalProcessExitReasons(context),
                )
            }
            allowTomorrowWithoutCompletion = data.first
            crashTraces = data.second
            exitReasons = data.third
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)

        PermissionCard(
            title = "Exact alarms",
            description = "Needed so sessions start at the exact minute. Without it alarms may be late.",
            granted = exactAlarm,
            actionLabel = "Allow",
            onAction = {
                if (Build.VERSION.SDK_INT >= 31) {
                    safeStart(context, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri(context)))
                }
            },
        )
        PermissionCard(
            title = "Display over other apps",
            description = "Needed so the lock screen can come back to the front by itself.",
            granted = overlay,
            actionLabel = "Allow",
            onAction = { safeStart(context, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri(context))) },
        )
        PermissionCard(
            title = "Notifications",
            description = "Shows the ongoing 'lock session' notification of the foreground service.",
            granted = notifications,
            actionLabel = "Allow",
            onAction = {
                if (Build.VERSION.SDK_INT >= 33) {
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    safeStart(
                        context,
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
                    )
                }
            },
            secondaryLabel = "App notification settings",
            onSecondary = {
                safeStart(
                    context,
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
                )
            },
        )
        PermissionCard(
            title = "Battery optimization exception",
            description = "Lets the watchdog keep running while the screen is off.",
            granted = battery,
            actionLabel = "Allow",
            onAction = {
                safeStart(context, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri(context)))
            },
            secondaryLabel = "Battery settings list",
            onSecondary = { safeStart(context, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Samsung background restrictions", style = MaterialTheme.typography.titleMedium)
                Text(
                    "One UI can put apps to sleep and stop their alarms and services. On your Galaxy: " +
                        "Settings > Battery > Background usage limits. Remove Focus Lock from \"Sleeping apps\" " +
                        "and \"Deep sleeping apps\", and add it to \"Never sleeping apps\". Also set the app's " +
                        "Battery setting to Unrestricted (Settings > Apps > Focus Lock > Battery).",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Developer exit", style = MaterialTheme.typography.titleMedium)
                Text(
                    "The lock screen has a \"Developer exit\" button that ends a session without logging it. " +
                        "Password: ${DeveloperPassword.VALUE} (defined in DeveloperPassword.kt, to be removed later).",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Debug info", style = MaterialTheme.typography.titleMedium)
                    Switch(checked = debug, onCheckedChange = { scope.launch { container.settings.setDebug(it) } })
                }
                if (debug) {
                    val s = session
                    Text(
                        if (s == null) "Session: none" else
                            "Session: ${s.moduleIds.joinToString()} - ${progress.done}/${progress.total} tasks done",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text("Exact alarms allowed: $exactAlarm", style = MaterialTheme.typography.bodySmall)
                    Text("Overlay allowed: $overlay", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Modules: ${container.registry.modules.joinToString { it.id }}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Allow changing tomorrow without completing today", style = MaterialTheme.typography.bodySmall)
                        Switch(
                            checked = allowTomorrowWithoutCompletion,
                            onCheckedChange = { value ->
                                allowTomorrowWithoutCompletion = value
                                scope.launch { container.settings.setAllowTomorrowWithoutCompletion(value) }
                            },
                        )
                    }
                    DiagnosticsCard(
                        traces = crashTraces,
                        exitReasons = exitReasons,
                        onRefresh = {
                            scope.launch {
                                val data = withContext(Dispatchers.IO) {
                                    CrashDiagnostics.readCrashTraces(context) to CrashDiagnostics.historicalProcessExitReasons(context)
                                }
                                crashTraces = data.first
                                exitReasons = data.second
                            }
                        },
                        onCopyAll = {
                            scope.launch {
                                val text = withContext(Dispatchers.IO) { CrashDiagnostics.copyText(context) }
                                val clipboard = context.getSystemService(ClipboardManager::class.java)
                                clipboard?.setPrimaryClip(ClipData.newPlainText("Focus Lock diagnostics", text))
                            }
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsCard(
    traces: List<String>,
    exitReasons: List<String>,
    onRefresh: () -> Unit,
    onCopyAll: () -> Unit,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Crash diagnostics", style = MaterialTheme.typography.titleMedium)
            Text("Last 5 stored stack traces", style = MaterialTheme.typography.labelLarge)
            if (traces.isEmpty()) Text("No stored crash traces.", style = MaterialTheme.typography.bodySmall)
            traces.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            Text("Last 10 historical process exits", style = MaterialTheme.typography.labelLarge)
            exitReasons.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onRefresh) { Text("Refresh") }
                Button(onClick = onCopyAll) { Text("Copy all") }
            }
        }
    }
}

@Composable
private fun PermissionCard(
    title: String,
    description: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit,
    secondaryLabel: String? = null,
    onSecondary: () -> Unit = {},
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (granted) "$title: granted" else "$title: not granted",
                style = MaterialTheme.typography.titleMedium,
            )
            Text(description, style = MaterialTheme.typography.bodyMedium)
            if (!granted) {
                Button(onClick = onAction) { Text(actionLabel) }
            }
            if (secondaryLabel != null) {
                TextButton(onClick = onSecondary) { Text(secondaryLabel) }
            }
        }
    }
}
