package com.example.focuslock.ui.module

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focuslock.data.ActivityLogRepository
import com.example.focuslock.data.ScheduleRepository
import com.example.focuslock.data.SettingsRepository
import com.example.focuslock.domain.FeatureModule
import com.example.focuslock.lock.LockForegroundService
import com.example.focuslock.lock.LockLauncher
import com.example.focuslock.lock.SOURCE_TEST_SESSION
import com.example.focuslock.lock.SessionManager
import com.example.focuslock.scheduler.AlarmScheduler
import com.example.focuslock.scheduler.ScheduleResolver
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Clock
import java.time.LocalDate
import java.time.ZonedDateTime

data class ModuleUiState(
    val enabled: Boolean,
    val todayMinutes: Int,
    val todayCompleted: Boolean,
    val tomorrowMinutes: Int,
    val tomorrowChanged: Boolean,
    val allowedWindowStartMinutes: Int,
    val allowedWindowEndMinutes: Int,
    val canChangeTomorrow: Boolean,
    val changeDisabledReason: String?,
    val defaultMinutes: Int,
)

private data class QuadInputs(
    val enabled: Boolean,
    val overrides: List<com.example.focuslock.data.ScheduleOverrideEntity>,
    val debug: Boolean,
    val debugBypass: Boolean,
    val lastFired: String?,
)

class ModuleViewModel(
    private val appContext: Context,
    private val module: FeatureModule,
    private val settings: SettingsRepository,
    private val schedules: ScheduleRepository,
    private val logs: ActivityLogRepository,
    private val scheduler: AlarmScheduler,
    private val sessions: SessionManager,
    private val clock: Clock = Clock.systemDefaultZone(),
) : ViewModel() {

    private val ticker = flow {
        while (true) {
            emit(Unit)
            delay(15_000)
        }
    }

    private val todayDate = ticker.map { LocalDate.now(clock) }.distinctUntilChanged()
    private val todayLogs = todayDate.flatMapLatest { logs.observeBetween(it, it) }

    private val inputs = combine(
        settings.moduleEnabled(module.id),
        schedules.observeOverrides(module.id),
        settings.debugEnabled,
        settings.allowTomorrowWithoutCompletion,
        settings.lastFired(module.id),
    ) { enabled, overrides, debug, debugBypass, lastFired ->
        QuadInputs(enabled, overrides, debug, debugBypass, lastFired)
    }.combine(settings.lastFiredMinutes(module.id)) { input, lastFiredMinutes ->
        Pair(input, lastFiredMinutes)
    }

    val state: StateFlow<ModuleUiState> = combine(inputs, todayLogs, ticker) { pair, logsToday, _ ->
        val input = pair.first
        val now = ZonedDateTime.now(clock)
        val today = now.toLocalDate()
        val tomorrow = today.plusDays(1)
        val todayKey = today.toString()
        val tomorrowKey = tomorrow.toString()
        val todayOverride = input.overrides.firstOrNull { it.date == todayKey }?.minutes
        val tomorrowOverride = input.overrides.firstOrNull { it.date == tomorrowKey }?.minutes
        val todayCompleted = logsToday.any { it.moduleId == module.id && it.source == "scheduled_session" }
        val effectiveDebugBypass = input.debug && input.debugBypass
        val canChange = ScheduleResolver.canChangeTomorrow(
            todayCompletedWithUnlock = todayCompleted,
            tomorrowOverrideExists = tomorrowOverride != null,
            allowWithoutCompletion = effectiveDebugBypass,
        )
        val reason = when {
            canChange -> null
            tomorrowOverride != null -> "Already changed for tomorrow"
            !todayCompleted && !effectiveDebugBypass -> "Finish today's session first"
            else -> null
        }
        val resolved = ScheduleResolver.resolve(
            now = now,
            defaultMinutes = module.defaultScheduleMinutes,
            todayOverrideMinutes = todayOverride,
            tomorrowOverrideMinutes = tomorrowOverride,
            firedToday = input.lastFired == todayKey,
        )
        val todayMinutes = if (input.lastFired == todayKey && pair.second != null) {
            pair.second!!
        } else if (resolved.isToday) {
            resolved.trigger.hour * 60 + resolved.trigger.minute
        } else {
            todayOverride ?: module.defaultScheduleMinutes
        }
        ModuleUiState(
            enabled = input.enabled,
            todayMinutes = todayMinutes,
            todayCompleted = todayCompleted,
            tomorrowMinutes = tomorrowOverride ?: module.defaultScheduleMinutes,
            tomorrowChanged = tomorrowOverride != null,
            allowedWindowStartMinutes = module.allowedWindowStartMinutes,
            allowedWindowEndMinutes = module.allowedWindowEndMinutes,
            canChangeTomorrow = canChange,
            changeDisabledReason = reason,
            defaultMinutes = module.defaultScheduleMinutes,
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        ModuleUiState(
            enabled = true,
            todayMinutes = module.defaultScheduleMinutes,
            todayCompleted = false,
            tomorrowMinutes = module.defaultScheduleMinutes,
            tomorrowChanged = false,
            allowedWindowStartMinutes = module.allowedWindowStartMinutes,
            allowedWindowEndMinutes = module.allowedWindowEndMinutes,
            canChangeTomorrow = false,
            changeDisabledReason = "Finish today's session first",
            defaultMinutes = module.defaultScheduleMinutes,
        ),
    )

    val sessionActive: StateFlow<Boolean> = sessions.session
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun setEnabled(value: Boolean) {
        viewModelScope.launch {
            settings.setModuleEnabled(module.id, value)
            scheduler.schedule(module.id)
        }
    }

    /** Validates and stores the single override for tomorrow. There is intentionally no clear action. */
    fun setTomorrowOverride(minutes: Int, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val now = ZonedDateTime.now(clock)
            val today = now.toLocalDate()
            val tomorrow = today.plusDays(1)
            val existing = schedules.getOverride(module.id, tomorrow)
            val todayCompleted = logs.hasSourceForDate(module.id, today, "scheduled_session")
            // The repository is a Flow; obtain the current value without adding another policy path.
            val debug = settings.debugEnabled.first()
            val allow = settings.allowTomorrowWithoutCompletion.first()
            val effectiveBypass = debug && allow
            val gateError = when {
                existing != null -> "Tomorrow's time has already been changed."
                !ScheduleResolver.canChangeTomorrow(todayCompleted, existing != null, effectiveBypass) ->
                    "Finish today's session first."
                else -> null
            }
            val error = gateError ?: ScheduleResolver.validateTomorrowTime(
                minutes,
                module.allowedWindowStartMinutes,
                module.allowedWindowEndMinutes,
            )
            if (error == null) {
                schedules.setOverride(module.id, tomorrow, minutes)
                scheduler.schedule(module.id)
            }
            onResult(error)
        }
    }

    fun testSession(onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val started = sessions.startSession(module.id, SOURCE_TEST_SESSION)
            if (started) {
                LockForegroundService.start(appContext)
                LockLauncher.launch(appContext)
            }
            onResult(started)
        }
    }
}
