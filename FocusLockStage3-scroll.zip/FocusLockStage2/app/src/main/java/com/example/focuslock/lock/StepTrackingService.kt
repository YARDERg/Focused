package com.example.focuslock.lock

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.example.focuslock.R
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.tasks.WalkingSensorSnapshot
import com.example.focuslock.tasks.WalkingStepTrackerState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.ArrayDeque

class StepTrackingService : Service(), SensorEventListener {
    companion object {
        private const val CHANNEL_ID = "walking_tracking"
        private const val NOTIFICATION_ID = 9003
        private const val SAMPLE_INTERVAL_MS = 1_000L
        private const val CADENCE_WINDOW_MS = 60_000L
        private const val MAX_CADENCE = 220
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var sensorManager: SensorManager
    private var sensor: Sensor? = null
    private var sensorTypeName = "none"
    private var counterBaseline: Float? = null
    private var lastRawCounter: Float? = null
    private val stepTimes = ArrayDeque<Long>() // guarded by stepLock (sensor thread + IO thread)
    private val stepLock = Any()
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        selectAndRegisterSensor()
        WalkingStepTrackerState.update(
            WalkingSensorSnapshot(
                sensorType = sensorTypeName,
                noSensor = sensor == null
            )
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startForeground(NOTIFICATION_ID, buildNotification())
        } catch (_: SecurityException) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!hasActivityRecognitionPermission()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (sensor == null) {
            WalkingStepTrackerState.update(
                WalkingSensorSnapshot(sensorType = "none", noSensor = true)
            )
            stopSelf()
            return START_NOT_STICKY
        }
        acquireWakeLock()
        startCreditLoop()
        return START_STICKY
    }

    private fun selectAndRegisterSensor() {
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        sensorTypeName = when (sensor?.type) {
            Sensor.TYPE_STEP_COUNTER -> "TYPE_STEP_COUNTER"
            Sensor.TYPE_STEP_DETECTOR -> "TYPE_STEP_DETECTOR"
            else -> "none"
        }
        sensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onSensorChanged(event: SensorEvent) {
        val now = SystemClock.elapsedRealtime()
        val eventMs = event.timestamp / 1_000_000L
        // Prefer the sensor's own timestamp; fall back to "now" if it looks off-base.
        val stepTime = if (eventMs in (now - 300_000L)..now) eventMs else now
        if (event.sensor.type == Sensor.TYPE_STEP_COUNTER) {
            val raw = event.values.firstOrNull() ?: return
            val last = lastRawCounter
            if (last == null) {
                counterBaseline = raw
                lastRawCounter = raw
                updateSnapshot(raw = raw)
                return
            }
            if (raw < last) {
                // Reboot/reset: rebase without crediting the discontinuity.
                counterBaseline = raw
                lastRawCounter = raw
                updateSnapshot(raw = raw)
                return
            }
            val delta = (raw - last).toInt().coerceAtLeast(0)
            lastRawCounter = raw
            synchronized(stepLock) { repeat(delta.coerceAtMost(1000)) { stepTimes.addLast(stepTime) } }
            updateSnapshot(raw = raw)
        } else if (event.sensor.type == Sensor.TYPE_STEP_DETECTOR) {
            synchronized(stepLock) { stepTimes.addLast(stepTime) }
            updateSnapshot(raw = null)
        }
        synchronized(stepLock) { trimStepTimes(now) }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private var creditJobStarted = false

    private fun startCreditLoop() {
        if (creditJobStarted) return
        creditJobStarted = true
        scope.launch {
            val dataStore = AppDataStore(applicationContext)
            var lastTick = SystemClock.elapsedRealtime()
            while (isActive) {
                delay(SAMPLE_INTERVAL_MS)
                val settings = dataStore.readWalkingSettings()
                val progress = dataStore.readWalkingProgress()
                if (!settings.enabled || progress.creditedSeconds >= settings.requiredMinutes * 60L) {
                    stopSelf()
                    break
                }
                val now = SystemClock.elapsedRealtime()
                // If the CPU was asleep, credit the whole gap (capped) instead of a single second.
                val gapSeconds = ((now - lastTick) / 1000L).coerceIn(1L, 60L)
                lastTick = now
                val cadence = synchronized(stepLock) {
                    trimStepTimes(now)
                    stepTimes.size
                }
                val walking = cadence >= settings.cadenceThreshold && cadence <= MAX_CADENCE
                updateSnapshot(cadence = cadence, walking = walking)
                if (walking) {
                    val updated = dataStore.creditWalkingSecond(gapSeconds)
                    if (updated.creditedSeconds >= settings.requiredMinutes * 60L) {
                        stopSelf()
                        break
                    }
                }
            }
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "focuslock:walking")
            ?.also { it.acquire(3 * 60 * 60 * 1000L) }
    }

    // Caller must hold stepLock.
    private fun trimStepTimes(now: Long) {
        while (stepTimes.isNotEmpty() && now - stepTimes.first() > CADENCE_WINDOW_MS) {
            stepTimes.removeFirst()
        }
    }

    private fun updateSnapshot(raw: Float? = WalkingStepTrackerState.snapshot.value.rawCounter, cadence: Int = WalkingStepTrackerState.snapshot.value.cadence, walking: Boolean = WalkingStepTrackerState.snapshot.value.isWalking) {
        WalkingStepTrackerState.update(
            WalkingSensorSnapshot(
                sensorType = sensorTypeName,
                rawCounter = raw,
                cadence = cadence,
                isWalking = walking,
                noSensor = sensor == null
            )
        )
    }

    private fun hasActivityRecognitionPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

    private fun buildNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_directions)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Walking activity tracking is active.")
            .setOngoing(true)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Walking tracking",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        scope.cancel()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        if (sensor != null) {
            WalkingStepTrackerState.update(WalkingSensorSnapshot())
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
