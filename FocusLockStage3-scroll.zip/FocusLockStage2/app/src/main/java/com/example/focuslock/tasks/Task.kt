package com.example.focuslock.tasks

import androidx.compose.runtime.Composable

interface Task {
    val id: String
    val title: String
    val hasFullScreenUi: Boolean get() = false

    fun isEnabled(): Boolean
    fun isCompleted(): Boolean
    fun reset()

    @Composable
    fun Content(onChanged: () -> Unit)
}
