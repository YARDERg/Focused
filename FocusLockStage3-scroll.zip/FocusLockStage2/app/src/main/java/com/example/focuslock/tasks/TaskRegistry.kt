package com.example.focuslock.tasks

import android.content.Context
import com.example.focuslock.data.AppDataStore

object TaskRegistry {
    private var initialized = false
    private var registeredTasks: List<Task> = emptyList()

    fun initialize(context: Context) {
        if (initialized) return
        val appContext = context.applicationContext
        val dataStore = AppDataStore(appContext)
        registeredTasks = listOf(
            LearningTask(dataStore),
            WalkingTask(dataStore)
        )
        initialized = true
    }

    val tasks: List<Task>
        get() = registeredTasks

    val enabledTasks: List<Task>
        get() = registeredTasks.filter(Task::isEnabled)

    fun resetAll() {
        registeredTasks.forEach(Task::reset)
    }

    fun allCompleted(): Boolean = enabledTasks.all(Task::isCompleted)
}
