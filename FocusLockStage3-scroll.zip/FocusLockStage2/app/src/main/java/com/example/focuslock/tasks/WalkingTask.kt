package com.example.focuslock.tasks

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.data.WalkingProgress
import com.example.focuslock.data.WalkingSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object WalkingStepTrackerState {
    private val _snapshot = MutableStateFlow(WalkingSensorSnapshot())
    val snapshot = _snapshot.asStateFlow()

    fun update(snapshot: WalkingSensorSnapshot) {
        _snapshot.value = snapshot
    }
}

data class WalkingSensorSnapshot(
    val sensorType: String = "none",
    val rawCounter: Float? = null,
    val cadence: Int = 0,
    val isWalking: Boolean = false,
    val noSensor: Boolean = false
)

class WalkingTask(
    private val dataStore: AppDataStore
) : Task {
    override val id: String = "walking_task"
    override val title: String = "Walking"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(WalkingTaskState())
    val state = _state.asStateFlow()
    private var settings = WalkingSettings(
        enabled = AppDataStore.DEFAULT_TASK_ENABLED,
        requiredMinutes = AppDataStore.DEFAULT_WALKING_REQUIRED_MINUTES,
        cadenceThreshold = AppDataStore.DEFAULT_WALKING_CADENCE_THRESHOLD,
        debugEnabled = false
    )
    private var progress = WalkingProgress("", 0L)
    private var initialized = false

    override fun isEnabled(): Boolean = _state.value.enabled
    override fun isCompleted(): Boolean = _state.value.completed

    override fun reset() {
        scope.launch { loadStateOnce() }
    }

    @Composable
    override fun Content(onChanged: () -> Unit) {
        val state by state.collectAsState()
        val sensor by WalkingStepTrackerState.snapshot.collectAsState()
        val context = LocalContext.current
        var permissionGranted by remember { mutableStateOf(hasPermission(context)) }
        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted -> permissionGranted = granted }

        DisposableEffect(Unit) {
            loadStateAsync()
            onDispose { }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!permissionGranted) {
                Text("Permission needed")
                Button(
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            permissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                        } else {
                            permissionGranted = true
                        }
                    }
                ) { Text("Allow activity recognition") }
            } else if (sensor.noSensor) {
                Text("No step sensor")
            } else {
                Text("Walking: ${state.creditedSeconds / 60} / ${state.requiredMinutes} min today")
                LinearProgressIndicator(
                    progress = { (state.creditedSeconds.toFloat() / (state.requiredMinutes * 60L)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (sensor.isWalking) "Walking" else "Not walking")
                    Text("${sensor.cadence} steps/min")
                }
            }
            if (state.debugEnabled) {
                Text("Sensor: ${sensor.sensorType}")
                Text("Raw counter: ${sensor.rawCounter ?: "none"}")
                Text("Cadence: ${sensor.cadence} steps/min")
                Text("Credited seconds: ${state.creditedSeconds}")
            }
        }
    }

    private fun loadStateAsync() {
        if (initialized) return
        initialized = true
        scope.launch {
            loadStateOnce()
            while (true) {
                delay(1000)
                loadStateOnce()
            }
        }
    }

    private suspend fun loadStateOnce() {
        settings = dataStore.readWalkingSettings()
        progress = dataStore.readWalkingProgress()
        updateState()
    }

    private fun updateState() {
        val sensor = WalkingStepTrackerState.snapshot.value
        val requiredSeconds = settings.requiredMinutes * 60L
        _state.value = WalkingTaskState(
            enabled = settings.enabled,
            requiredMinutes = settings.requiredMinutes,
            cadenceThreshold = settings.cadenceThreshold,
            debugEnabled = settings.debugEnabled,
            creditedSeconds = progress.creditedSeconds,
            completed = progress.creditedSeconds >= requiredSeconds
        )
    }

    private fun hasPermission(context: android.content.Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACTIVITY_RECOGNITION
            ) == PackageManager.PERMISSION_GRANTED

    data class WalkingTaskState(
        val enabled: Boolean = true,
        val requiredMinutes: Int = AppDataStore.DEFAULT_WALKING_REQUIRED_MINUTES,
        val cadenceThreshold: Int = AppDataStore.DEFAULT_WALKING_CADENCE_THRESHOLD,
        val creditedSeconds: Long = 0L,
        val completed: Boolean = false,
        val debugEnabled: Boolean = false
    )
}
