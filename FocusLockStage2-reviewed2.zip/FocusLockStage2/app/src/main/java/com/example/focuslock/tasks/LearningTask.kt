package com.example.focuslock.tasks

import android.content.Context
import android.net.Uri
import android.os.PowerManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.data.LearningProgress
import com.example.focuslock.data.LearningSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.roundToLong

class LearningTask(
    private val dataStore: AppDataStore
) : Task {
    override val id: String = "learning_task"
    override val title: String = "Learning"
    override val hasFullScreenUi: Boolean = true

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(LearningTaskState())
    val state = _state.asStateFlow()

    private var settings: LearningSettings = LearningSettings(
        AppDataStore.DEFAULT_LEARNING_START_URL,
        AppDataStore.DEFAULT_LEARNING_REQUIRED_MINUTES,
        AppDataStore.DEFAULT_LEARNING_REQUIRED_LECTURES,
        false,
        AppDataStore.DEFAULT_LEARNING_MINIMUM_WATCHED_SHARE
    )
    private var progress: LearningProgress = LearningProgress.empty("")
    private var initialized = false

    override fun isCompleted(): Boolean = _state.value.completed

    override fun reset() {
        scope.launch { loadState() }
    }

    @Composable
    override fun Content(onChanged: () -> Unit) {
        val state by state.collectAsState()
        val currentOnChanged by rememberUpdatedState(onChanged)

        DisposableEffect(Unit) {
            loadStateAsync()
            onDispose { }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                when {
                    state.completed -> "Learning goals completed"
                    state.requiredMinutes > 0 -> "Verified: ${state.creditedMillis / 60_000} / ${state.requiredMinutes} min"
                    else -> "Verified: ${state.creditedMillis / 60_000} min"
                }
            )
            if (state.requiredMinutes > 0) {
                LinearProgressIndicator(
                    progress = { (state.creditedMillis.toFloat() / (state.requiredMinutes * 60_000L)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (state.requiredLectures > 0) {
                Text("Lectures: ${state.watchedLectureCount} / ${state.requiredLectures}")
            }
            Button(onClick = {
                state.openRequest?.invoke()
                currentOnChanged()
            }) {
                Text("Open learning")
            }
        }
    }

    fun createWebView(
        context: Context,
        onProgressChanged: () -> Unit
    ): WebView {
        val webView = WebView(context)
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
        }
        webView.webViewClient = LearningWebViewClient(
            isAllowedUrl = ::isAllowedUrl,
            onVisitedUrl = ::onVisitedUrl,
            onProgressChanged = onProgressChanged
        )
        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }

        if (isDebugBuild(context)) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        val startUrl = settings.startUrl.takeIf { isAllowedUrl(it) }
            ?: AppDataStore.DEFAULT_LEARNING_START_URL
        webView.loadUrl(startUrl)
        startTracking(webView, onProgressChanged)
        return webView
    }

    fun disposeWebView(webView: WebView) {
        stopTracking(webView)
        CookieManager.getInstance().flush()
        webView.stopLoading()
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = null
        webView.destroy()
    }

    private var trackingJob: Job? = null
    private var lastLectureKey: String? = null
    private var lastMediaTime: Double? = null
    private var lastWallTime: Double? = null
    private var pendingCreditMillis = 0.0
    private val creditMutex = Mutex()

    private fun startTracking(webView: WebView, onProgressChanged: () -> Unit) {
        stopTracking(webView)
        trackingJob = scope.launch(Dispatchers.Main.immediate) {
            while (true) {
                delay(250)
                sampleVideo(webView, onProgressChanged)
            }
        }
    }

    private fun stopTracking(webView: WebView) {
        trackingJob?.cancel()
        trackingJob = null
        lastLectureKey = null
        lastMediaTime = null
        lastWallTime = null
        pendingCreditMillis = 0.0
    }

    private fun sampleVideo(webView: WebView, onProgressChanged: () -> Unit) {
        if (!_state.value.activityResumed) {
            setSkipReason("not resumed")
            return
        }

        val powerManager = webView.context.getSystemService(PowerManager::class.java)
        if (powerManager?.isInteractive != true) {
            setSkipReason("screen off")
            return
        }

        webView.evaluateJavascript(VIDEO_PROBE_JS) { raw ->
            val sample = parseVideoSample(raw) ?: run {
                _state.value = _state.value.copy(videoFound = false, isPlaying = false)
                return@evaluateJavascript
            }

            val url = _state.value.url
            val explicitLectureId = extractLectureId(url)
            val lectureKey = explicitLectureId?.toString()
                ?: buildFallbackLectureKey(url, sample.duration, sample.documentTitle)
            val lectureIdSource = if (explicitLectureId != null) "URL lecture/<digits>" else "fallback hash"

            if (lectureKey != _state.value.lectureKey) {
                lastLectureKey = null
                lastMediaTime = null
                lastWallTime = null
                pendingCreditMillis = 0.0
            }

            // duration is NaN until metadata loads (Infinity for live); roundToLong() throws on NaN.
            val safeDuration = if (sample.duration.isFinite() && sample.duration > 0.0) sample.duration else 0.0
            val safeCurrentTime = if (sample.currentTime.isFinite()) sample.currentTime else 0.0

            val currentLectureCredit = progress.creditsByLectureMs[lectureKey] ?: 0L
            val currentMaxPosition = progress.maxPositionByLectureMs[lectureKey] ?: 0L
            _state.value = _state.value.copy(
                videoFound = true,
                currentTime = sample.currentTime,
                duration = sample.duration,
                playbackRate = sample.playbackRate,
                isPlaying = !sample.paused && !sample.ended,
                lectureKey = lectureKey,
                lectureId = explicitLectureId,
                lectureIdSource = lectureIdSource,
                currentLectureCreditedMillis = currentLectureCredit,
                currentLectureMaxPositionMillis = currentMaxPosition,
                currentLectureDurationMillis = (safeDuration * 1000.0).roundToLong().coerceAtLeast(1L)
            )
            updateCurrentLectureWatchedState()

            val durationMillis = (safeDuration * 1000.0).roundToLong().coerceAtLeast(1L)
            val maxPositionMillis = (safeCurrentTime * 1000.0)
                .roundToLong()
                .coerceIn(0L, durationMillis)

            if (sample.paused || sample.ended || sample.duration <= 0.0 || !sample.duration.isFinite()) {
                lastLectureKey = lectureKey
                lastMediaTime = sample.currentTime
                lastWallTime = sample.pageTimeMs
                pendingCreditMillis = 0.0
                if (maxPositionMillis > (progress.maxPositionByLectureMs[lectureKey] ?: 0L)) {
                    persistLectureProgress(lectureKey, maxPositionMillis, durationMillis, onProgressChanged)
                }
                setSkipReason("paused")
                return@evaluateJavascript
            }

            if (lastLectureKey != lectureKey || lastMediaTime == null || lastWallTime == null) {
                lastLectureKey = lectureKey
                lastMediaTime = sample.currentTime
                lastWallTime = sample.pageTimeMs
                pendingCreditMillis = 0.0
                return@evaluateJavascript
            }

            val mediaDelta = sample.currentTime - lastMediaTime!!
            val wallDelta = (sample.pageTimeMs - lastWallTime!!) / 1000.0
            lastMediaTime = sample.currentTime
            lastWallTime = sample.pageTimeMs
            _state.value = _state.value.copy(
                lastMediaDelta = mediaDelta,
                lastWallDelta = wallDelta
            )

            val maxAllowedMediaDelta =
                wallDelta * maxOf(sample.playbackRate, 1.0) * 1.3
            if (wallDelta > 0.0 &&
                mediaDelta > 0.0 &&
                mediaDelta <= maxAllowedMediaDelta &&
                mediaDelta.isFinite()
            ) {
                pendingCreditMillis += minOf(mediaDelta, wallDelta) * 1000.0
                val creditMillis = pendingCreditMillis.roundToLong()
                pendingCreditMillis -= creditMillis

                if (creditMillis > 0L || maxPositionMillis > (progress.maxPositionByLectureMs[lectureKey] ?: 0L)) {
                    scope.launch {
                        creditMutex.withLock {
                            val currentCredit = progress.creditsByLectureMs[lectureKey] ?: 0L
                            val newCredit = (currentCredit + creditMillis).coerceAtMost(durationMillis)
                            val newMaxPosition = maxOf(
                                progress.maxPositionByLectureMs[lectureKey] ?: 0L,
                                maxPositionMillis
                            )
                            val updated = dataStore.creditLearningLecture(
                                lectureKey,
                                newCredit,
                                newMaxPosition,
                                durationMillis,
                                settings.minimumWatchedShare
                            )
                            progress = updated
                            updateCompletionState()
                            _state.value = _state.value.copy(
                                currentLectureCreditedMillis = updated.creditsByLectureMs[lectureKey] ?: 0L,
                                currentLectureMaxPositionMillis = updated.maxPositionByLectureMs[lectureKey] ?: 0L,
                                currentLectureDurationMillis = durationMillis
                            )
                            updateCurrentLectureWatchedState()
                            onProgressChanged()
                        }
                    }
                }
            } else {
                setSkipReason(
                    when {
                        wallDelta <= 0.0 -> "clock reset"
                        mediaDelta == 0.0 -> "stalled/buffering"
                        mediaDelta < 0.0 -> "seek back"
                        else -> "seek forward"
                    }
                )
            }
        }
    }

    private fun persistLectureProgress(
        lectureKey: String,
        maxPositionMillis: Long,
        durationMillis: Long,
        onProgressChanged: () -> Unit
    ) {
        scope.launch {
            creditMutex.withLock {
                val currentCredit = progress.creditsByLectureMs[lectureKey] ?: 0L
                val currentMax = progress.maxPositionByLectureMs[lectureKey] ?: 0L
                val updated = dataStore.creditLearningLecture(
                    lectureKey,
                    currentCredit,
                    maxOf(currentMax, maxPositionMillis),
                    durationMillis,
                    settings.minimumWatchedShare
                )
                progress = updated
                updateCompletionState()
                _state.value = _state.value.copy(
                    currentLectureCreditedMillis = updated.creditsByLectureMs[lectureKey] ?: 0L,
                    currentLectureMaxPositionMillis = updated.maxPositionByLectureMs[lectureKey] ?: 0L,
                    currentLectureDurationMillis = durationMillis
                )
                updateCurrentLectureWatchedState()
                onProgressChanged()
            }
        }
    }

    private fun setSkipReason(reason: String) {
        _state.value = _state.value.copy(lastSkipReason = reason)
    }

    fun setActivityResumed(resumed: Boolean) {
        _state.value = _state.value.copy(activityResumed = resumed)
        if (!resumed) {
            lastMediaTime = null
            lastWallTime = null
            pendingCreditMillis = 0.0
            setSkipReason("not resumed")
        }
    }

    fun setOpenRequest(request: (() -> Unit)?) {
        _state.value = _state.value.copy(openRequest = request)
    }

    private fun loadStateAsync() {
        if (initialized) return
        initialized = true
        scope.launch { loadState() }
    }

    private suspend fun loadState() {
        settings = dataStore.readLearningSettings()
        progress = dataStore.readLearningProgress()
        updateCompletionState()
    }

    private fun updateCurrentLectureWatchedState() {
        val key = _state.value.lectureKey
        val duration = _state.value.currentLectureDurationMillis
        if (key == null || duration <= 0L) {
            _state.value = _state.value.copy(
                currentLectureCountsAsWatched = false,
                currentLectureWatchedReason = "no lecture key"
            )
            return
        }
        val maxMet = _state.value.currentLectureMaxPositionMillis * 100L >= duration * 90L
        val creditMet = _state.value.currentLectureCreditedMillis * 100L >= duration * settings.minimumWatchedShare
        val reason = when {
            maxMet && creditMet -> "both thresholds met"
            !maxMet && !creditMet -> "max position < 90% and credited < ${settings.minimumWatchedShare}%"
            !maxMet -> "max position < 90%"
            else -> "credited < ${settings.minimumWatchedShare}%"
        }
        _state.value = _state.value.copy(
            currentLectureCountsAsWatched = maxMet && creditMet,
            currentLectureWatchedReason = reason
        )
    }

    private fun updateCompletionState() {
        val creditedMillis = progress.creditedMillis
        val minutesMet = settings.requiredMinutes <= 0 || creditedMillis >= settings.requiredMinutes * 60_000L
        val lecturesMet = settings.requiredLectures <= 0 || progress.watchedLectureIds.size >= settings.requiredLectures
        val currentKey = _state.value.lectureKey
        _state.value = _state.value.copy(
            requiredMinutes = settings.requiredMinutes,
            requiredLectures = settings.requiredLectures,
            minimumWatchedShare = settings.minimumWatchedShare,
            creditedMillis = creditedMillis,
            watchedLectureCount = progress.watchedLectureIds.size,
            completed = minutesMet && lecturesMet,
            debugEnabled = settings.debugEnabled,
            currentLectureCreditedMillis = currentKey?.let { progress.creditsByLectureMs[it] ?: 0L } ?: 0L,
            currentLectureMaxPositionMillis = currentKey?.let { progress.maxPositionByLectureMs[it] ?: 0L } ?: 0L
        )
        updateCurrentLectureWatchedState()
    }

    fun onVisitedUrl(url: String) {
        val lectureId = extractLectureId(url)
        if (lectureId != null) {
            val nextKey = lectureId.toString()
            if (nextKey != _state.value.lectureKey) {
                lastLectureKey = null
                lastMediaTime = null
                lastWallTime = null
                pendingCreditMillis = 0.0
            }
            _state.value = _state.value.copy(
                url = url,
                lectureId = lectureId,
                lectureKey = nextKey,
                lectureIdSource = "URL lecture/<digits>"
            )
        } else {
            // Keep the current key; sampleVideo() detects a real lecture change itself.
            _state.value = _state.value.copy(url = url, lectureId = null)
        }
    }

    fun isAllowedUrl(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase(Locale.US) ?: return false
        return host == "udemy.com" || host.endsWith(".udemy.com") || host == "udemycdn.com"
    }

    private fun extractLectureId(url: String): Long? {
        val match = Regex("lecture/(\\d+)", RegexOption.IGNORE_CASE).find(url) ?: return null
        return match.groupValues[1].toLongOrNull()
    }

    private fun buildFallbackLectureKey(url: String, duration: Double, documentTitle: String): String {
        val courseSegment = Regex("/course/([^/?#]+)", RegexOption.IGNORE_CASE)
            .find(url)
            ?.groupValues
            ?.getOrNull(1)
            ?.ifBlank { "unknown-course" }
            ?: "unknown-course"
        val roundedDuration = Math.round(duration.coerceAtLeast(0.0))
        val input = "$courseSegment|$roundedDuration|$documentTitle"
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return "fallback:" + digest.take(12).joinToString("") { "%02x".format(it) }
    }

    private fun isDebugBuild(context: Context): Boolean =
        (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0

    private fun parseVideoSample(raw: String): VideoSample? {
        val value = raw.removeSurrounding("\"")
            .replace("\\\"", "\"")
            .replace("\\n", "")
        val parts = value.split('|')
        if (parts.size != 7) return null
        return VideoSample(
            paused = parts[0] == "1",
            ended = parts[1] == "1",
            currentTime = parts[2].toDoubleOrNull() ?: return null,
            duration = parts[3].toDoubleOrNull() ?: return null,
            playbackRate = parts[4].toDoubleOrNull() ?: return null,
            documentTitle = Uri.decode(parts[5]),
            pageTimeMs = parts[6].toDoubleOrNull() ?: return null
        )
    }

    data class LearningTaskState(
        val url: String = "",
        val lectureId: Long? = null,
        val lectureKey: String? = null,
        val lectureIdSource: String = "none",
        val videoFound: Boolean = false,
        val currentTime: Double = 0.0,
        val duration: Double = 0.0,
        val playbackRate: Double = 1.0,
        val currentLectureCreditedMillis: Long = 0,
        val currentLectureMaxPositionMillis: Long = 0,
        val currentLectureDurationMillis: Long = 0,
        val currentLectureCountsAsWatched: Boolean = false,
        val currentLectureWatchedReason: String = "no lecture key",
        val creditedMillis: Long = 0,
        val watchedLectureCount: Int = 0,
        val requiredMinutes: Int = 30,
        val requiredLectures: Int = 0,
        val minimumWatchedShare: Int = AppDataStore.DEFAULT_LEARNING_MINIMUM_WATCHED_SHARE,
        val completed: Boolean = false,
        val debugEnabled: Boolean = false,
        val isPlaying: Boolean = false,
        val activityResumed: Boolean = false,
        val lastMediaDelta: Double? = null,
        val lastWallDelta: Double? = null,
        val lastSkipReason: String = "none",
        val openRequest: (() -> Unit)? = null
    )

    private data class VideoSample(
        val paused: Boolean,
        val ended: Boolean,
        val currentTime: Double,
        val duration: Double,
        val playbackRate: Double,
        val documentTitle: String,
        val pageTimeMs: Double
    )

    private class LearningWebViewClient(
        private val isAllowedUrl: (String) -> Boolean,
        private val onVisitedUrl: (String) -> Unit,
        private val onProgressChanged: () -> Unit
    ) : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return !isAllowedUrl(request.url.toString())
        }

        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            return !isAllowedUrl(url)
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            super.doUpdateVisitedHistory(view, url, isReload)
            onVisitedUrl(url)
            onProgressChanged()
        }
    }

    companion object {
        private const val VIDEO_PROBE_JS = """
            (function() {
              function findVideo(doc) {
                try {
                  var v = doc.querySelector('video');
                  if (v) return v;
                  var frames = doc.querySelectorAll('iframe');
                  for (var i = 0; i < frames.length; i++) {
                    try {
                      if (frames[i].contentDocument) {
                        v = findVideo(frames[i].contentDocument);
                        if (v) return v;
                      }
                    } catch (e) {}
                  }
                } catch (e) {}
                return null;
              }
              var v = findVideo(document);
              if (!v) return 'none';
              return (v.paused ? '1' : '0') + '|' +
                     (v.ended ? '1' : '0') + '|' +
                     v.currentTime + '|' +
                     v.duration + '|' +
                     v.playbackRate + '|' +
                     encodeURIComponent(document.title || '') + '|' +
                     Date.now();
            })();
        """
    }
}
