package com.example.focuslock.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.rememberTimePickerState
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    scheduleEnabled: Boolean,
    startMinutes: Int,
    exactAlarmAllowed: Boolean,
    overlayAllowed: Boolean,
    learningStartUrl: String,
    learningRequiredMinutes: Int,
    learningRequiredLectures: Int,
    learningDebugEnabled: Boolean,
    learningMinimumWatchedShare: Int,
    learningEnabled: Boolean,
    walkingEnabled: Boolean,
    walkingRequiredMinutes: Int,
    walkingCadenceThreshold: Int,
    walkingDebugEnabled: Boolean,
    onScheduleEnabledChanged: (Boolean) -> Unit,
    onStartMinutesChanged: (Int) -> Unit,
    onRequestExactAlarm: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestBatteryOptimization: () -> Unit,
    onTestLock: () -> Unit,
    onLearningStartUrlChanged: (String) -> Unit,
    onLearningRequiredMinutesChanged: (Int) -> Unit,
    onLearningRequiredLecturesChanged: (Int) -> Unit,
    onLearningDebugChanged: (Boolean) -> Unit,
    onLearningMinimumWatchedShareChanged: (Int) -> Unit,
    onLearningEnabledChanged: (Boolean) -> Unit,
    onWalkingEnabledChanged: (Boolean) -> Unit,
    onWalkingRequiredMinutesChanged: (Int) -> Unit,
    onWalkingCadenceThresholdChanged: (Int) -> Unit,
    onWalkingDebugChanged: (Boolean) -> Unit
) {
    var showTimePicker by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var activityRecognitionGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> activityRecognitionGranted = granted }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Focus Lock", style = MaterialTheme.typography.headlineMedium)
        Text("Scheduling, lock, learning, and developer exit.")

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Schedule", style = MaterialTheme.typography.titleLarge)
                HorizontalDivider()
                Text("Start time: ${formatMinutes(startMinutes)}")
                OutlinedButton(onClick = { showTimePicker = true }) {
                    Text("Choose start time")
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Enable daily schedule")
                    Switch(checked = scheduleEnabled, onCheckedChange = onScheduleEnabledChanged)
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Learning", style = MaterialTheme.typography.titleLarge)
                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Enable Learning task")
                    Switch(checked = learningEnabled, onCheckedChange = onLearningEnabledChanged)
                }
                OutlinedTextField(
                    value = learningStartUrl,
                    onValueChange = onLearningStartUrlChanged,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Start URL") },
                    singleLine = true
                )
                Text("Allowed hosts: udemy.com, *.udemy.com, udemycdn.com", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = learningRequiredMinutes.toString(),
                    onValueChange = { value -> value.toIntOrNull()?.takeIf { it >= 0 }?.let(onLearningRequiredMinutesChanged) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Required verified minutes (0 disables)") },
                    singleLine = true
                )
                var shareText by remember(learningMinimumWatchedShare) {
                    mutableStateOf(learningMinimumWatchedShare.toString())
                }
                OutlinedTextField(
                    value = shareText,
                    onValueChange = { value ->
                        if (value.length <= 3 && value.all { it.isDigit() }) {
                            shareText = value
                            value.toIntOrNull()?.takeIf { it in 50..100 }
                                ?.let(onLearningMinimumWatchedShareChanged)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Minimum watched share (%) (50-100)") },
                    isError = shareText.toIntOrNull()?.let { it in 50..100 } != true,
                    singleLine = true
                )
                OutlinedTextField(
                    value = learningRequiredLectures.toString(),
                    onValueChange = { value -> value.toIntOrNull()?.takeIf { it >= 0 }?.let(onLearningRequiredLecturesChanged) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Required watched lectures (0 disables)") },
                    singleLine = true
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Learning debug panel")
                    Switch(checked = learningDebugEnabled, onCheckedChange = onLearningDebugChanged)
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Walking", style = MaterialTheme.typography.titleLarge)
                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Enable Walking task")
                    Switch(checked = walkingEnabled, onCheckedChange = onWalkingEnabledChanged)
                }
                Text(if (activityRecognitionGranted) "Activity recognition: allowed" else "Activity recognition: permission needed")
                if (!activityRecognitionGranted) {
                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                permissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                            } else {
                                activityRecognitionGranted = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Allow activity recognition") }
                }
                OutlinedTextField(
                    value = walkingRequiredMinutes.toString(),
                    onValueChange = { value ->
                        value.toIntOrNull()?.let { minutes ->
                            val minimum = if (walkingDebugEnabled) 1 else 30
                            if (minutes >= minimum) onWalkingRequiredMinutesChanged(minutes)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(if (walkingDebugEnabled) "Required walking minutes (debug: minimum 1)" else "Required walking minutes (minimum 30)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = walkingCadenceThreshold.toString(),
                    onValueChange = { value -> value.toIntOrNull()?.takeIf { it >= 1 }?.let(onWalkingCadenceThresholdChanged) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Cadence threshold (steps/min)") },
                    singleLine = true
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Walking debug / test mode")
                    Switch(checked = walkingDebugEnabled, onCheckedChange = onWalkingDebugChanged)
                }
                Text(
                    "Debug mode allows a walking goal as low as 1 minute and shows sensor diagnostics on the task card.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Required access", style = MaterialTheme.typography.titleLarge)
                Text(if (exactAlarmAllowed) "Exact alarms: allowed" else "Exact alarms: permission needed")
                if (!exactAlarmAllowed) {
                    Button(onClick = onRequestExactAlarm, modifier = Modifier.fillMaxWidth()) { Text("Allow exact alarms") }
                }
                Text(if (overlayAllowed) "Overlay: allowed" else "Overlay: permission needed")
                if (!overlayAllowed) {
                    Button(onClick = onRequestOverlay, modifier = Modifier.fillMaxWidth()) { Text("Allow overlay") }
                }
                Button(onClick = onRequestBatteryOptimization, modifier = Modifier.fillMaxWidth()) {
                    Text("Allow battery optimization exception")
                }
                Text(
                    "Samsung may restrict background work. Allowing the exception can improve scheduled-lock reliability.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Button(onClick = onTestLock, modifier = Modifier.fillMaxWidth()) { Text("Test lock now") }
    }

    if (showTimePicker) {
        TimePickerDialog(
            initialMinutes = startMinutes,
            onDismiss = { showTimePicker = false },
            onConfirm = {
                onStartMinutesChanged(it)
                showTimePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialog(
    initialMinutes: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val state = rememberTimePickerState(
        initialHour = initialMinutes / 60,
        initialMinute = initialMinutes % 60,
        is24Hour = false
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose start time") },
        text = { TimePicker(state = state) },
        confirmButton = { TextButton(onClick = { onConfirm(state.hour * 60 + state.minute) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun formatMinutes(minutes: Int): String {
    val hour24 = minutes / 60
    val minute = minutes % 60
    val period = if (hour24 < 12) "AM" else "PM"
    val hour12 = when (val hour = hour24 % 12) {
        0 -> 12
        else -> hour
    }
    return "%02d:%02d %s".format(hour12, minute, period)
}
