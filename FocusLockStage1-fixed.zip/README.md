# Focus Lock — Stage 1

Kotlin + Jetpack Compose Android app, min SDK 26, target SDK 35.

## Stage 1 scope

- Daily scheduled start time.
- Exact `AlarmManager` alarm.
- Re-register after reboot/package replacement/exact-alarm permission changes.
- Foreground service while locked.
- Full-screen lock Activity with Back disabled.
- Registry-driven `Task` interface and one manual task.
- Developer password exit.
- Emergency Call opens the system dialer.
- Overlay permission and battery-optimization guidance.

## Developer exit password

Defined only in:

`app/src/main/java/com/example/focuslock/lock/DeveloperPassword.kt`

Current value: `Stage1Exit`

## Android Studio

1. Open this folder in Android Studio.
2. Use JDK 17.
3. Let Gradle sync and install the requested Android SDK 35 platform.
4. Connect a Samsung Galaxy A16 with USB debugging enabled.
5. Run the `app` configuration.

## Device setup

Inside the app:

1. Allow notifications when prompted.
2. Allow **Alarms & reminders** when prompted/opened.
3. Allow **Display over other apps**.
4. Allow the battery-optimization exception if the device offers it.
5. Choose a time and enable the schedule.
6. Use **Test lock now** before testing the real schedule.

## Scheduled-alarm test

Set the start time a few minutes in the future, enable the schedule, leave the app, and wait for the alarm. The exact alarm starts the foreground service, which attempts to launch the lock Activity. The foreground notification also provides a fallback entry point to the lock screen.

## USB install

Android Studio can install directly. If using ADB from a terminal after building:

`adb install -r app/build/outputs/apk/debug/app-debug.apk`

## Limitations

- Android does not provide a general-purpose kiosk mode to ordinary apps. Home, system UI, Settings, power controls, and other privileged/system surfaces cannot be guaranteed to remain blocked without device-owner/kiosk APIs, which Stage 1 intentionally does not use.
- `SYSTEM_ALERT_WINDOW` creates `TYPE_APPLICATION_OVERLAY` windows, but an ordinary Activity itself is still an application window; the permission does not convert an Activity into an overlay window.
- Android 14+ restricts full-screen intent notifications to permitted high-priority use cases, and Android/OEM versions can restrict background activity launches. This project attempts a direct Activity launch and also exposes the lock Activity through the foreground notification.
- Samsung firmware may apply additional battery/background restrictions.
- Task completion state is in memory for Stage 1 and resets when the lock service starts/process state is lost.
- Exact-alarm access can be revoked by the user/system; the app rechecks it before scheduling.
- No camera, AI, lessons, walking, database, authentication, or persistent task history is included.
