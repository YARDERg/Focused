# Stage 1 intentionally uses no custom ProGuard/R8 rules.
