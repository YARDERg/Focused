package com.example.focuslock.tasks

import androidx.compose.runtime.Composable

interface Task {
    val id: String
    val title: String

    fun isCompleted(): Boolean

    fun reset()

    @Composable
    fun Content(onChanged: () -> Unit)
}
