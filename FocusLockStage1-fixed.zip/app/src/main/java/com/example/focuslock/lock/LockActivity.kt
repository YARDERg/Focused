package com.example.focuslock.lock

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.tasks.TaskRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class LockActivity : ComponentActivity() {
    private var developerPassword by mutableStateOf("")
    private var passwordError by mutableStateOf(false)
    private var skipBackgroundRelaunch = false

    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        window.addFlags(
            android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = Unit
        })

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    LockScreen()
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()

        if (skipBackgroundRelaunch || TaskRegistry.allCompleted()) return

        activityScope.launch {
            val settings = AppDataStore(applicationContext).readSettings()
            val now = System.currentTimeMillis()

            if (!settings.lockActive || now < settings.emergencyUntil) {
                return@launch
            }

            launchLockActivity()
        }
    }

    private fun launchLockActivity() {
        runOnUiThread {
            val intent = Intent(this@LockActivity, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }

            runCatching { startActivity(intent) }
        }
    }

    @Composable
    private fun LockScreen() {
        val tasks = TaskRegistry.tasks
        val completedCount = tasks.count { it.isCompleted() }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Focus lock",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "Complete every task to unlock.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Text(
                    text = "$completedCount / ${tasks.size} completed",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(tasks, key = { it.id }) { task ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(task.title, style = MaterialTheme.typography.titleMedium)
                        HorizontalDivider()
                        task.Content {
                            // Compose state inside each task drives its own UI.
                        }
                    }
                }
            }

            item {
                if (TaskRegistry.allCompleted()) {
                    Button(
                        onClick = { finishLock() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Unlock")
                    }
                }
            }

            item { DeveloperExitCard() }

            item {
                Button(
                    onClick = { openEmergencyDialer() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Emergency Call")
                }
            }
        }
    }

    @Composable
    private fun DeveloperExitCard() {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Developer exit", style = MaterialTheme.typography.titleMedium)
                Text("Stage 1 only. Remove this section later.")
                OutlinedTextField(
                    value = developerPassword,
                    onValueChange = {
                        developerPassword = it
                        passwordError = false
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    isError = passwordError
                )
                if (passwordError) {
                    Text("Incorrect password.", color = MaterialTheme.colorScheme.error)
                }
                Button(
                    onClick = {
                        if (developerPassword == DeveloperPassword.VALUE) {
                            finishLock()
                        } else {
                            passwordError = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Exit lock")
                }
            }
        }
    }

    private fun finishLock() {
        skipBackgroundRelaunch = true

        activityScope.launch {
            AppDataStore(applicationContext).setLockActive(false)

            runOnUiThread {
                stopService(Intent(this@LockActivity, LockForegroundService::class.java))
                finishAndRemoveTask()
            }
        }
    }

    private fun openEmergencyDialer() {
        activityScope.launch {
            AppDataStore(applicationContext).setEmergencyUntil(
                System.currentTimeMillis() + 10 * 60 * 1000L
            )

            runOnUiThread {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
                runCatching { startActivity(intent) }
            }
        }
    }

    override fun onDestroy() {
        activityScope.cancel()
        super.onDestroy()
    }
}
