package com.example.focuslock.lock

object DeveloperPassword {
    // Stage 1: deliberately hard-coded in one place so it is easy to remove later.
    const val VALUE = "Stage1Exit"
}
