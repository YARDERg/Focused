package com.example.focuslock.tasks

object TaskRegistry {
    // Stage 2: add another Task implementation here. The lock UI needs no changes.
    val tasks: List<Task> = listOf(
        ManualTask()
    )

    fun resetAll() {
        tasks.forEach(Task::reset)
    }

    fun allCompleted(): Boolean = tasks.all(Task::isCompleted)
}
