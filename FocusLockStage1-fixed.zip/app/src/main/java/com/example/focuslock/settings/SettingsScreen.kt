package com.example.focuslock.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TimePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    scheduleEnabled: Boolean,
    startMinutes: Int,
    exactAlarmAllowed: Boolean,
    overlayAllowed: Boolean,
    onScheduleEnabledChanged: (Boolean) -> Unit,
    onStartMinutesChanged: (Int) -> Unit,
    onRequestExactAlarm: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestBatteryOptimization: () -> Unit,
    onTestLock: () -> Unit
) {
    var showTimePicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Focus Lock", style = MaterialTheme.typography.headlineMedium)
        Text("Stage 1: scheduling, lock, and developer exit.")

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Schedule", style = MaterialTheme.typography.titleLarge)
                HorizontalDivider()

                Text("Start time: ${formatMinutes(startMinutes)}")
                OutlinedButton(onClick = { showTimePicker = true }) {
                    Text("Choose start time")
                }

                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Enable daily schedule")
                    Switch(
                        checked = scheduleEnabled,
                        onCheckedChange = onScheduleEnabledChanged
                    )
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Required access", style = MaterialTheme.typography.titleLarge)
                Text(if (exactAlarmAllowed) "Exact alarms: allowed" else "Exact alarms: permission needed")
                if (!exactAlarmAllowed) {
                    Button(onClick = onRequestExactAlarm, modifier = Modifier.fillMaxWidth()) {
                        Text("Allow exact alarms")
                    }
                }

                Text(if (overlayAllowed) "Overlay: allowed" else "Overlay: permission needed")
                if (!overlayAllowed) {
                    Button(onClick = onRequestOverlay, modifier = Modifier.fillMaxWidth()) {
                        Text("Allow overlay")
                    }
                }

                Button(onClick = onRequestBatteryOptimization, modifier = Modifier.fillMaxWidth()) {
                    Text("Allow battery optimization exception")
                }
                Text(
                    "Samsung may restrict background work. Allowing the exception can improve scheduled-lock reliability.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Button(onClick = onTestLock, modifier = Modifier.fillMaxWidth()) {
            Text("Test lock now")
        }
    }

    if (showTimePicker) {
        TimePickerDialog(
            initialMinutes = startMinutes,
            onDismiss = { showTimePicker = false },
            onConfirm = {
                onStartMinutesChanged(it)
                showTimePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialog(
    initialMinutes: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val state = rememberTimePickerState(
        initialHour = initialMinutes / 60,
        initialMinute = initialMinutes % 60,
        is24Hour = true
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose start time") },
        text = { TimePicker(state = state) },
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour * 60 + state.minute) }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

private fun formatMinutes(minutes: Int): String {
    val hour = minutes / 60
    val minute = minutes % 60
    return "%02d:%02d".format(hour, minute)
}
