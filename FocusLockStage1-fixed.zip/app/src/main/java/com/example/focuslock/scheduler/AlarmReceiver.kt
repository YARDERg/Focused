package com.example.focuslock.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.lock.LockForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val settings = AppDataStore(appContext).readSettings()
                if (settings.scheduleEnabled) {
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, LockForegroundService::class.java)
                    )

                    // setExactAndAllowWhileIdle is a one-shot alarm, so register tomorrow's alarm now.
                    ScheduleManager.scheduleDaily(appContext, settings.startMinutes)
                }
            } finally {
                pendingResult.finish()
                cancel()
            }
        }
    }
}
