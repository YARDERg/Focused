package com.example.focuslock.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.lock.LockForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return

        val supported =
            action == Intent.ACTION_BOOT_COMPLETED ||
                action == Intent.ACTION_MY_PACKAGE_REPLACED ||
                action == "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED"

        if (!supported) return

        val pendingResult = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val settings = AppDataStore(appContext).readSettings()

                if (settings.lockActive) {
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, LockForegroundService::class.java)
                    )
                }

                if (
                    settings.scheduleEnabled &&
                    ScheduleManager.canScheduleExactAlarms(appContext)
                ) {
                    ScheduleManager.scheduleDaily(
                        appContext,
                        settings.startMinutes
                    )
                }
            } finally {
                pendingResult.finish()
                cancel()
            }
        }
    }
}
