package com.example.focuslock.tasks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class ManualTask : Task {
    override val id: String = "manual_task"
    override val title: String = "Manual task"

    private var completed by mutableStateOf(false)

    override fun isCompleted(): Boolean = completed

    override fun reset() {
        completed = false
    }

    @Composable
    override fun Content(onChanged: () -> Unit) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(if (completed) "Completed" else "Tap the button to complete this task.")
            if (!completed) {
                Button(onClick = {
                    completed = true
                    onChanged()
                }) {
                    Text("Complete")
                }
            }
        }
    }
}
