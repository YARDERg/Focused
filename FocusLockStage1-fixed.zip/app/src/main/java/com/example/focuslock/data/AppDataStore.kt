package com.example.focuslock.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.focusLockDataStore by preferencesDataStore(name = "focus_lock")

class AppDataStore(private val context: Context) {
    private object Keys {
        val scheduleEnabled = booleanPreferencesKey("schedule_enabled")
        val startMinutes = intPreferencesKey("start_minutes")
        val lockActive = booleanPreferencesKey("lock_active")
        val emergencyUntil = longPreferencesKey("emergency_until")
    }

    val scheduleEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.scheduleEnabled] ?: false
    }

    val startMinutes: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.startMinutes] ?: (9 * 60)
    }

    val lockActive: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.lockActive] ?: false
    }

    suspend fun setScheduleEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.scheduleEnabled] = enabled }
    }

    suspend fun setStartMinutes(minutes: Int) {
        require(minutes in 0..1439)
        context.focusLockDataStore.edit { it[Keys.startMinutes] = minutes }
    }

    suspend fun setLockActive(active: Boolean) {
        context.focusLockDataStore.edit { it[Keys.lockActive] = active }
    }

    suspend fun setEmergencyUntil(timestampMillis: Long) {
        context.focusLockDataStore.edit { it[Keys.emergencyUntil] = timestampMillis }
    }

    suspend fun readSettings(): StoredSettings {
        val preferences = context.focusLockDataStore.data.first()
        return StoredSettings(
            scheduleEnabled = preferences[Keys.scheduleEnabled] ?: false,
            startMinutes = preferences[Keys.startMinutes] ?: (9 * 60),
            lockActive = preferences[Keys.lockActive] ?: false,
            emergencyUntil = preferences[Keys.emergencyUntil] ?: 0L
        )
    }
}

data class StoredSettings(
    val scheduleEnabled: Boolean,
    val startMinutes: Int,
    val lockActive: Boolean,
    val emergencyUntil: Long
)
