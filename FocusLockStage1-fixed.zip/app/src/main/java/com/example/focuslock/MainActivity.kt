package com.example.focuslock

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.core.content.ContextCompat
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.lock.LockForegroundService
import com.example.focuslock.scheduler.ScheduleManager
import com.example.focuslock.settings.SettingsScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val dataStore by lazy { AppDataStore(applicationContext) }

    private var exactAlarmAllowed by mutableStateOf(false)
    private var overlayAllowed by mutableStateOf(false)

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        refreshPermissionState()

        if (
            Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            val scheduleEnabled by dataStore.scheduleEnabled.collectAsStateWithLifecycle(initialValue = false)
            val startMinutes by dataStore.startMinutes.collectAsStateWithLifecycle(initialValue = 9 * 60)

            MaterialTheme {
                Surface {
                    SettingsScreen(
                        scheduleEnabled = scheduleEnabled,
                        startMinutes = startMinutes,
                        exactAlarmAllowed = exactAlarmAllowed,
                        overlayAllowed = overlayAllowed,
                        onScheduleEnabledChanged = ::setScheduleEnabled,
                        onStartMinutesChanged = ::setStartMinutes,
                        onRequestExactAlarm = ::requestExactAlarmAccess,
                        onRequestOverlay = ::requestOverlayAccess,
                        onRequestBatteryOptimization = ::requestBatteryOptimization,
                        onTestLock = ::testLock
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionState()
        refreshScheduleAndLock()
    }

    private fun refreshPermissionState() {
        exactAlarmAllowed = ScheduleManager.canScheduleExactAlarms(this)
        overlayAllowed = Settings.canDrawOverlays(this)
    }

    private fun setScheduleEnabled(enabled: Boolean) {
        lifecycleScope.launch {
            dataStore.setScheduleEnabled(enabled)

            if (enabled) {
                val settings = dataStore.readSettings()
                ScheduleManager.scheduleDaily(this@MainActivity, settings.startMinutes)
            } else {
                ScheduleManager.cancel(this@MainActivity)
            }
        }
    }

    private fun setStartMinutes(minutes: Int) {
        lifecycleScope.launch {
            dataStore.setStartMinutes(minutes)
            val settings = dataStore.readSettings()

            if (settings.scheduleEnabled) {
                ScheduleManager.scheduleDaily(this@MainActivity, settings.startMinutes)
            }
        }
    }

    private fun refreshScheduleAndLock() {
        lifecycleScope.launch {
            val settings = dataStore.readSettings()

            if (settings.lockActive) {
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, LockForegroundService::class.java)
                )
            }

            if (
                settings.scheduleEnabled &&
                ScheduleManager.canScheduleExactAlarms(this@MainActivity)
            ) {
                ScheduleManager.scheduleDaily(this@MainActivity, settings.startMinutes)
            }
        }
    }

    private fun requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }

    private fun requestOverlayAccess() {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
            data = Uri.parse("package:$packageName")
        }
        startActivity(intent)
    }

    private fun requestBatteryOptimization() {
        val powerManager = getSystemService(PowerManager::class.java)

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !powerManager.isIgnoringBatteryOptimizations(packageName)
        ) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }

    private fun testLock() {
        val intent = Intent(this@MainActivity, LockForegroundService::class.java)
        ContextCompat.startForegroundService(this@MainActivity, intent)
    }
}
