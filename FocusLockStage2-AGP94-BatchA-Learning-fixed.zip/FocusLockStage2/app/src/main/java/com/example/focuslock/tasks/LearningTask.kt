package com.example.focuslock.tasks

import android.content.Context
import android.net.Uri
import android.os.PowerManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.data.LearningProgress
import com.example.focuslock.data.LearningSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale

class LearningTask(
    private val dataStore: AppDataStore
) : Task {
    override val id: String = "learning_task"
    override val title: String = "Learning"
    override val hasFullScreenUi: Boolean = true

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(LearningTaskState())
    val state = _state.asStateFlow()

    private var settings: LearningSettings = LearningSettings(
        AppDataStore.DEFAULT_LEARNING_START_URL,
        AppDataStore.DEFAULT_LEARNING_REQUIRED_MINUTES,
        AppDataStore.DEFAULT_LEARNING_REQUIRED_LECTURES,
        false
    )
    private var progress: LearningProgress = LearningProgress.empty("")
    private var initialized = false

    override fun isCompleted(): Boolean = _state.value.completed

    override fun reset() {
        scope.launch {
            loadState()
        }
    }

    @Composable
    override fun Content(onChanged: () -> Unit) {
        val state by state.collectAsState()
        val currentOnChanged by rememberUpdatedState(onChanged)

        DisposableEffect(Unit) {
            loadStateAsync()
            onDispose { }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                when {
                    state.completed -> "Learning goals completed"
                    state.requiredMinutes > 0 -> "Verified: ${state.creditedSeconds / 60} / ${state.requiredMinutes} min"
                    else -> "Verified: ${state.creditedSeconds / 60} min"
                }
            )
            if (state.requiredMinutes > 0) {
                LinearProgressIndicator(
                    progress = { (state.creditedSeconds.toFloat() / (state.requiredMinutes * 60L)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (state.requiredLectures > 0) {
                Text("Lectures: ${state.watchedLectureCount} / ${state.requiredLectures}")
            }
            Button(onClick = {
                state.openRequest?.invoke()
                currentOnChanged()
            }) {
                Text("Open learning")
            }
        }
    }

    fun createWebView(
        context: Context,
        onProgressChanged: () -> Unit
    ): WebView {
        val webView = WebView(context)
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
        }
        webView.webViewClient = LearningWebViewClient(
            isAllowedUrl = ::isAllowedUrl,
            onVisitedUrl = ::onVisitedUrl,
            onProgressChanged = onProgressChanged
        )
        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }

        if (isDebugBuild(context)) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        val startUrl = settings.startUrl.takeIf { isAllowedUrl(it) }
            ?: AppDataStore.DEFAULT_LEARNING_START_URL
        webView.loadUrl(startUrl)
        startTracking(webView, onProgressChanged)
        return webView
    }

    fun disposeWebView(webView: WebView) {
        stopTracking(webView)
        CookieManager.getInstance().flush()
        webView.stopLoading()
        webView.webViewClient = null
        webView.webChromeClient = null
        webView.destroy()
    }

    private var trackingJob: Job? = null
    private var lastLectureId: Long? = null
    private var lastMediaTime: Double? = null
    private var lastWallTime: Long? = null
    private var pendingCreditFraction = 0.0
    private val creditMutex = Mutex()

    private fun startTracking(webView: WebView, onProgressChanged: () -> Unit) {
        stopTracking(webView)
        trackingJob = scope.launch(Dispatchers.Main.immediate) {
            while (true) {
                delay(1000)
                sampleVideo(webView, onProgressChanged)
            }
        }
    }

    private fun stopTracking(webView: WebView) {
        trackingJob?.cancel()
        trackingJob = null
        lastLectureId = null
        lastMediaTime = null
        lastWallTime = null
        pendingCreditFraction = 0.0
    }

    private fun sampleVideo(webView: WebView, onProgressChanged: () -> Unit) {
        if (!_state.value.activityResumed) return
        val powerManager = webView.context.getSystemService(PowerManager::class.java)
        if (powerManager?.isInteractive != true) return

        val now = System.currentTimeMillis()
        webView.evaluateJavascript(VIDEO_PROBE_JS) { raw ->
            val sample = parseVideoSample(raw) ?: run {
                _state.value = _state.value.copy(videoFound = false, isPlaying = false)
                return@evaluateJavascript
            }

            val lectureId = _state.value.lectureId
            _state.value = _state.value.copy(
                videoFound = true,
                currentTime = sample.currentTime,
                duration = sample.duration,
                isPlaying = !sample.paused && !sample.ended
            )

            if (lectureId == null || sample.paused || sample.ended || sample.duration <= 0.0 || !sample.duration.isFinite()) {
                lastLectureId = lectureId
                lastMediaTime = sample.currentTime
                lastWallTime = now
                pendingCreditFraction = 0.0
                return@evaluateJavascript
            }

            if (lastLectureId != lectureId || lastMediaTime == null || lastWallTime == null) {
                lastLectureId = lectureId
                lastMediaTime = sample.currentTime
                lastWallTime = now
                pendingCreditFraction = 0.0
                return@evaluateJavascript
            }

            val mediaDelta = sample.currentTime - lastMediaTime!!
            val wallDelta = (now - lastWallTime!!).toDouble() / 1000.0
            lastMediaTime = sample.currentTime
            lastWallTime = now

            val maxAllowedMediaDelta =
                wallDelta * max(sample.playbackRate, 1.0) * 1.3
            if (mediaDelta > 0.0 &&
                mediaDelta <= maxAllowedMediaDelta &&
                mediaDelta.isFinite()
            ) {
                pendingCreditFraction += minOf(mediaDelta, wallDelta)
                val wholeSeconds = pendingCreditFraction.toLong()
                pendingCreditFraction -= wholeSeconds

                if (wholeSeconds > 0L) {
                    scope.launch {
                        creditMutex.withLock {
                            val currentCredit = progress.creditsByLecture[lectureId] ?: 0L
                            val newCredit = (currentCredit + wholeSeconds).coerceAtMost(sample.duration.toLong())
                            val updated = dataStore.creditLearningLecture(
                                lectureId,
                                newCredit,
                                sample.duration.toLong().coerceAtLeast(1L)
                            )
                            progress = updated
                            updateCompletionState()
                            onProgressChanged()
                        }
                    }
                }
            }
        }
    }

    fun setActivityResumed(resumed: Boolean) {
        _state.value = _state.value.copy(activityResumed = resumed)
        if (!resumed) {
            lastMediaTime = null
            lastWallTime = null
            pendingCreditFraction = 0.0
        }
    }

    fun setOpenRequest(request: (() -> Unit)?) {
        _state.value = _state.value.copy(openRequest = request)
    }

    private fun loadStateAsync() {
        if (initialized) return
        initialized = true
        scope.launch { loadState() }
    }

    private suspend fun loadState() {
        settings = dataStore.readLearningSettings()
        progress = dataStore.readLearningProgress()
        updateCompletionState()
    }

    private fun updateCompletionState() {
        val creditedSeconds = progress.creditedSeconds
        val minutesMet = settings.requiredMinutes <= 0 || creditedSeconds >= settings.requiredMinutes * 60L
        val lecturesMet = settings.requiredLectures <= 0 || progress.watchedLectureIds.size >= settings.requiredLectures
        _state.value = _state.value.copy(
            requiredMinutes = settings.requiredMinutes,
            requiredLectures = settings.requiredLectures,
            creditedSeconds = creditedSeconds,
            watchedLectureCount = progress.watchedLectureIds.size,
            completed = minutesMet && lecturesMet,
            debugEnabled = settings.debugEnabled
        )
    }

    fun onVisitedUrl(url: String) {
        val lectureId = extractLectureId(url)
        if (lectureId != _state.value.lectureId) {
            lastLectureId = null
            lastMediaTime = null
            lastWallTime = null
        }
        _state.value = _state.value.copy(url = url, lectureId = lectureId)
    }

    fun isAllowedUrl(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase(Locale.US) ?: return false
        return host == "udemy.com" || host.endsWith(".udemy.com") || host == "udemycdn.com"
    }

    private fun extractLectureId(url: String): Long? {
        val match = Regex("lecture/(\\d+)", RegexOption.IGNORE_CASE).find(url) ?: return null
        return match.groupValues[1].toLongOrNull()
    }

    private fun isDebugBuild(context: Context): Boolean =
        (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0

    private fun parseVideoSample(raw: String): VideoSample? {
        val value = raw.removeSurrounding("\"")
            .replace("\\\"", "\"")
            .replace("\\n", "")
        val parts = value.split('|')
        if (parts.size != 5) return null
        return VideoSample(
            paused = parts[0] == "1",
            ended = parts[1] == "1",
            currentTime = parts[2].toDoubleOrNull() ?: return null,
            duration = parts[3].toDoubleOrNull() ?: return null,
            playbackRate = parts[4].toDoubleOrNull() ?: return null
        )
    }

    data class LearningTaskState(
        val url: String = "",
        val lectureId: Long? = null,
        val videoFound: Boolean = false,
        val currentTime: Double = 0.0,
        val duration: Double = 0.0,
        val creditedSeconds: Long = 0,
        val watchedLectureCount: Int = 0,
        val requiredMinutes: Int = 30,
        val requiredLectures: Int = 0,
        val completed: Boolean = false,
        val debugEnabled: Boolean = false,
        val isPlaying: Boolean = false,
        val activityResumed: Boolean = false,
        val openRequest: (() -> Unit)? = null
    )

    private data class VideoSample(
        val paused: Boolean,
        val ended: Boolean,
        val currentTime: Double,
        val duration: Double,
        val playbackRate: Double
    )

    private class LearningWebViewClient(
        private val isAllowedUrl: (String) -> Boolean,
        private val onVisitedUrl: (String) -> Unit,
        private val onProgressChanged: () -> Unit
    ) : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return !isAllowedUrl(request.url.toString())
        }

        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            return !isAllowedUrl(url)
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            super.doUpdateVisitedHistory(view, url, isReload)
            onVisitedUrl(url)
            onProgressChanged()
        }
    }

    companion object {
        private const val VIDEO_PROBE_JS = """
            (function() {
              function findVideo(doc) {
                try {
                  var v = doc.querySelector('video');
                  if (v) return v;
                  var frames = doc.querySelectorAll('iframe');
                  for (var i = 0; i < frames.length; i++) {
                    try {
                      if (frames[i].contentDocument) {
                        v = findVideo(frames[i].contentDocument);
                        if (v) return v;
                      }
                    } catch (e) {}
                  }
                } catch (e) {}
                return null;
              }
              var v = findVideo(document);
              if (!v) return 'none';
              return (v.paused ? '1' : '0') + '|' + (v.ended ? '1' : '0') + '|' + v.currentTime + '|' + v.duration + '|' + v.playbackRate;
            })();
        """
    }
}
