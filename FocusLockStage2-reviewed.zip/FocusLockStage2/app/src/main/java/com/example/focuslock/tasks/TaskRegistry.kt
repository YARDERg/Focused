package com.example.focuslock.tasks

import android.content.Context
import com.example.focuslock.data.AppDataStore

object TaskRegistry {
    private var initialized = false
    private var registeredTasks: List<Task> = emptyList()

    fun initialize(context: Context) {
        if (initialized) return
        val appContext = context.applicationContext
        registeredTasks = listOf(
            LearningTask(AppDataStore(appContext))
        )
        initialized = true
    }

    val tasks: List<Task>
        get() = registeredTasks

    fun resetAll() {
        registeredTasks.forEach(Task::reset)
    }

    fun allCompleted(): Boolean = registeredTasks.isNotEmpty() && registeredTasks.all(Task::isCompleted)
}
