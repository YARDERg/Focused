package com.example.focuslock.lock

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.focuslock.data.AppDataStore
import com.example.focuslock.tasks.LearningTask
import com.example.focuslock.tasks.Task
import com.example.focuslock.tasks.TaskRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class LockActivity : ComponentActivity() {
    private var developerPassword by mutableStateOf("")
    private var passwordError by mutableStateOf(false)
    private var skipBackgroundRelaunch = false
    private var fullScreenTask by mutableStateOf<Task?>(null)
    private var learningWebView: WebView? = null

    private lateinit var learningTask: LearningTask

    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        window.addFlags(
            android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        }

        TaskRegistry.initialize(applicationContext)
        learningTask = TaskRegistry.tasks.filterIsInstance<LearningTask>().first()
        learningTask.setOpenRequest { fullScreenTask = learningTask }
        learningTask.setActivityResumed(true)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (fullScreenTask != null) {
                    if (learningWebView?.canGoBack() == true) {
                        learningWebView?.goBack()
                    } else {
                        closeFullScreenTask()
                    }
                }
            }
        })

        hideSystemBars()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (fullScreenTask != null) {
                        FullScreenTask()
                    } else {
                        LockScreen()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        learningTask.setActivityResumed(true)
        hideSystemBars()
    }

    override fun onPause() {
        learningTask.setActivityResumed(false)
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemBars()
        }
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onStop() {
        super.onStop()

        if (skipBackgroundRelaunch || TaskRegistry.allCompleted()) return

        activityScope.launch {
            val settings = AppDataStore(applicationContext).readSettings()
            val now = System.currentTimeMillis()

            if (!settings.lockActive || now < settings.emergencyUntil) return@launch
            launchLockActivity()
        }
    }

    private fun launchLockActivity() {
        runOnUiThread {
            val intent = Intent(this@LockActivity, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            runCatching { startActivity(intent) }
        }
    }

    @Composable
    private fun LockScreen() {
        val learningState by learningTask.state.collectAsState()
        val tasks = TaskRegistry.tasks
        val completedCount = tasks.count { it.isCompleted() }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Focus lock", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Complete every task to unlock.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Text(
                    "$completedCount / ${tasks.size} completed",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(tasks, key = { it.id }) { task ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(task.title, style = MaterialTheme.typography.titleMedium)
                        HorizontalDivider()
                        task.Content { }
                    }
                }
            }

            if (TaskRegistry.allCompleted()) {
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Goals complete", style = MaterialTheme.typography.titleMedium)
                            Text("Your learning goals for today are complete.")
                            Button(onClick = { finishLock() }, modifier = Modifier.fillMaxWidth()) {
                                Text("Unlock")
                            }
                        }
                    }
                }
            }

            item { DeveloperExitCard() }

            item {
                Button(onClick = { openEmergencyDialer() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Emergency Call")
                }
            }
        }
    }

    @Composable
    private fun FullScreenTask() {
        val learningState by learningTask.state.collectAsState()
        val canGoBack = learningWebView?.canGoBack() == true

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { learningWebView?.goBack() },
                    enabled = canGoBack,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Page back")
                }
                Button(
                    onClick = { closeFullScreenTask() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Exit to lock")
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    "Credited: ${learningState.creditedSeconds / 60} / ${learningState.requiredMinutes} min today",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Lectures watched: ${learningState.watchedLectureCount} / ${learningState.requiredLectures}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (learningState.completed) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Goals complete", style = MaterialTheme.typography.titleMedium)
                        Button(onClick = { finishLock() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Unlock")
                        }
                    }
                }
            }

            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { context ->
                    learningTask.createWebView(
                        context = context,
                        onProgressChanged = { }
                    ).also { webView ->
                        learningWebView = webView
                        webView.layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { webView -> learningWebView = webView }
            )

            if (learningState.debugEnabled) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text("URL: ${learningState.url}", style = MaterialTheme.typography.bodySmall)
                    Text("Lecture ID: ${learningState.lectureId ?: "none"}", style = MaterialTheme.typography.bodySmall)
                    Text("Lecture key: ${learningState.lectureKey ?: "none"}", style = MaterialTheme.typography.bodySmall)
                    Text("Lecture ID source: ${learningState.lectureIdSource}", style = MaterialTheme.typography.bodySmall)
                    Text("Video found: ${if (learningState.videoFound) "yes" else "no"}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Video: ${"%.1f".format(learningState.currentTime)} / ${"%.1f".format(learningState.duration)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Current lecture credited: ${learningState.currentLectureCreditedSeconds}s",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text("Total credited: ${learningState.creditedSeconds}s", style = MaterialTheme.typography.bodySmall)
                    Text("Playback rate: ${"%.3f".format(learningState.playbackRate)}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Last mediaDelta: ${learningState.lastMediaDelta?.let { "%.3f".format(it) } ?: "none"} | wallDelta: ${learningState.lastWallDelta?.let { "%.3f".format(it) } ?: "none"}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text("Last skip reason: ${learningState.lastSkipReason}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Goals: ${learningState.creditedSeconds / 60} / ${learningState.requiredMinutes} min; ${learningState.watchedLectureCount} / ${learningState.requiredLectures} lectures",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }

    private fun closeFullScreenTask() {
        learningWebView?.let(learningTask::disposeWebView)
        learningWebView = null
        fullScreenTask = null
    }

    @Composable
    private fun DeveloperExitCard() {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Developer exit", style = MaterialTheme.typography.titleMedium)
                Text("Developer only. Remove this section later.")
                OutlinedTextField(
                    value = developerPassword,
                    onValueChange = {
                        developerPassword = it
                        passwordError = false
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    isError = passwordError
                )
                if (passwordError) {
                    Text("Incorrect password.", color = MaterialTheme.colorScheme.error)
                }
                Button(
                    onClick = {
                        if (developerPassword == DeveloperPassword.VALUE) finishLock()
                        else passwordError = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Exit lock")
                }
            }
        }
    }

    private fun finishLock() {
        skipBackgroundRelaunch = true
        activityScope.launch {
            AppDataStore(applicationContext).apply {
                setLockActive(false)
                setEmergencyUntil(0L)
            }
            runOnUiThread {
                stopService(Intent(this@LockActivity, LockForegroundService::class.java))
                finishAndRemoveTask()
            }
        }
    }

    private fun openEmergencyDialer() {
        activityScope.launch {
            AppDataStore(applicationContext).setEmergencyUntil(
                System.currentTimeMillis() + 3 * 60 * 1000L
            )
            runOnUiThread {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
                runCatching { startActivity(intent) }
            }
        }
    }

    override fun onDestroy() {
        learningTask.setOpenRequest(null)
        learningTask.setActivityResumed(false)
        learningWebView?.let(learningTask::disposeWebView)
        learningWebView = null
        activityScope.cancel()
        super.onDestroy()
    }
}
