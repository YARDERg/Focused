package com.example.focuslock.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private val Context.focusLockDataStore by preferencesDataStore(name = "focus_lock")

class AppDataStore(private val context: Context) {
    private object Keys {
        val scheduleEnabled = booleanPreferencesKey("schedule_enabled")
        val startMinutes = intPreferencesKey("start_minutes")
        val lockActive = booleanPreferencesKey("lock_active")
        val emergencyUntil = longPreferencesKey("emergency_until")
        val learningStartUrl = stringPreferencesKey("learning_start_url")
        val learningRequiredMinutes = intPreferencesKey("learning_required_minutes")
        val learningRequiredLectures = intPreferencesKey("learning_required_lectures")
        val learningDebugEnabled = booleanPreferencesKey("learning_debug_enabled")
        val learningProgressDate = stringPreferencesKey("learning_progress_date")
        val learningLectureCredits = stringSetPreferencesKey("learning_lecture_credits")
        val learningWatchedLectures = stringSetPreferencesKey("learning_watched_lectures")
    }

    val scheduleEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.scheduleEnabled] ?: false
    }

    val startMinutes: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.startMinutes] ?: (9 * 60)
    }

    val lockActive: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.lockActive] ?: false
    }

    val learningStartUrl: Flow<String> = context.focusLockDataStore.data.map {
        it[Keys.learningStartUrl] ?: DEFAULT_LEARNING_START_URL
    }

    val learningRequiredMinutes: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.learningRequiredMinutes] ?: DEFAULT_LEARNING_REQUIRED_MINUTES
    }

    val learningRequiredLectures: Flow<Int> = context.focusLockDataStore.data.map {
        it[Keys.learningRequiredLectures] ?: DEFAULT_LEARNING_REQUIRED_LECTURES
    }

    val learningDebugEnabled: Flow<Boolean> = context.focusLockDataStore.data.map {
        it[Keys.learningDebugEnabled] ?: false
    }

    suspend fun setScheduleEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.scheduleEnabled] = enabled }
    }

    suspend fun setStartMinutes(minutes: Int) {
        require(minutes in 0..1439)
        context.focusLockDataStore.edit { it[Keys.startMinutes] = minutes }
    }

    suspend fun setLockActive(active: Boolean) {
        context.focusLockDataStore.edit { it[Keys.lockActive] = active }
    }

    suspend fun setEmergencyUntil(timestampMillis: Long) {
        context.focusLockDataStore.edit { it[Keys.emergencyUntil] = timestampMillis }
    }

    suspend fun setLearningStartUrl(url: String) {
        context.focusLockDataStore.edit { it[Keys.learningStartUrl] = url }
    }

    suspend fun setLearningRequiredMinutes(minutes: Int) {
        require(minutes >= 0)
        context.focusLockDataStore.edit { it[Keys.learningRequiredMinutes] = minutes }
    }

    suspend fun setLearningRequiredLectures(count: Int) {
        require(count >= 0)
        context.focusLockDataStore.edit { it[Keys.learningRequiredLectures] = count }
    }

    suspend fun setLearningDebugEnabled(enabled: Boolean) {
        context.focusLockDataStore.edit { it[Keys.learningDebugEnabled] = enabled }
    }

    suspend fun readSettings(): StoredSettings {
        val preferences = context.focusLockDataStore.data.first()
        return StoredSettings(
            scheduleEnabled = preferences[Keys.scheduleEnabled] ?: false,
            startMinutes = preferences[Keys.startMinutes] ?: (9 * 60),
            lockActive = preferences[Keys.lockActive] ?: false,
            emergencyUntil = preferences[Keys.emergencyUntil] ?: 0L
        )
    }

    suspend fun readLearningSettings(): LearningSettings {
        val preferences = context.focusLockDataStore.data.first()
        return LearningSettings(
            startUrl = preferences[Keys.learningStartUrl] ?: DEFAULT_LEARNING_START_URL,
            requiredMinutes = preferences[Keys.learningRequiredMinutes] ?: DEFAULT_LEARNING_REQUIRED_MINUTES,
            requiredLectures = preferences[Keys.learningRequiredLectures] ?: DEFAULT_LEARNING_REQUIRED_LECTURES,
            debugEnabled = preferences[Keys.learningDebugEnabled] ?: false
        )
    }

    suspend fun readLearningProgress(): LearningProgress {
        val today = LocalDate.now().toString()
        var progress = LearningProgress.empty(today)

        context.focusLockDataStore.edit { preferences ->
            val storedDate = preferences[Keys.learningProgressDate]
            if (storedDate != today) {
                preferences[Keys.learningProgressDate] = today
                preferences[Keys.learningLectureCredits] = emptySet()
                preferences[Keys.learningWatchedLectures] = emptySet()
            }

            progress = LearningProgress(
                date = today,
                creditsByLecture = parseLectureCredits(
                    preferences[Keys.learningLectureCredits] ?: emptySet()
                ),
                watchedLectureIds = preferences[Keys.learningWatchedLectures] ?: emptySet()
            )
        }

        return progress
    }

    suspend fun creditLearningLecture(
        lectureId: String,
        creditedSeconds: Long,
        durationSeconds: Long
    ): LearningProgress {
        require(lectureId.isNotBlank())
        require(creditedSeconds >= 0)
        require(durationSeconds > 0)

        val today = LocalDate.now().toString()
        var result = LearningProgress.empty(today)

        context.focusLockDataStore.edit { preferences ->
            val storedDate = preferences[Keys.learningProgressDate]
            val credits = if (storedDate == today) {
                parseLectureCredits(preferences[Keys.learningLectureCredits] ?: emptySet()).toMutableMap()
            } else {
                preferences[Keys.learningProgressDate] = today
                preferences[Keys.learningWatchedLectures] = emptySet()
                mutableMapOf()
            }

            val capped = minOf(creditedSeconds, durationSeconds)
            credits[lectureId] = capped

            val watched = if (storedDate == today) {
                (preferences[Keys.learningWatchedLectures] ?: emptySet()).toMutableSet()
            } else {
                mutableSetOf()
            }

            if (capped * 100L >= durationSeconds * 90L) {
                watched += lectureId
            }

            preferences[Keys.learningProgressDate] = today
            preferences[Keys.learningLectureCredits] = credits.entries
                .filter { it.value > 0 }
                .map { "${it.key}=${it.value}" }
                .toSet()
            preferences[Keys.learningWatchedLectures] = watched

            result = LearningProgress(today, credits, watched)
        }

        return result
    }

    companion object {
        const val DEFAULT_LEARNING_START_URL = "https://www.udemy.com"
        const val DEFAULT_LEARNING_REQUIRED_MINUTES = 30
        const val DEFAULT_LEARNING_REQUIRED_LECTURES = 0

        private fun parseLectureCredits(values: Set<String>): Map<String, Long> =
            values.mapNotNull { value ->
                val parts = value.split('=', limit = 2)
                if (parts.size != 2 || parts[0].isBlank()) return@mapNotNull null
                val seconds = parts[1].toLongOrNull() ?: return@mapNotNull null
                parts[0] to seconds
            }.toMap()
    }
}

data class StoredSettings(
    val scheduleEnabled: Boolean,
    val startMinutes: Int,
    val lockActive: Boolean,
    val emergencyUntil: Long
)

data class LearningSettings(
    val startUrl: String,
    val requiredMinutes: Int,
    val requiredLectures: Int,
    val debugEnabled: Boolean
)

data class LearningProgress(
    val date: String,
    val creditsByLecture: Map<String, Long>,
    val watchedLectureIds: Set<String>
) {
    val creditedSeconds: Long get() = creditsByLecture.values.sum()

    companion object {
        fun empty(date: String) = LearningProgress(date, emptyMap(), emptySet())
    }
}
